import QtQuick

QtObject {
    id: api

    property string projectId: "webgis-sctk"
    property string projectDocumentId: "fc98b8f1-78d5-456f-b76a-8ebb3b4b4160"
    property string idToken: ""
    property bool busy: false

    signal uploadSucceeded(string featureId)
    signal uploadFailed(string message)

    function firestoreValue(value) {
        if (value === null || value === undefined)
            return { nullValue: null }
        if (typeof value === "boolean")
            return { booleanValue: value }
        if (typeof value === "number") {
            if (isFinite(value) && Math.floor(value) === value)
                return { integerValue: String(value) }
            if (isFinite(value))
                return { doubleValue: value }
            return { stringValue: String(value) }
        }
        if (typeof value === "string")
            return { stringValue: value }
        if (value instanceof Array) {
            var values = []
            for (var i = 0; i < value.length; i++)
                values.push(firestoreValue(value[i]))
            return { arrayValue: { values: values } }
        }
        if (typeof value === "object") {
            var fields = {}
            for (var key in value) {
                if (value.hasOwnProperty(key))
                    fields[key] = firestoreValue(value[key])
            }
            return { mapValue: { fields: fields } }
        }
        return { stringValue: String(value) }
    }

    // Parse WKT coordinate groups into nested arrays. WKT coordinates are X Y
    // (longitude latitude for EPSG:4326). Z values are ignored intentionally.
    function parseWktCoordinates(text) {
        var tokens = text.match(/\(|\)|,|[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?/g)
        if (!tokens || tokens.length === 0)
            throw new Error("Koordinat WKT tidak dapat dibaca.")
        var index = 0
        function parseGroup() {
            if (tokens[index] !== "(")
                throw new Error("Format tanda kurung WKT tidak valid.")
            index++
            var items = []
            while (index < tokens.length && tokens[index] !== ")") {
                if (tokens[index] === "(") {
                    items.push(parseGroup())
                } else if (tokens[index] === ",") {
                    index++
                } else {
                    var x = Number(tokens[index++])
                    if (index >= tokens.length || tokens[index] === ")" || tokens[index] === ",")
                        throw new Error("Pasangan koordinat WKT tidak lengkap.")
                    var y = Number(tokens[index++])
                    // Skip optional Z/M dimensions, if present, until separator.
                    while (index < tokens.length && tokens[index] !== "," && tokens[index] !== ")") {
                        if (tokens[index] !== "(") index++
                        else break
                    }
                    items.push([x, y])
                }
            }
            if (tokens[index] !== ")")
                throw new Error("Kurung penutup WKT tidak ditemukan.")
            index++
            return items
        }
        return parseGroup()
    }

    function coordinatesToFirestoreShape(value) {
        if (value instanceof Array && value.length >= 2 &&
            typeof value[0] === "number" && typeof value[1] === "number") {
            return { lng: value[0], lat: value[1] }
        }
        if (value instanceof Array) {
            var out = []
            for (var i = 0; i < value.length; i++)
                out.push(coordinatesToFirestoreShape(value[i]))
            return out
        }
        return value
    }

    function normalizeGeometry(geometry) {
        var source = geometry || {}
        var type = String(source.type || "Unknown")
        var wkt = String(source.wkt || "").trim()
        var crs = String(source.crs || "").toUpperCase().replace(/\s+/g, "")

        if (wkt === "" || /^\s*(POINT|LINESTRING|POLYGON|MULTIPOINT|MULTILINESTRING|MULTIPOLYGON)\s+EMPTY\s*$/i.test(wkt))
            throw new Error("Geometri kosong atau WKT tidak tersedia.")

        // Never label projected coordinates as lat/lng. QField must use a layer
        // whose coordinates are already WGS84 for this QML-only implementation.
        if (crs !== "EPSG:4326" && crs !== "OGC:CRS84")
            throw new Error("Layer memakai " + (crs || "CRS tidak diketahui") + ". Untuk menyimpan koordinat lat/lng yang benar, ubah CRS layer ke EPSG:4326 lalu kirim ulang.")

        var match = wkt.match(/^\s*(POINT|LINESTRING|POLYGON|MULTIPOINT|MULTILINESTRING|MULTIPOLYGON)\s*(\([\s\S]*\))\s*$/i)
        if (!match)
            throw new Error("Tipe WKT belum didukung: " + type + ".")

        var wktType = match[1].toUpperCase()
        var canonicalType = {
            POINT: "Point",
            LINESTRING: "LineString",
            POLYGON: "Polygon",
            MULTIPOINT: "MultiPoint",
            MULTILINESTRING: "MultiLineString",
            MULTIPOLYGON: "MultiPolygon"
        }[wktType]
        var parsed = parseWktCoordinates(match[2])
        var coordinates = parsed

        // Point WKT has one coordinate pair wrapped in one group.
        if (canonicalType === "Point") {
            var point = parsed.length && parsed[0] instanceof Array ? parsed[0] : parsed
            if (!point || point.length < 2 || typeof point[0] !== "number")
                throw new Error("Koordinat Point tidak valid.")
            if (point[0] < -180 || point[0] > 180 || point[1] < -90 || point[1] > 90)
                throw new Error("Koordinat Point di luar rentang longitude/latitude EPSG:4326.")
            return { type: "Point", lng: point[0], lat: point[1] }
        }

        return {
            type: canonicalType,
            coordinates: coordinatesToFirestoreShape(coordinates)
        }
    }

    function uploadSurvey(documentId, featureUuid, layerId, layerName,
                          geometry, attributes, email, surveyDate) {
        if (api.busy) {
            api.uploadFailed("Pengiriman sedang berlangsung.")
            return
        }
        if (api.idToken.trim() === "") {
            api.uploadFailed("Silakan login terlebih dahulu.")
            return
        }
        if (String(api.projectDocumentId).trim() === "" ||
            String(documentId).trim() === "" || String(layerName).trim() === "") {
            api.uploadFailed("ID dokumen project, ID fitur, dan nama layer wajib diisi.")
            return
        }

        var uuid = String(featureUuid || documentId).replace(/^\{|\}$/g, "")
        var properties = {}
        var sourceAttributes = attributes || {}
        for (var key in sourceAttributes) {
            if (sourceAttributes.hasOwnProperty(key))
                properties[key] = sourceAttributes[key]
        }
        if (properties.uuid === undefined || properties.uuid === null || String(properties.uuid) === "")
            properties.uuid = uuid

        var normalizedGeometry
        try {
            normalizedGeometry = normalizeGeometry(geometry)
        } catch (geometryError) {
            api.uploadFailed(uuid + " — geometri tidak bisa dikirim: " + String(geometryError.message || geometryError))
            return
        }

        api.busy = true
        var url = "https://firestore.googleapis.com/v1/projects/"
            + encodeURIComponent(api.projectId)
            + "/databases/(default)/documents/projects/"
            + encodeURIComponent(api.projectDocumentId)
            + "/qfield_inbox/" + encodeURIComponent(String(documentId))

        var fields = {
            geometry: api.firestoreValue(normalizedGeometry),
            properties: api.firestoreValue(properties),
            type: { stringValue: "Feature" },
            uuid: { stringValue: uuid },
            feature_uuid: { stringValue: uuid },
            layer_id: api.firestoreValue(String(layerId || "")),
            layer_name: api.firestoreValue(String(layerName || "")),
            source: { stringValue: "qfield" },
            status: { stringValue: "pending" },
            surveyor: { stringValue: String(email || "") },
            uploaded_at: { timestampValue: new Date().toISOString() }
        }
        if (surveyDate !== undefined && surveyDate !== null && String(surveyDate).trim() !== "")
            fields.survey_date = api.firestoreValue(String(surveyDate))

        var request = new XMLHttpRequest()
        request.open("PATCH", url)
        request.setRequestHeader("Content-Type", "application/json")
        request.setRequestHeader("Authorization", "Bearer " + api.idToken)
        request.onreadystatechange = function() {
            if (request.readyState !== XMLHttpRequest.DONE)
                return
            api.busy = false
            if (request.status >= 200 && request.status < 300) {
                api.uploadSucceeded(uuid)
            } else {
                var message = "HTTP " + request.status
                try {
                    var result = JSON.parse(request.responseText)
                    if (result.error && result.error.message)
                        message += ": " + result.error.message
                } catch (error) {
                    message += ": respons server tidak dapat dibaca"
                }
                api.uploadFailed(uuid + " — " + message)
            }
        }
        request.onerror = function() {
            api.busy = false
            api.uploadFailed(uuid + " — gagal terhubung ke Firestore.")
        }
        request.send(JSON.stringify({ fields: fields }))
    }
}
