import QtQuick

QtObject {
    id: api

    property string projectId: "webgis-sctk"
    property string projectDocumentId: "fc98b8f1-78d5-456f-b76a-8ebb3b4b4160"
    property string idToken: ""
    property bool busy: false

    signal uploadSucceeded(string featureId)
    signal uploadFailed(string message)

    function firestoreValue(value) {
        if (value === null || value === undefined)
            return { nullValue: null }
        if (typeof value === "boolean")
            return { booleanValue: value }
        if (typeof value === "number") {
            if (!isFinite(value))
                return { stringValue: String(value) }
            if (Math.floor(value) === value)
                return { integerValue: String(value) }
            return { doubleValue: value }
        }
        if (typeof value === "string")
            return { stringValue: value }
        if (value instanceof Array) {
            var values = []
            for (var i = 0; i < value.length; i++)
                values.push(firestoreValue(value[i]))
            return { arrayValue: { values: values } }
        }
        if (typeof value === "object") {
            var fields = {}
            for (var key in value) {
                if (value.hasOwnProperty(key))
                    fields[key] = firestoreValue(value[key])
            }
            return { mapValue: { fields: fields } }
        }
        return { stringValue: String(value) }
    }

    // Membaca koordinat WKT menjadi array bersarang; dimensi Z/M diabaikan.
    function parseWktCoordinates(text) {
        var tokens = text.match(/\(|\)|,|[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?/g)
        if (!tokens || tokens.length === 0)
            throw new Error("Koordinat WKT tidak dapat dibaca.")

        var index = 0
        function parseGroup() {
            if (tokens[index] !== "(")
                throw new Error("Format tanda kurung WKT tidak valid.")
            index++
            var items = []
            while (index < tokens.length && tokens[index] !== ")") {
                if (tokens[index] === "(") {
                    items.push(parseGroup())
                } else if (tokens[index] === ",") {
                    index++
                } else {
                    var x = Number(tokens[index++])
                    if (index >= tokens.length || tokens[index] === ")" || tokens[index] === ",")
                        throw new Error("Pasangan koordinat WKT tidak lengkap.")
                    var y = Number(tokens[index++])
                    if (!isFinite(x) || !isFinite(y))
                        throw new Error("Koordinat WKT bukan angka yang valid.")
                    // Abaikan koordinat Z/M jika ada.
                    while (index < tokens.length && tokens[index] !== "," && tokens[index] !== ")") {
                        if (tokens[index] !== "(")
                            index++
                        else
                            break
                    }
                    items.push([x, y])
                }
            }
            if (tokens[index] !== ")")
                throw new Error("Kurung penutup WKT tidak ditemukan.")
            index++
            return items
        }
        var parsed = parseGroup()
        if (index !== tokens.length)
            throw new Error("Ada teks tambahan yang tidak dikenali setelah geometri WKT.")
        return parsed
    }

    // Firestore melarang array yang berisi array. Ubah setiap tingkat geometri
    // menjadi array berisi map agar aman disimpan sebagai nilai Firestore.
    function pointFromPair(pair) {
        // Beberapa keluaran WKT (terutama MultiPoint) membungkus pasangan
        // koordinat dalam satu atau lebih array tunggal: [[x, y]]. Lepaskan
        // pembungkus tersebut sebelum memvalidasi pasangan angka.
        var candidate = pair
        while (candidate instanceof Array && candidate.length === 1 &&
               candidate[0] instanceof Array) {
            candidate = candidate[0]
        }
        if (!(candidate instanceof Array) || candidate.length < 2 ||
                typeof candidate[0] !== "number" || typeof candidate[1] !== "number" ||
                !isFinite(candidate[0]) || !isFinite(candidate[1])) {
            var received = ""
            try { received = JSON.stringify(pair) } catch (e) { received = String(pair) }
            throw new Error("Pasangan koordinat tidak valid: " + received)
        }
        return { lng: candidate[0], lat: candidate[1] }
    }

    function pointList(points) {
        if (!(points instanceof Array))
            throw new Error("Daftar koordinat tidak valid.")
        var out = []
        for (var i = 0; i < points.length; i++)
            out.push(pointFromPair(points[i]))
        return out
    }

    function ringList(rings) {
        if (!(rings instanceof Array))
            throw new Error("Daftar ring Polygon tidak valid.")
        var out = []
        for (var i = 0; i < rings.length; i++)
            out.push({ points: pointList(rings[i]) })
        return out
    }

    function lineList(lines) {
        if (!(lines instanceof Array))
            throw new Error("Daftar garis MultiLineString tidak valid.")
        var out = []
        for (var i = 0; i < lines.length; i++)
            out.push({ points: pointList(lines[i]) })
        return out
    }

    function polygonList(polygons) {
        if (!(polygons instanceof Array))
            throw new Error("Daftar Polygon MultiPolygon tidak valid.")
        var out = []
        for (var i = 0; i < polygons.length; i++)
            out.push({ rings: ringList(polygons[i]) })
        return out
    }

    function normalizeGeometry(geometry) {
        var source = geometry || {}
        var type = String(source.type || "Unknown")
        var wkt = String(source.wkt || "").trim()
        var crs = String(source.crs || "").toUpperCase().replace(/\s+/g, "")

        if (wkt === "" || /^\s*(POINT|LINESTRING|POLYGON|MULTIPOINT|MULTILINESTRING|MULTIPOLYGON)\s+EMPTY\s*$/i.test(wkt))
            throw new Error("Geometri kosong atau WKT tidak tersedia.")

        // Penting: QML ini tidak memiliki transformasi CRS. Jangan menganggap
        // koordinat meter dari CRS proyeksi sebagai latitude/longitude.
        if (crs !== "EPSG:4326" && crs !== "OGC:CRS84")
            throw new Error("CRS layer adalah '" + (crs || "tidak diketahui") + "'. File ini hanya dapat mengubah koordinat menjadi format lat/lng jika sumbernya EPSG:4326/OGC:CRS84. Ubah CRS layer ke EPSG:4326 atau lakukan transformasi koordinat sebelum upload.")

        var match = wkt.match(/^\s*(POINT|LINESTRING|POLYGON|MULTIPOINT|MULTILINESTRING|MULTIPOLYGON)\s*(\([\s\S]*\))\s*$/i)
        if (!match)
            throw new Error("Tipe/format WKT belum didukung: " + type + ".")

        var wktType = match[1].toUpperCase()
        var canonicalType = {
            POINT: "Point",
            LINESTRING: "LineString",
            POLYGON: "Polygon",
            MULTIPOINT: "MultiPoint",
            MULTILINESTRING: "MultiLineString",
            MULTIPOLYGON: "MultiPolygon"
        }[wktType]
        var parsed = parseWktCoordinates(match[2])

        if (canonicalType === "Point") {
            var point = parsed.length && parsed[0] instanceof Array ? parsed[0] : parsed
            if (!point || point.length < 2 || typeof point[0] !== "number")
                throw new Error("Koordinat Point tidak valid.")
            if (point[0] < -180 || point[0] > 180 || point[1] < -90 || point[1] > 90)
                throw new Error("Koordinat Point di luar rentang longitude/latitude EPSG:4326. Pastikan CRS layer benar.")
            return { type: "Point", lng: point[0], lat: point[1] }
        }

        if (canonicalType === "LineString")
            return { type: canonicalType, coordinates: { points: pointList(parsed) } }
        if (canonicalType === "MultiPoint")
            return { type: canonicalType, coordinates: { points: pointList(parsed) } }
        if (canonicalType === "Polygon")
            return { type: canonicalType, coordinates: { rings: ringList(parsed) } }
        if (canonicalType === "MultiLineString")
            return { type: canonicalType, coordinates: { lines: lineList(parsed) } }
        if (canonicalType === "MultiPolygon")
            return { type: canonicalType, coordinates: { polygons: polygonList(parsed) } }

        throw new Error("Tipe geometri tidak didukung: " + canonicalType)
    }

    function uploadSurvey(documentId, featureUuid, layerId, layerName,
                          geometry, attributes, email, surveyDate) {
        if (api.busy) {
            api.uploadFailed("Pengiriman sedang berlangsung.")
            return
        }
        if (String(api.idToken).trim() === "") {
            api.uploadFailed("Silakan login terlebih dahulu. Token Firebase kosong.")
            return
        }
        if (String(api.projectId).trim() === "" ||
                String(api.projectDocumentId).trim() === "" ||
                String(documentId).trim() === "" || String(layerName).trim() === "") {
            api.uploadFailed("Project ID, ID dokumen project, ID fitur, dan nama layer wajib diisi.")
            return
        }

        var uuid = String(featureUuid || documentId).replace(/^\{/, "").replace(/\}$/, "")
        var properties = {}
        var sourceAttributes = attributes || {}
        for (var key in sourceAttributes) {
            if (sourceAttributes.hasOwnProperty(key))
                properties[key] = sourceAttributes[key]
        }
        if (properties.uuid === undefined || properties.uuid === null || String(properties.uuid).trim() === "")
            properties.uuid = uuid

        var normalizedGeometry
        try {
            normalizedGeometry = normalizeGeometry(geometry)
        } catch (geometryError) {
            api.uploadFailed(uuid + " — geometri tidak bisa dikirim: " + String(geometryError.message || geometryError))
            return
        }

        var url = "https://firestore.googleapis.com/v1/projects/"
            + encodeURIComponent(api.projectId)
            + "/databases/(default)/documents/projects/"
            + encodeURIComponent(api.projectDocumentId)
            + "/qfield_inbox/" + encodeURIComponent(String(documentId))

        var fields = {
            geometry: api.firestoreValue(normalizedGeometry),
            properties: api.firestoreValue(properties),
            type: { stringValue: "Feature" },
            uuid: { stringValue: uuid },
            feature_uuid: { stringValue: uuid },
            layer_id: api.firestoreValue(String(layerId || "")),
            layer_name: api.firestoreValue(String(layerName || "")),
            source: { stringValue: "qfield" },
            status: { stringValue: "pending" },
            surveyor: { stringValue: String(email || "") },
            uploaded_at: { timestampValue: new Date().toISOString() }
        }
        if (surveyDate !== undefined && surveyDate !== null && String(surveyDate).trim() !== "")
            fields.survey_date = api.firestoreValue(String(surveyDate))

        api.busy = true
        var request = new XMLHttpRequest()
        request.open("PATCH", url)
        request.setRequestHeader("Content-Type", "application/json")
        request.setRequestHeader("Authorization", "Bearer " + api.idToken)
        request.onreadystatechange = function() {
            if (request.readyState !== XMLHttpRequest.DONE)
                return
            api.busy = false
            if (request.status >= 200 && request.status < 300) {
                api.uploadSucceeded(uuid)
                return
            }

            var message = "HTTP " + request.status
            var detail = String(request.responseText || "").trim()
            try {
                var result = JSON.parse(request.responseText)
                if (result.error) {
                    var status = result.error.status ? String(result.error.status) : ""
                    var serverMessage = result.error.message ? String(result.error.message) : ""
                    if (status !== "") message += " " + status
                    if (serverMessage !== "") message += ": " + serverMessage
                    else if (detail !== "") message += ": " + detail
                } else if (detail !== "") {
                    message += ": " + detail
                }
            } catch (parseError) {
                if (detail !== "") message += ": " + detail
            }
            console.log("Firestore upload failed. URL=" + url + " response=" + detail)
            api.uploadFailed(uuid + " — " + message)
        }
        request.onerror = function() {
            api.busy = false
            api.uploadFailed(uuid + " — koneksi ke Firestore gagal. Periksa internet atau akses jaringan QField.")
        }
        request.ontimeout = function() {
            api.busy = false
            api.uploadFailed(uuid + " — request ke Firestore timeout. Coba lagi saat koneksi stabil.")
        }
        request.timeout = 30000
        request.send(JSON.stringify({ fields: fields }))
    }

    // =====================================================
    // BASE DARI QGIS (qfield_base)
    // =====================================================

    function firestoreToJs(v) {
        if (v === undefined || v === null) return null
        if (v.nullValue !== undefined) return null
        if (v.stringValue !== undefined) return v.stringValue
        if (v.integerValue !== undefined) return Number(v.integerValue)
        if (v.doubleValue !== undefined) return Number(v.doubleValue)
        if (v.booleanValue !== undefined) return v.booleanValue
        if (v.timestampValue !== undefined) return v.timestampValue
        if (v.arrayValue !== undefined) {
            var arr = []
            var values = v.arrayValue.values || []
            for (var i = 0; i < values.length; i++)
                arr.push(firestoreToJs(values[i]))
            return arr
        }
        if (v.mapValue !== undefined) {
            var obj = {}
            var fields = v.mapValue.fields || {}
            for (var key in fields) {
                if (fields.hasOwnProperty(key))
                    obj[key] = firestoreToJs(fields[key])
            }
            return obj
        }
        return null
    }

    function documentToJs(doc) {
        var out = {}
        var fields = doc.fields || {}
        for (var key in fields) {
            if (fields.hasOwnProperty(key))
                out[key] = firestoreToJs(fields[key])
        }
        out._docId = String(doc.name || "").split("/").pop()
        return out
    }

    function baseCollectionUrl() {
        return "https://firestore.googleapis.com/v1/projects/"
            + encodeURIComponent(api.projectId)
            + "/databases/(default)/documents/projects/"
            + encodeURIComponent(api.projectDocumentId)
            + "/qfield_base"
    }

    // Ambil semua dokumen dari sebuah collection, dengan paging.
    // callback(errorMessage, documents)
    function listAllDocuments(url, callback) {
        var collected = []

        function fetchPage(pageToken) {
            var pageUrl = url + "?pageSize=300"
            if (pageToken)
                pageUrl += "&pageToken=" + encodeURIComponent(pageToken)

            var request = new XMLHttpRequest()
            request.open("GET", pageUrl)
            request.setRequestHeader("Authorization", "Bearer " + api.idToken)
            request.timeout = 30000
            request.onreadystatechange = function() {
                if (request.readyState !== XMLHttpRequest.DONE)
                    return
                if (request.status === 404) {
                    callback("", collected)
                    return
                }
                if (request.status < 200 || request.status >= 300) {
                    callback("HTTP " + request.status + ": " + String(request.responseText || ""), collected)
                    return
                }
                var data = {}
                try { data = JSON.parse(request.responseText) } catch (e) { data = {} }
                var docs = data.documents || []
                for (var i = 0; i < docs.length; i++)
                    collected.push(api.documentToJs(docs[i]))
                if (data.nextPageToken)
                    fetchPage(data.nextPageToken)
                else
                    callback("", collected)
            }
            request.onerror = function() {
                callback("Koneksi ke Firestore gagal.", collected)
            }
            request.ontimeout = function() {
                callback("Request ke Firestore timeout.", collected)
            }
            request.send()
        }

        if (String(api.idToken).trim() === "") {
            callback("Silakan login terlebih dahulu.", [])
            return
        }
        fetchPage("")
    }

    function listBases(callback) {
        listAllDocuments(baseCollectionUrl(), callback)
    }

    function listBaseFeatures(baseDocId, callback) {
        listAllDocuments(baseCollectionUrl() + "/" + encodeURIComponent(baseDocId) + "/features", callback)
    }
}
