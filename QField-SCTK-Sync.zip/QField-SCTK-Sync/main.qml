
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import org.qfield
import org.qfield.core

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var availableLayers: []
    property string layerListMessage: "Tekan tombol untuk memuat layer."
    property string featureCheckOutput: "Pilih layer lalu ketuk Cek fitur."
    property var attributeHeaders: []
    property var attributeRows: []
    property string attributeLayerName: ""
    property string attributeLayerId: ""
    property int attributeFeatureCount: 0
    // Semua fitur dimuat; ListView hanya membuat delegate yang terlihat.
    property int sortColumn: -1
    property bool sortAscending: true
    property var selectedFeatureIds: []
    property var featurePayloads: []
    property var uploadQueue: []
    property int uploadQueueIndex: 0
    property int uploadSuccessCount: 0
    property int uploadFailureCount: 0
    property var uploadFailureDetails: []
    // Satu percobaan refresh + retry untuk setiap fitur yang mendapat HTTP 401.
    property bool uploadRetryPending: false
    property bool uploadRetryAttempted: false
    property string uploadSurveyDate: ""
    property string debugOutput: "Tekan Cek API untuk memeriksa API."

    // Tarik base dari QGIS (qfield_base)
    property var baseList: []
    property string baseListMessage: "Memuat daftar base..."
    property var pendingBase: null
    property bool pullBusy: false
    property string pullOutput: ""

    // Firebase Authentication
    property string firebaseApiKey: "ISI_WEB_API_KEY_FIREBASE"
    property string activeUser: "Belum login"
    property string connectionStatus: "Belum terhubung"
    property string idToken: ""
    property string refreshToken: ""
    property string loginError: ""
    property bool isLoggingIn: false

    Settings {
        id: loginSettings
        category: "SCTKSync"

        property string savedEmail: ""
        property string savedRefreshToken: ""
        property string savedApiKey: ""
    }

    // =====================================================
    // PEMERIKSAAN API QFIELD
    // =====================================================

    function debugQFieldApi() {
        var result = "=== QFIELD LAYER API CHECK ===\n"

        try {
            result += "iface: " + typeof iface + "\n"
            result += "iface.mapCanvas: " + typeof iface.mapCanvas + "\n"

            var canvas = iface.mapCanvas()
            var settings = canvas.mapSettings
            var layers = settings.layers

            result += "mapSettings: " + typeof settings + "\n"
            result += "settings.layers: " + typeof layers + "\n"

            if (layers !== undefined && layers !== null) {
                result += "Jumlah layer: " + layers.length + "\n"

                for (var i = 0; i < layers.length; i++) {
                    var item = layers[i]

                    result += (i + 1) + ". " +
                        (item && item.name !== undefined
                            ? String(item.name)
                            : "(nama tidak tersedia)") +
                        " | ID: " +
                        (item && item.id !== undefined
                            ? String(item.id)
                            : "(ID tidak tersedia)") + "\n"
                }
            }
            result += "\n=== EDIT API CHECK ===\n"
            result += "LayerUtils.addFeature: " + typeof LayerUtils.addFeature + "\n"
            result += "FeatureUtils.createBlankFeature: " + typeof FeatureUtils.createBlankFeature + "\n"
            result += "FeatureUtils.createFeature: " + typeof FeatureUtils.createFeature + "\n"
            result += "GeometryUtils.createGeometryFromWkt: " + typeof GeometryUtils.createGeometryFromWkt + "\n"
            result += "LayerUtils.createMemoryLayer: " + typeof LayerUtils.createMemoryLayer + "\n"
            result += "qgisProject: " + typeof qgisProject + "\n"
            if (typeof qgisProject !== "undefined" && qgisProject) {
                result += "qgisProject.addMapLayer: " + typeof qgisProject.addMapLayer + "\n"
                result += "qgisProject.mapLayers: " + typeof qgisProject.mapLayers + "\n"
            }

            var everyLayer = plugin.allProjectLayers()
            for (var m = 0; m < everyLayer.length; m++) {
                var ly = everyLayer[m]
                if (!ly || ly.fields === undefined) continue
                result += "\n[" + String(ly.name) + "]\n"
                result += "CRS: " + (ly.crs ? String(ly.crs.authid) : "?") + "\n"
                result += "fields: " + ly.fields.names.join(", ") + "\n"
            }

            for (var k = 0; k < layers.length; k++) {
                if (String(layers[k].name) === "Survei_Line") {
                    var t = layers[k]
                    result += "\n[Survei_Line]\n"
                    result += "CRS: " + (t.crs ? String(t.crs.authid) : "?") + "\n"
                    result += "startEditing: " + typeof t.startEditing + "\n"
                    result += "commitChanges: " + typeof t.commitChanges + "\n"
                    result += "changeAttributeValue: " + typeof t.changeAttributeValue + "\n"
                    result += "changeGeometry: " + typeof t.changeGeometry + "\n"
                    result += "fields: " + t.fields.names.join(", ") + "\n"
                }
            }
        } catch (error) {
            result += "\nERROR: " + String(error)
        }

        plugin.debugOutput = result
        debugDialog.open()
        console.log(result)
    }

    // =====================================================
    // PEMERIKSAAN FITUR DAN ATRIBUT
    // =====================================================


    function formatFeatureValue(value) {
        if (value === null || value === undefined || String(value) === "")
            return "—"
        if (value === true || String(value) === "true")
            return "Ya"
        if (value === false || String(value) === "false")
            return "Tidak"
        return String(value)
    }

    function sortAttributeRows(columnIndex) {
        if (plugin.sortColumn === columnIndex)
            plugin.sortAscending = !plugin.sortAscending
        else {
            plugin.sortColumn = columnIndex
            plugin.sortAscending = true
        }

        var sorted = plugin.attributeRows.slice(0)
        sorted.sort(function(a, b) {
            var av = String(a[columnIndex])
            var bv = String(b[columnIndex])
            var an = Number(av)
            var bn = Number(bv)
            var numeric = av.trim() !== "" && bv.trim() !== "" &&
                          !isNaN(an) && !isNaN(bn)
            var cmp = numeric ? (an < bn ? -1 : (an > bn ? 1 : 0))
                              : av.toLowerCase().localeCompare(bv.toLowerCase())
            return plugin.sortAscending ? cmp : -cmp
        })
        plugin.attributeRows = sorted
    }

    function isFeatureSelected(featureId) {
        return plugin.selectedFeatureIds.indexOf(String(featureId)) !== -1
    }

    // UUID v4 fallback for features that do not yet have a UUID attribute.
    // This creates a stable ID for the current upload queue; persistent local
    // UUIDs should be configured as a field default expression in QGIS: uuid().
    function generateUuidV4() {
        function hex4() { return Math.floor(Math.random() * 65536).toString(16).padStart(4, "0") }
        var value = hex4() + hex4() + "-" + hex4() + "-4" + hex4().slice(1) + "-" +
                    ((8 + Math.floor(Math.random() * 4)).toString(16)) + hex4().slice(1) + "-" +
                    hex4() + hex4() + hex4()
        return value.toLowerCase()
    }

    function setFeatureSelected(featureId, checked) {
        var id = String(featureId)
        var selected = plugin.selectedFeatureIds.slice(0)
        var pos = selected.indexOf(id)
        if (checked && pos < 0)
            selected.push(id)
        else if (!checked && pos >= 0)
            selected.splice(pos, 1)
        plugin.selectedFeatureIds = selected
    }

    function findFeaturePayload(featureId) {
        var target = String(featureId)
        for (var i = 0; i < plugin.featurePayloads.length; i++) {
            if (String(plugin.featurePayloads[i].rowId) === target)
                return plugin.featurePayloads[i]
        }
        return null
    }

    function buildSelectedUploadQueue() {
        var selected = plugin.selectedFeatureIds.slice(0)
        var queue = []
        var layer = null
        var layers = iface.mapCanvas().mapSettings.layers
        for (var i = 0; i < layers.length; i++) {
            if (String(layers[i].id) === String(plugin.attributeLayerId)) {
                layer = layers[i]
                break
            }
        }
        if (layer === null)
            throw new Error("Layer tidak ditemukan. Tutup tabel lalu buka kembali.")

        // Hanya ambil geometri fitur yang dipilih. Satu kali scan untuk semua pilihan.
        // WKT hanya format perantara dari QField; FirestoreApi mengubahnya ke map/array Firestore.
        var wanted = {}
        for (var w = 0; w < selected.length; w++)
            wanted[String(selected[w])] = true
        var iterator = LayerUtils.createFeatureIterator(layer)
        while (iterator.hasNext() && Object.keys(wanted).length > 0) {
            var feature = iterator.next()
            var rowId = String(feature.id)
            if (!wanted[rowId])
                continue
            var payload = plugin.findFeaturePayload(rowId)
            if (payload !== null) {
                // Prefer an existing UUID field; otherwise generate one for upload.
                var currentAttributes = {}
                var fieldNames = layer.fields.names
                for (var a = 0; a < fieldNames.length; a++) {
                    var fieldName = String(fieldNames[a])
                    var fieldValue = null
                    try { fieldValue = feature.attribute(fieldName) } catch (attributeError) { fieldValue = null }
                    currentAttributes[fieldName] = fieldValue === undefined ? null : fieldValue
                }
                var uuidFieldValue = ""
                for (var u = 0; u < fieldNames.length; u++) {
                    var candidateName = String(fieldNames[u]).toLowerCase()
                    if (candidateName === "uuid" || candidateName === "feature_uuid") {
                        var candidateValue = currentAttributes[String(fieldNames[u])]
                        if (candidateValue !== null && candidateValue !== undefined && String(candidateValue).trim() !== "") {
                            uuidFieldValue = String(candidateValue).replace(/^\{|\}$/g, "")
                            break
                        }
                    }
                }
                if (uuidFieldValue === "")
                    uuidFieldValue = plugin.generateUuidV4()
                payload.featureUuid = uuidFieldValue
                payload.documentId = uuidFieldValue
                // Keep the outgoing feature properties consistent with the document UUID.
                currentAttributes.uuid = uuidFieldValue
                payload.attributes = currentAttributes
                var geom = feature.geometry
                var wkt = ""
                if (geom !== undefined && geom !== null && typeof geom.asWkt === "function")
                    wkt = String(geom.asWkt())
                var geometryType = "Unknown"
                if (geom !== undefined && geom !== null) {
                    var typeNumber = Number(geom.type)
                    geometryType = typeNumber === 0 ? "Point" :
                                   (typeNumber === 1 ? "LineString" :
                                   (typeNumber === 2 ? "Polygon" : "Unknown"))
                }
                // Kirim WKT + CRS sebagai input perantara. Jangan kirim WKT
                // langsung sebagai geometry Firestore: FirestoreApi.qml akan
                // membentuk mapValue/arrayValue sesuai plugin QGIS SCTK Sync.
                payload.geometry = {
                    type: geometryType,
                    wkt: wkt,
                    crs: (layer.crs && layer.crs.authid !== undefined) ? String(layer.crs.authid) : ""
                }
                queue.push(payload)
                delete wanted[rowId]
            }
        }
        return queue
    }

    function startSelectedUpload() {
        if (plugin.idToken === "") {
            mainWindow.displayToast("Silakan login terlebih dahulu.")
            return
        }
        if (plugin.selectedFeatureIds.length === 0) {
            mainWindow.displayToast("Centang minimal satu fitur.")
            return
        }

        var queue = []
        try {
            queue = plugin.buildSelectedUploadQueue()
        } catch (queueError) {
            mainWindow.displayToast("Gagal menyiapkan fitur: " + String(queueError.message || queueError))
            return
        }

        if (queue.length === 0) {
            mainWindow.displayToast("Data fitur terpilih tidak ditemukan. Buka ulang tabel atribut.")
            return
        }

        plugin.uploadQueue = queue
        plugin.uploadQueueIndex = 0
        plugin.uploadSuccessCount = 0
        plugin.uploadFailureCount = 0
        plugin.uploadFailureDetails = []
        plugin.uploadRetryPending = false
        plugin.uploadRetryAttempted = false
        sendSelectionDialog.close()
        uploadProgressDialog.open()
        plugin.uploadNextFeature()
    }

    function uploadNextFeature() {
        if (plugin.uploadQueueIndex >= plugin.uploadQueue.length) {
            uploadProgressDialog.close()
            uploadResultDialog.open()
            return
        }

        var item = plugin.uploadQueue[plugin.uploadQueueIndex]
        uploadProgressText.text = "Mengirim " + (plugin.uploadQueueIndex + 1) +
                                  " dari " + plugin.uploadQueue.length +
                                  "\nLayer: " + plugin.attributeLayerName
        firestoreApi.uploadSurvey(
            item.documentId,
            item.featureUuid,
            plugin.attributeLayerId,
            plugin.attributeLayerName,
            item.geometry,
            item.attributes,
            plugin.activeUser,
            item.surveyDate
        )
    }

    function inspectLayer(layerId) {
        featureCheckDialog.open()
        plugin.featureCheckOutput = "Memuat atribut layer..."
        plugin.attributeHeaders = []
        plugin.attributeRows = []
        plugin.attributeLayerName = ""
        plugin.attributeLayerId = ""
        plugin.attributeFeatureCount = 0
        plugin.featurePayloads = []
        plugin.sortColumn = -1
        plugin.sortAscending = true
        plugin.selectedFeatureIds = []

        try {
            var layers = iface.mapCanvas().mapSettings.layers
            var layer = null
            for (var i = 0; i < layers.length; i++) {
                if (String(layers[i].id) === String(layerId)) {
                    layer = layers[i]
                    break
                }
            }

            if (layer === null) {
                plugin.featureCheckOutput = "Layer tidak ditemukan."
                return
            }

            var names = layer.fields.names
            var headers = ["ID_FITUR"]
            for (var h = 0; h < names.length; h++)
                headers.push(String(names[h]))

            var iterator = LayerUtils.createFeatureIterator(layer)
            var rows = []
            var payloads = []
            while (iterator.hasNext()) {
                var feature = iterator.next()
                var rowId = String(feature.id)
                var row = [rowId]
                var featureUuid = ""
                var surveyDate = ""

                for (var j = 0; j < names.length; j++) {
                    var fieldName = String(names[j])
                    var rawValue = null
                    try {
                        rawValue = feature.attribute(fieldName)
                    } catch (attributeError) {
                        rawValue = null
                    }
                    row.push(formatFeatureValue(rawValue))
                    var lowerName = fieldName.toLowerCase()
                    if ((lowerName === "uuid" || lowerName === "feature_uuid") &&
                        rawValue !== null && rawValue !== undefined &&
                        String(rawValue).trim() !== "") {
                        featureUuid = String(rawValue).replace(/^\\{|\\}$/g, "")
                    }
                    if ((lowerName === "survey_date" || lowerName === "tanggal_survei" ||
                         lowerName === "tanggal_survey" || lowerName === "tanggal") &&
                        rawValue !== null && rawValue !== undefined &&
                        String(rawValue).trim() !== "") {
                        surveyDate = String(rawValue)
                    }
                }

                // Jangan konversi geometri ke WKT untuk semua fitur saat tabel dibuka.
                // Ini operasi yang relatif berat pada layer besar/perangkat HP.
                // Geometri baru dibaca untuk fitur yang benar-benar dipilih saat upload.
                var geometryObject = null

                rows.push(row)
                payloads.push({
                    "rowId": rowId,
                    "featureUuid": featureUuid,
                    "documentId": featureUuid || "",
                    // Atribut lengkap dibaca ulang hanya untuk fitur yang dikirim.
                    "geometry": geometryObject,
                    "surveyDate": surveyDate
                })
            }

            plugin.attributeLayerName = String(layer.name)
            plugin.attributeLayerId = String(layer.id)
            plugin.attributeFeatureCount = rows.length
            plugin.attributeHeaders = headers
            plugin.attributeRows = rows
            plugin.featurePayloads = payloads
            plugin.featureCheckOutput = rows.length === 0
                ? "Layer ini belum memiliki fitur."
                : rows.length + " fitur tersedia. Tabel dirender bertahap agar lebih ringan."
        } catch (error) {
            plugin.featureCheckOutput = "Gagal membaca tabel atribut: " + String(error)
        }
        console.log("Tabel atribut layer selesai dibaca.")
    }

    // =====================================================
    // DAFTAR LAYER
    // =====================================================

    function refreshLayerList() {
        var rows = []

        try {
            var canvas = iface.mapCanvas()
            var layers = canvas.mapSettings.layers

            if (layers !== undefined && layers !== null) {
                for (var i = 0; i < layers.length; i++) {
                    var layer = layers[i]
                    var layerName = "Layer " + (i + 1)
                    var layerId = ""

                    try {
                        if (layer && layer.name !== undefined) {
                            layerName = String(layer.name)
                        }
                    } catch (nameError) {
                    }

                    try {
                        if (layer && layer.id !== undefined) {
                            layerId = String(layer.id)
                        }
                    } catch (idError) {
                    }

                    rows.push({
                        "name": layerName,
                        "id": layerId
                    })
                }
            }

            plugin.availableLayers = rows
            plugin.layerListMessage = rows.length > 0
                ? "Ditemukan " + rows.length +
                    " layer pada map canvas."
                : "Tidak ada layer yang ditemukan."
        } catch (error) {
            plugin.availableLayers = []
            plugin.layerListMessage =
                "Gagal membaca layer: " + String(error)
        }

        layerDialog.open()
    }

    // =====================================================
    // FIREBASE AUTHENTICATION
    // =====================================================

    FirebaseAuth {
        id: firebaseAuth
        apiKey: plugin.firebaseApiKey

        onLoginSucceeded: function(email, token, refresh) {
            plugin.isLoggingIn = false
            plugin.idToken = token
            plugin.refreshToken = refresh

            loginSettings.savedEmail = email
            loginSettings.savedRefreshToken = refresh

            plugin.activeUser = email
            plugin.connectionStatus = "Login berhasil"
            plugin.loginError = ""

            loginDialog.close()
            mainWindow.displayToast("Login berhasil")
        }

        onLoginFailed: function(message) {
            plugin.isLoggingIn = false
            plugin.loginError = message
        }

        onTokenRefreshed: function(token, refresh) {
            plugin.idToken = token
            plugin.refreshToken = refresh
            plugin.activeUser = loginSettings.savedEmail
            plugin.connectionStatus = "Login berhasil"
            plugin.loginError = ""
            loginSettings.savedRefreshToken = refresh

            if (plugin.uploadRetryPending) {
                // Ulangi fitur saat ini; jangan menaikkan indeks antrean dulu.
                plugin.uploadRetryPending = false
                mainWindow.displayToast("Sesi diperbarui, mencoba ulang upload...")
                plugin.uploadNextFeature()
            } else {
                mainWindow.displayToast("Sesi login berhasil dipulihkan")
            }
        }

        onRefreshFailed: function(message) {
            plugin.idToken = ""
            plugin.refreshToken = ""
            plugin.activeUser = "Belum login"
            plugin.connectionStatus = "Sesi berakhir, silakan login"
            plugin.loginError = message
            loginSettings.savedRefreshToken = ""

            if (plugin.uploadRetryPending) {
                plugin.uploadRetryPending = false
                var failedItem = plugin.uploadQueue[plugin.uploadQueueIndex]
                var details = plugin.uploadFailureDetails.slice(0)
                details.push("Fitur " + (failedItem ? failedItem.featureUuid : "tidak diketahui") +
                             ": refresh token gagal; " + String(message))
                plugin.uploadFailureDetails = details
                plugin.uploadFailureCount += 1
                plugin.uploadQueueIndex += 1
                plugin.uploadRetryAttempted = false
                plugin.uploadNextFeature()
            }
        }
    }

    // =====================================================
    // FIRESTORE API
    // =====================================================

    FirestoreApi {
        id: firestoreApi

        projectId: "webgis-sctk"
        projectDocumentId: "fc98b8f1-78d5-456f-b76a-8ebb3b4b4160"
        idToken: plugin.idToken

        onUploadSucceeded: function(featureId) {
            plugin.uploadSuccessCount += 1
            plugin.uploadRetryAttempted = false
            plugin.uploadRetryPending = false
            plugin.uploadQueueIndex += 1
            plugin.uploadNextFeature()
        }

        onUploadFailed: function(message) {
            var errorText = String(message)
            var isUnauthorized = errorText.indexOf("HTTP 401") !== -1 ||
                                 errorText.indexOf("UNAUTHENTICATED") !== -1

            if (isUnauthorized && !plugin.uploadRetryAttempted &&
                    plugin.refreshToken !== "") {
                plugin.uploadRetryAttempted = true
                plugin.uploadRetryPending = true
                plugin.connectionStatus = "Memperbarui sesi untuk upload..."
                firebaseAuth.refreshIdToken(plugin.refreshToken)
                return
            }

            plugin.uploadFailureCount += 1
            var details = plugin.uploadFailureDetails.slice(0)
            var failedItem = plugin.uploadQueue[plugin.uploadQueueIndex]
            details.push("Fitur " + (failedItem ? failedItem.featureUuid : "tidak diketahui") +
                         ": " + errorText)
            plugin.uploadFailureDetails = details
            console.log("Upload gagal: " + errorText)
            plugin.uploadRetryAttempted = false
            plugin.uploadQueueIndex += 1
            plugin.uploadNextFeature()
        }
    }


    // =====================================================
    // TARIK BASE DARI QGIS (qfield_base -> GPKG QField)
    // =====================================================

    // Normalisasi nama layer supaya "Pipa rencana" (QGIS) cocok dengan
    // "Pipa Rencana — pipa_rencana" (QField): huruf kecil, "_" jadi spasi,
    // spasi ganda dirapikan.
    function normalizeLayerName(name) {
        return String(name || "").toLowerCase().replace(/_/g, " ")
                                 .replace(/\s+/g, " ").trim()
    }

    // Semua kemungkinan nama untuk satu layer QField: nama lengkap,
    // bagian sebelum " — " (nama tampilan), dan bagian sesudahnya (nama tabel).
    function layerNameVariants(name) {
        var full = String(name || "")
        var variants = [plugin.normalizeLayerName(full)]
        var parts = full.split(/\s+[—–-]\s+/)
        for (var i = 0; i < parts.length; i++)
            variants.push(plugin.normalizeLayerName(parts[i]))
        return variants
    }

    function allProjectLayers() {
        var result = []
        try {
            if (typeof qgisProject !== "undefined" && qgisProject
                    && typeof qgisProject.mapLayers === "function") {
                var all = qgisProject.mapLayers()
                for (var id in all) {
                    if (all[id])
                        result.push(all[id])
                }
            }
        } catch (e) {
            console.log("mapLayers gagal: " + e)
        }
        if (result.length === 0) {
            var layers = iface.mapCanvas().mapSettings.layers
            for (var i = 0; i < layers.length; i++)
                result.push(layers[i])
        }
        return result
    }

    // Cari layer di seluruh proyek berdasarkan nama base dari QGIS.
    function findProjectLayerByName(name) {
        var target = plugin.normalizeLayerName(name)
        var layers = plugin.allProjectLayers()
        for (var i = 0; i < layers.length; i++) {
            if (!layers[i] || layers[i].fields === undefined)
                continue   // lewati layer raster seperti Google Satellite
            if (plugin.layerNameVariants(layers[i].name).indexOf(target) !== -1)
                return layers[i]
        }
        return null
    }

    function openBaseList() {
        if (plugin.idToken === "") {
            mainWindow.displayToast("Silakan login terlebih dahulu")
            return
        }
        plugin.baseList = []
        plugin.baseListMessage = "Memuat daftar base..."
        baseDialog.open()

        firestoreApi.listBases(function(error, documents) {
            if (error !== "") {
                plugin.baseListMessage = "Gagal memuat base: " + error
                return
            }
            var items = []
            for (var i = 0; i < documents.length; i++) {
                var d = documents[i]
                var layerName = String(d.layer_name || d._docId)
                var target = plugin.findProjectLayerByName(layerName)
                items.push({
                    docId: d._docId,
                    layerName: layerName,
                    geometryType: String(d.geometry_type || "-"),
                    crs: String(d.crs || ""),
                    featureCount: Number(d.feature_count || 0),
                    fields: d.fields || [],
                    inProject: target !== null,
                    targetName: target !== null ? String(target.name) : ""
                })
            }
            plugin.baseList = items
            plugin.baseListMessage = items.length === 0
                ? "Belum ada base di Firebase. Upload dulu dari QGIS lewat QField SCTK."
                : "Pilih base untuk dimasukkan ke layer dengan nama yang sama di proyek ini."
        })
    }

    function startPullBase(base) {
        plugin.pullBusy = true
        plugin.pullOutput = "Menarik base '" + base.layerName + "'...\n"
        pullResultDialog.open()

        var layer = plugin.findProjectLayerByName(base.layerName)
        if (layer === null) {
            plugin.pullBusy = false
            plugin.pullOutput += "GAGAL: layer '" + base.layerName + "' tidak ada di proyek QField ini."
            return
        }

        var layerCrs = (layer.crs && layer.crs.authid !== undefined) ? String(layer.crs.authid) : ""
        if (base.crs !== "" && layerCrs !== "" && base.crs !== layerCrs) {
            plugin.pullBusy = false
            plugin.pullOutput += "GAGAL: CRS berbeda.\n"
                + "Base: " + base.crs + "\nLayer QField: " + layerCrs + "\n"
                + "Samakan CRS layer di QGIS dan QField dulu."
            return
        }

        firestoreApi.listBaseFeatures(base.docId, function(error, documents) {
            if (error !== "") {
                plugin.pullBusy = false
                plugin.pullOutput += "GAGAL mengambil feature: " + error
                return
            }
            plugin.pullOutput += "Feature di Firebase: " + documents.length + "\n"
            try {
                plugin.applyBaseFeatures(layer, base, documents)
            } catch (e) {
                plugin.pullOutput += "\nERROR: " + String(e)
            }
            plugin.pullBusy = false
        })
    }

    function applyBaseFeatures(layer, base, documents) {
        var fieldNames = []
        var rawNames = layer.fields.names
        for (var n = 0; n < rawNames.length; n++)
            fieldNames.push(String(rawNames[n]))

        // Cari kolom uuid (tidak peka huruf besar/kecil)
        var uuidIndex = -1
        for (var u = 0; u < fieldNames.length; u++) {
            if (fieldNames[u].toLowerCase() === "uuid") { uuidIndex = u; break }
        }
        if (uuidIndex < 0) {
            plugin.pullOutput += "GAGAL: layer QField tidak punya kolom uuid untuk mencocokkan feature."
            return
        }
        var uuidFieldName = fieldNames[uuidIndex]

        // Index uuid -> fid untuk feature yang sudah ada di GPKG QField
        var existing = {}
        var iterator = LayerUtils.createFeatureIterator(layer)
        while (iterator.hasNext()) {
            var f = iterator.next()
            var val = f.attribute(uuidFieldName)
            if (val !== null && val !== undefined && String(val).trim() !== "")
                existing[String(val).replace(/^\{|\}$/g, "").toLowerCase()] = f.id
        }
        if (typeof iterator.close === "function")
            iterator.close()

        // Indeks kolom yang akan diisi: semua kolom yang namanya ada di layer, kecuali fid
        function fieldIndexOf(name) {
            var lower = String(name).toLowerCase()
            if (lower === "fid") return -1
            var exact = fieldNames.indexOf(String(name))
            if (exact >= 0) return exact
            for (var i = 0; i < fieldNames.length; i++)
                if (fieldNames[i].toLowerCase() === lower) return i
            return -1
        }

        layer.startEditing()

        var added = 0, updated = 0, skipped = 0, failed = 0
        var notes = []
        var attrCheckDone = false

        for (var d = 0; d < documents.length; d++) {
            var doc = documents[d]
            var props = doc.properties || {}
            var featureUuid = String(doc.uuid || props[uuidFieldName] || props.uuid || props.UUID || doc._docId)
                              .replace(/^\{|\}$/g, "")
            var key = featureUuid.toLowerCase()

            if (existing[key] !== undefined) {
                // UPDATE: atribut saja (QField belum menyediakan changeGeometry)
                var fid = existing[key]
                for (var pName in props) {
                    if (!props.hasOwnProperty(pName)) continue
                    var idx = fieldIndexOf(pName)
                    if (idx < 0 || idx === uuidIndex) continue
                    layer.changeAttributeValue(fid, idx, props[pName])
                }
                updated++
                continue
            }

            // INSERT: feature baru
            var wkt = String(doc.geometry_wkt || "").trim()
            if (wkt === "") {
                skipped++
                if (notes.length < 10) notes.push(featureUuid + ": tidak punya geometri, dilewati")
                continue
            }

            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            var feature = FeatureUtils.createBlankFeature(layer.fields, geometry)

            for (var aName in props) {
                if (!props.hasOwnProperty(aName)) continue
                var aIdx = fieldIndexOf(aName)
                if (aIdx < 0) continue
                feature.setAttribute(aIdx, props[aName])
            }
            feature.setAttribute(uuidIndex, featureUuid)

            if (!attrCheckDone) {
                attrCheckDone = true
                if (String(feature.attribute(uuidFieldName) || "") === "")
                    notes.push("PERINGATAN: atribut tidak terisi ke feature baru (setAttribute tidak berpengaruh).")
            }

            if (LayerUtils.addFeature(layer, feature)) {
                added++
                existing[key] = -1
            } else {
                failed++
                if (notes.length < 10) notes.push(featureUuid + ": gagal ditambahkan")
            }
        }

        var committed = layer.commitChanges()
        if (!committed) {
            var errors = ""
            if (typeof layer.commitErrors === "function") {
                try { errors = String(layer.commitErrors()) } catch (e) { errors = "" }
            }
            if (typeof layer.rollBack === "function")
                layer.rollBack()
            plugin.pullOutput += "\nGAGAL menyimpan ke GPKG. Semua perubahan dibatalkan.\n" + errors
            return
        }

        plugin.pullOutput += "\nSELESAI\n"
            + "Ditambahkan : " + added + "\n"
            + "Diperbarui  : " + updated + " (atribut saja, geometri tidak diubah)\n"
            + "Dilewati    : " + skipped + "\n"
            + "Gagal       : " + failed + "\n"
        if (notes.length > 0)
            plugin.pullOutput += "\nCatatan:\n- " + notes.join("\n- ")

        if (typeof layer.triggerRepaint === "function")
            layer.triggerRepaint()
        mainWindow.displayToast("Base '" + base.layerName + "' selesai ditarik")
    }

    // =====================================================
    // INISIALISASI
    // =====================================================

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(openDashboardButton)

        if (loginSettings.savedApiKey !== "") {
            plugin.firebaseApiKey = loginSettings.savedApiKey
            firebaseAuth.apiKey = loginSettings.savedApiKey
        }

        if (loginSettings.savedRefreshToken !== "") {
            plugin.activeUser = loginSettings.savedEmail
            plugin.connectionStatus = "Memulihkan sesi login..."

            firebaseAuth.refreshIdToken(
                loginSettings.savedRefreshToken
            )
        }

        mainWindow.displayToast(
            "QField SCTK Sync siap digunakan"
        )
    }

    // =====================================================
    // LOGOUT
    // =====================================================

    function logoutFirebase() {
        plugin.idToken = ""
        plugin.refreshToken = ""
        plugin.activeUser = "Belum login"
        plugin.connectionStatus = "Belum terhubung"
        plugin.loginError = ""
        plugin.isLoggingIn = false

        loginSettings.savedEmail = ""
        loginSettings.savedRefreshToken = ""
        loginSettings.savedApiKey = ""

        plugin.firebaseApiKey = ""
        firebaseAuth.apiKey = ""

        mainWindow.displayToast("Logout berhasil")
    }

    // =====================================================
    // KOMPONEN UI (inline, tidak menambah file baru)
    // Palet: netral + satu aksen hijau.
    //   Aksen #166534 | Teks #111827 | Teks redup #6B7280
    //   Garis #E5E7EB | Permukaan #F9FAFB | Bahaya #B91C1C
    // =====================================================

    component AppButton: Button {
        id: appBtn

        // kind: "primary" | "secondary" | "ghost" | "danger"
        property string kind: "secondary"
        property bool compact: false

        implicitHeight: compact ? 36 : 44
        leftPadding: compact ? 14 : 18
        rightPadding: compact ? 14 : 18
        font.pixelSize: compact ? 13 : 14
        font.weight: Font.Medium
        font.capitalization: Font.MixedCase
        opacity: enabled ? 1.0 : 0.4

        contentItem: Text {
            text: appBtn.text
            font: appBtn.font
            elide: Text.ElideRight
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            color: appBtn.kind === "primary" ? "#FFFFFF"
                 : appBtn.kind === "danger" ? "#B91C1C"
                 : appBtn.kind === "ghost" ? "#166534"
                 : "#111827"
        }

        background: Rectangle {
            radius: 8
            color: appBtn.kind === "primary"
                   ? (appBtn.down ? "#14532D" : "#166534")
                   : appBtn.kind === "danger"
                     ? (appBtn.down ? "#FEE2E2" : "#FFFFFF")
                     : appBtn.kind === "ghost"
                       ? (appBtn.down ? "#F0FDF4" : "transparent")
                       : (appBtn.down ? "#F3F4F6" : "#FFFFFF")
            border.width: (appBtn.kind === "secondary" || appBtn.kind === "danger") ? 1 : 0
            border.color: appBtn.kind === "danger" ? "#FECACA" : "#D1D5DB"
        }
    }

    component AppDialog: Dialog {
        id: appDlg

        property bool showClose: true

        modal: true
        standardButtons: Dialog.NoButton
        padding: 16
        topPadding: 12

        Overlay.modal: Rectangle {
            color: "#66000000"
        }

        background: Rectangle {
            color: "#FFFFFF"
            radius: 16
            border.color: "#E5E7EB"
        }

        header: Item {
            implicitHeight: 56

            Label {
                anchors.left: parent.left
                anchors.leftMargin: 20
                anchors.right: closeButton.left
                anchors.rightMargin: 8
                anchors.verticalCenter: parent.verticalCenter
                text: appDlg.title
                color: "#111827"
                font.pixelSize: 17
                font.weight: Font.DemiBold
                elide: Text.ElideRight
            }

            ToolButton {
                id: closeButton
                visible: appDlg.showClose
                z: 20
                width: 44
                height: 44
                anchors.right: parent.right
                anchors.rightMargin: 4
                anchors.verticalCenter: parent.verticalCenter
                text: "✕"
                font.pixelSize: 18
                font.weight: Font.DemiBold
                padding: 0
                contentItem: Text {
                    text: closeButton.text
                    color: "#374151"
                    font: closeButton.font
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
                background: Rectangle {
                    radius: 10
                    color: closeButton.down ? "#E5E7EB" : "transparent"
                }
                onClicked: appDlg.close()
            }

            Rectangle {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                height: 1
                color: "#F1F5F9"
            }
        }
    }

    // =====================================================
    // TOMBOL TOOLBAR
    // =====================================================

    Button {
        id: openDashboardButton

        text: "SCTK"
        width: 48
        height: 48
        font.pixelSize: 11
        font.bold: true
        font.capitalization: Font.MixedCase

        contentItem: Text {
            text: openDashboardButton.text
            font: openDashboardButton.font
            color: "#FFFFFF"
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
        }

        background: Rectangle {
            radius: width / 2
            color: openDashboardButton.down ? "#14532D" : "#166534"
        }

        onClicked: dashboard.open()
    }

    // =====================================================
    // DASHBOARD
    // =====================================================

    AppDialog {
        id: dashboard

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 24, 420)
        height: Math.min(parent.height - 32, 440)

        title: "QField SCTK Sync"

        contentItem: Flickable {
            clip: true
            contentWidth: width
            contentHeight: dashboardColumn.implicitHeight
            boundsBehavior: Flickable.StopAtBounds

            ColumnLayout {
                id: dashboardColumn

                width: parent.width
                spacing: 12

                // Akun & status koneksi
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: accountRow.implicitHeight + 32
                    radius: 12
                    color: "#F9FAFB"
                    border.color: "#E5E7EB"

                    RowLayout {
                        id: accountRow

                        anchors.fill: parent
                        anchors.margins: 16
                        spacing: 12

                        Rectangle {
                            Layout.preferredWidth: 40
                            Layout.preferredHeight: 40
                            radius: 20
                            color: plugin.idToken !== "" ? "#DCFCE7" : "#E5E7EB"

                            Label {
                                anchors.centerIn: parent
                                text: plugin.idToken !== "" && plugin.activeUser.length > 0
                                      ? plugin.activeUser.charAt(0).toUpperCase() : "?"
                                color: plugin.idToken !== "" ? "#166534" : "#6B7280"
                                font.pixelSize: 16
                                font.bold: true
                            }
                        }

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 3

                            Label {
                                Layout.fillWidth: true
                                text: plugin.activeUser
                                color: "#111827"
                                font.pixelSize: 14
                                font.weight: Font.DemiBold
                                elide: Text.ElideMiddle
                            }

                            RowLayout {
                                Layout.fillWidth: true
                                spacing: 6

                                Rectangle {
                                    Layout.preferredWidth: 8
                                    Layout.preferredHeight: 8
                                    Layout.alignment: Qt.AlignVCenter
                                    radius: 4
                                    color: plugin.idToken !== "" ? "#16A34A" : "#D97706"
                                }

                                Label {
                                    Layout.fillWidth: true
                                    text: plugin.connectionStatus
                                    color: "#6B7280"
                                    font.pixelSize: 12
                                    elide: Text.ElideRight
                                }
                            }
                        }

                        AppButton {
                            compact: true
                            kind: plugin.idToken === "" ? "primary" : "secondary"
                            text: plugin.idToken === "" ? "Login" : "Akun"

                            onClicked: {
                                if (plugin.idToken === "") {
                                    plugin.loginError = ""
                                    loginDialog.open()
                                } else {
                                    accountDialog.open()
                                }
                            }
                        }
                    }
                }

                // Survei
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: surveyColumn.implicitHeight + 32
                    radius: 12
                    color: "#FFFFFF"
                    border.color: "#E5E7EB"

                    ColumnLayout {
                        id: surveyColumn

                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.top: parent.top
                        anchors.margins: 16
                        spacing: 6

                        Label {
                            text: "Survei QField"
                            color: "#111827"
                            font.pixelSize: 15
                            font.weight: Font.DemiBold
                        }

                        Label {
                            Layout.fillWidth: true
                            text: "Lihat layer proyek dan siapkan hasil survei untuk dikirim ke Firebase."
                            color: "#6B7280"
                            font.pixelSize: 13
                            wrapMode: Text.WordWrap
                        }

                        AppButton {
                            Layout.fillWidth: true
                            Layout.topMargin: 8
                            kind: "primary"
                            text: "Lihat daftar layer"
                            onClicked: plugin.refreshLayerList()
                        }
                    }
                }

                // Base dari QGIS
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: baseColumn.implicitHeight + 32
                    radius: 12
                    color: "#FFFFFF"
                    border.color: "#E5E7EB"

                    ColumnLayout {
                        id: baseColumn

                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.top: parent.top
                        anchors.margins: 16
                        spacing: 6

                        Label {
                            text: "Base dari QGIS"
                            color: "#111827"
                            font.pixelSize: 15
                            font.weight: Font.DemiBold
                        }

                        Label {
                            Layout.fillWidth: true
                            text: "Tarik data acuan dari QGIS ke GeoPackage QField, ke layer dengan nama yang sama."
                            color: "#6B7280"
                            font.pixelSize: 13
                            wrapMode: Text.WordWrap
                        }

                        AppButton {
                            Layout.fillWidth: true
                            Layout.topMargin: 8
                            kind: "secondary"
                            text: "Tarik base"
                            enabled: plugin.idToken !== ""
                            onClicked: plugin.openBaseList()
                        }
                    }
                }

                Label {
                    Layout.fillWidth: true
                    Layout.topMargin: 2
                    text: "Proyek  ·  " + firestoreApi.projectId
                    color: "#9CA3AF"
                    font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                    elide: Text.ElideMiddle
                }
            }
        }
    }

    // =====================================================
    // DIALOG DAFTAR LAYER
    // =====================================================

    AppDialog {
        id: layerDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 420)
        height: Math.min(parent.height - 48, 540)

        title: "Daftar Layer"

        contentItem: ColumnLayout {
            spacing: 8

            Label {
                Layout.fillWidth: true
                text: plugin.layerListMessage
                color: "#6B7280"
                font.pixelSize: 13
                wrapMode: Text.WordWrap
            }

            ListView {
                id: layerList

                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                model: plugin.availableLayers
                boundsBehavior: Flickable.StopAtBounds

                ScrollBar.vertical: ScrollBar {
                    policy: ScrollBar.AsNeeded
                }

                delegate: Item {
                    id: layerRow

                    required property var modelData
                    required property int index

                    width: ListView.view.width
                    height: 64

                    Rectangle {
                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.bottom: parent.bottom
                        height: 1
                        color: "#F1F5F9"
                        visible: layerRow.index < layerList.count - 1
                    }

                    RowLayout {
                        anchors.fill: parent
                        anchors.rightMargin: 4
                        spacing: 12

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 2

                            Label {
                                Layout.fillWidth: true
                                text: layerRow.modelData.name
                                color: "#111827"
                                font.pixelSize: 14
                                font.weight: Font.DemiBold
                                elide: Text.ElideRight
                            }

                            Label {
                                Layout.fillWidth: true
                                text: layerRow.modelData.id !== ""
                                      ? layerRow.modelData.id
                                      : "ID layer tidak tersedia"
                                color: "#9CA3AF"
                                font.pixelSize: 10
                                elide: Text.ElideMiddle
                            }
                        }

                        AppButton {
                            compact: true
                            text: "Cek fitur"

                            onClicked: {
                                try {
                                    var chosenLayerId = layerRow.modelData.id
                                    layerDialog.close()
                                    plugin.inspectLayer(chosenLayerId)
                                } catch (error) {
                                    plugin.featureCheckOutput =
                                        "ERROR TOMBOL CEK FITUR: " + String(error)
                                    featureCheckDialog.open()
                                }
                            }
                        }
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                AppButton {
                    compact: true
                    kind: "ghost"
                    text: "Cek API"
                    onClicked: {
                        layerDialog.close()
                        plugin.debugQFieldApi()
                    }
                }

                Item {
                    Layout.fillWidth: true
                }
            }
        }
    }

    // =====================================================
    // DIALOG TABEL ATRIBUT QFIELD
    // =====================================================

    AppDialog {
        id: featureCheckDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.max(260, Math.min(parent.width - 24, 1040))
        height: Math.max(300, Math.min(parent.height - 24, 780))

        title: "Tabel Atribut"

        contentItem: ColumnLayout {
            spacing: 10

            // Ringkasan layer
            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2

                    Label {
                        Layout.fillWidth: true
                        text: plugin.attributeLayerName
                        color: "#111827"
                        font.pixelSize: 15
                        font.weight: Font.DemiBold
                        elide: Text.ElideRight
                    }

                    Label {
                        Layout.fillWidth: true
                        text: plugin.attributeFeatureCount + " fitur  ·  " +
                              plugin.attributeHeaders.length + " kolom"
                        color: "#6B7280"
                        font.pixelSize: 12
                        elide: Text.ElideRight
                    }
                }

                Rectangle {
                    Layout.preferredWidth: selectedChipLabel.implicitWidth + 24
                    Layout.preferredHeight: 28
                    radius: 14
                    color: plugin.selectedFeatureIds.length > 0 ? "#DCFCE7" : "#F3F4F6"

                    Label {
                        id: selectedChipLabel
                        anchors.centerIn: parent
                        text: plugin.selectedFeatureIds.length + " dipilih"
                        color: plugin.selectedFeatureIds.length > 0 ? "#166534" : "#6B7280"
                        font.pixelSize: 12
                        font.weight: Font.DemiBold
                    }
                }
            }

            Label {
                Layout.fillWidth: true
                text: plugin.featureCheckOutput
                visible: plugin.featureCheckOutput !== ""
                color: "#6B7280"
                font.pixelSize: 12
                wrapMode: Text.WordWrap
            }

            // Tabel
            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                radius: 8
                color: "#FFFFFF"
                border.color: "#E5E7EB"
                clip: true

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 1
                    spacing: 0

                    // Header terpisah dari isi agar tetap terlihat saat scroll vertikal.
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 40
                        color: "#F3F4F6"

                        Flickable {
                            id: attributeHeaderFlick

                            anchors.fill: parent
                            clip: true
                            contentWidth: Math.max(width, 48 + plugin.attributeHeaders.length * 136)
                            contentHeight: height
                            interactive: false
                            boundsBehavior: Flickable.StopAtBounds

                            Row {
                                height: 40
                                spacing: 0

                                Item {
                                    width: 48
                                    height: 40

                                    Text {
                                        anchors.centerIn: parent
                                        text: "Pilih"
                                        color: "#374151"
                                        font.bold: true
                                        font.pixelSize: 11
                                    }
                                }

                                Repeater {
                                    model: plugin.attributeHeaders

                                    delegate: Item {
                                        required property var modelData
                                        required property int index

                                        width: 136
                                        height: 40

                                        Button {
                                            anchors.fill: parent
                                            flat: true
                                            padding: 8
                                            text: String(modelData) +
                                                  (plugin.sortColumn === index
                                                   ? (plugin.sortAscending ? "  ▲" : "  ▼") : "")

                                            contentItem: Text {
                                                text: parent.text
                                                color: plugin.sortColumn === index ? "#166534" : "#374151"
                                                font.bold: true
                                                font.pixelSize: 11
                                                font.capitalization: Font.MixedCase
                                                verticalAlignment: Text.AlignVCenter
                                                horizontalAlignment: Text.AlignLeft
                                                elide: Text.ElideRight
                                            }

                                            background: Rectangle {
                                                color: parent.down ? "#E5E7EB" : "transparent"
                                            }

                                            onClicked: plugin.sortAttributeRows(index)
                                        }
                                    }
                                }
                            }
                        }

                        Rectangle {
                            anchors.left: parent.left
                            anchors.right: parent.right
                            anchors.bottom: parent.bottom
                            height: 1
                            color: "#E5E7EB"
                        }
                    }

                    Item {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true

                        Flickable {
                            id: attributeBodyFlick

                            anchors.fill: parent
                            clip: true
                            contentWidth: Math.max(width, 48 + plugin.attributeHeaders.length * 136)
                            contentHeight: height
                            boundsBehavior: Flickable.StopAtBounds
                            flickableDirection: Flickable.HorizontalFlick
                            onContentXChanged: attributeHeaderFlick.contentX = contentX

                            ListView {
                                id: attributeRowsList

                                x: 0
                                y: 0
                                width: attributeBodyFlick.contentWidth
                                height: attributeBodyFlick.height
                                clip: true
                                model: plugin.attributeRows
                                boundsBehavior: Flickable.StopAtBounds
                                reuseItems: true
                                cacheBuffer: 0
                                spacing: 0

                                delegate: Item {
                                    id: tableRow

                                    required property var modelData

                                    readonly property bool picked: plugin.isFeatureSelected(modelData[0])

                                    width: attributeBodyFlick.contentWidth
                                    height: 40

                                    Rectangle {
                                        anchors.fill: parent
                                        color: tableRow.picked ? "#F0FDF4" : "transparent"
                                    }

                                    Rectangle {
                                        anchors.left: parent.left
                                        anchors.right: parent.right
                                        anchors.bottom: parent.bottom
                                        height: 1
                                        color: "#F1F5F9"
                                    }

                                    Row {
                                        anchors.fill: parent
                                        spacing: 0

                                        Item {
                                            id: checkboxCell
                                            width: 48
                                            height: 40

                                            Rectangle {
                                                id: checkboxVisual
                                                width: 20
                                                height: 20
                                                radius: 4
                                                anchors.centerIn: parent
                                                color: tableRow.picked ? "#166534" : "#FFFFFF"
                                                border.width: tableRow.picked ? 0 : 1.5
                                                border.color: tableRow.picked ? "#166534" : "#9CA3AF"

                                                Text {
                                                    anchors.centerIn: parent
                                                    visible: tableRow.picked
                                                    text: "✓"
                                                    color: "#FFFFFF"
                                                    font.pixelSize: 15
                                                    font.bold: true
                                                }
                                            }

                                            MouseArea {
                                                anchors.fill: parent
                                                onClicked: plugin.setFeatureSelected(tableRow.modelData[0], !tableRow.picked)
                                            }
                                        }

                                        Repeater {
                                            model: tableRow.modelData

                                            delegate: Item {
                                                required property var modelData
                                                required property int index

                                                width: 136
                                                height: 40

                                                Text {
                                                    anchors.fill: parent
                                                    anchors.leftMargin: 8
                                                    anchors.rightMargin: 8
                                                    text: String(modelData)
                                                    color: index === 0 ? "#6B7280" : "#1F2937"
                                                    font.pixelSize: 12
                                                    verticalAlignment: Text.AlignVCenter
                                                    elide: Text.ElideRight
                                                }
                                            }
                                        }
                                    }
                                }

                                ScrollBar.vertical: ScrollBar {
                                    policy: ScrollBar.AsNeeded
                                    width: 10
                                    minimumSize: 0.08
                                }
                            }

                            ScrollBar.horizontal: ScrollBar {
                                policy: ScrollBar.AsNeeded
                                height: 10
                                minimumSize: 0.08
                            }
                        }
                    }
                }
            }

            Label {
                Layout.fillWidth: true
                text: plugin.idToken === ""
                      ? "Login diperlukan untuk mengirim data."
                      : "Geser ke samping untuk kolom lain. Ketuk judul kolom untuk mengurutkan."
                color: "#9CA3AF"
                font.pixelSize: 11
                wrapMode: Text.WordWrap
            }

            // Aksi
            RowLayout {
                Layout.fillWidth: true
                spacing: 6

                AppButton {
                    compact: true
                    kind: "ghost"
                    text: "Pilih semua"
                    onClicked: {
                        var ids = []
                        for (var i = 0; i < plugin.attributeRows.length; i++)
                            ids.push(String(plugin.attributeRows[i][0]))
                        plugin.selectedFeatureIds = ids
                    }
                }

                AppButton {
                    compact: true
                    kind: "ghost"
                    text: "Batal pilih"
                    onClicked: plugin.selectedFeatureIds = []
                }

                Item {
                    Layout.fillWidth: true
                }

                AppButton {
                    kind: "primary"
                    text: "Kirim (" + plugin.selectedFeatureIds.length + ")"
                    enabled: plugin.selectedFeatureIds.length > 0 && plugin.idToken !== ""
                    onClicked: sendSelectionDialog.open()
                }
            }
        }
    }

    // =====================================================
    // KONFIRMASI, PROGRES, DAN HASIL PENGIRIMAN
    // =====================================================

    AppDialog {
        id: sendSelectionDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 420)
        title: "Konfirmasi Pengiriman"

        contentItem: ColumnLayout {
            spacing: 14

            Label {
                Layout.fillWidth: true
                text: "Kamu memilih " + plugin.selectedFeatureIds.length +
                      " fitur dari layer " + plugin.attributeLayerName + "."
                color: "#111827"
                font.pixelSize: 14
                wrapMode: Text.WordWrap
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: noteLabel.implicitHeight + 24
                radius: 10
                color: "#FFFBEB"
                border.color: "#FDE68A"

                Label {
                    id: noteLabel

                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.margins: 12
                    text: "Fitur terpilih dikirim ke antrean survei Firebase. Atribut disimpan sebagai properties dan geometri sebagai objek terstruktur dengan koordinat. Data utama tidak ditimpa langsung."
                    color: "#92400E"
                    font.pixelSize: 12
                    wrapMode: Text.WordWrap
                }
            }

            RowLayout {
                Layout.fillWidth: true
                Layout.topMargin: 4
                spacing: 8

                AppButton {
                    Layout.fillWidth: true
                    text: "Batal"
                    onClicked: sendSelectionDialog.close()
                }

                AppButton {
                    Layout.fillWidth: true
                    kind: "primary"
                    text: "Kirim sekarang"
                    onClicked: plugin.startSelectedUpload()
                }
            }
        }
    }

    AppDialog {
        id: uploadProgressDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 420)
        title: "Mengirim Data Survei"
        showClose: false
        closePolicy: Popup.NoAutoClose

        contentItem: ColumnLayout {
            spacing: 14

            Label {
                id: uploadProgressText

                Layout.fillWidth: true
                text: "Menyiapkan pengiriman..."
                color: "#111827"
                font.pixelSize: 14
                wrapMode: Text.WordWrap
            }

            ProgressBar {
                Layout.fillWidth: true
                from: 0
                to: Math.max(1, plugin.uploadQueue.length)
                value: plugin.uploadQueueIndex
            }

            Label {
                Layout.fillWidth: true
                text: "Jangan tutup aplikasi sampai pengiriman selesai."
                color: "#9CA3AF"
                font.pixelSize: 11
                wrapMode: Text.WordWrap
            }
        }
    }

    AppDialog {
        id: uploadResultDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 420)
        title: "Hasil Pengiriman"

        contentItem: ColumnLayout {
            spacing: 14

            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 76
                    radius: 12
                    color: "#F0FDF4"
                    border.color: "#BBF7D0"

                    Column {
                        anchors.centerIn: parent
                        spacing: 2

                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: plugin.uploadSuccessCount
                            color: "#166534"
                            font.pixelSize: 26
                            font.bold: true
                        }

                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: "Berhasil"
                            color: "#166534"
                            font.pixelSize: 12
                        }
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 76
                    radius: 12
                    color: plugin.uploadFailureCount > 0 ? "#FEF2F2" : "#F9FAFB"
                    border.color: plugin.uploadFailureCount > 0 ? "#FECACA" : "#E5E7EB"

                    Column {
                        anchors.centerIn: parent
                        spacing: 2

                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: plugin.uploadFailureCount
                            color: plugin.uploadFailureCount > 0 ? "#B91C1C" : "#6B7280"
                            font.pixelSize: 26
                            font.bold: true
                        }

                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: "Gagal"
                            color: plugin.uploadFailureCount > 0 ? "#B91C1C" : "#6B7280"
                            font.pixelSize: 12
                        }
                    }
                }
            }

            Label {
                Layout.fillWidth: true
                visible: plugin.uploadFailureCount > 0
                text: "Detail kegagalan (ID fitur dan penyebab):"
                color: "#991B1B"
                font.pixelSize: 12
                font.bold: true
                wrapMode: Text.WordWrap
            }

            ScrollView {
                Layout.fillWidth: true
                Layout.preferredHeight: plugin.uploadFailureCount > 0 ? Math.min(150, Math.max(48, failureDetailsLabel.implicitHeight + 12)) : 0
                visible: plugin.uploadFailureCount > 0
                clip: true

                Label {
                    id: failureDetailsLabel
                    width: uploadResultDialog.width - 64
                    text: plugin.uploadFailureDetails.join("\n\n")
                    color: "#7F1D1D"
                    font.pixelSize: 11
                    wrapMode: Text.WrapAnywhere
                }
            }

            Label {
                Layout.fillWidth: true
                visible: plugin.uploadFailureCount > 0
                text: "Periksa penyebab di atas. UUID otomatis dibuat untuk fitur yang belum memiliki UUID; UUID tersebut dikirim sebagai identitas dokumen dan properti."
                color: "#6B7280"
                font.pixelSize: 11
                wrapMode: Text.WordWrap
            }

            AppButton {
                Layout.fillWidth: true
                kind: "primary"
                text: "Selesai"
                onClicked: uploadResultDialog.close()
            }
        }
    }

    // =====================================================
    // DIALOG HASIL PEMERIKSAAN API
    // =====================================================

    AppDialog {
        id: debugDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 24, 520)
        height: Math.min(parent.height - 32, 540)

        title: "Pemeriksaan API QField"

        contentItem: ColumnLayout {
            spacing: 10

            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                radius: 10
                color: "#F9FAFB"
                border.color: "#E5E7EB"
                clip: true

                ScrollView {
                    anchors.fill: parent
                    anchors.margins: 4

                    TextArea {
                        readOnly: true
                        selectByMouse: true
                        wrapMode: TextEdit.Wrap
                        text: plugin.debugOutput
                        color: "#1F2937"
                        font.family: "monospace"
                        font.pixelSize: 12
                        background: null
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                Item {
                    Layout.fillWidth: true
                }

                AppButton {
                    text: "Tutup"
                    onClicked: debugDialog.close()
                }
            }
        }
    }

    // =====================================================
    // DIALOG DAFTAR BASE
    // =====================================================

    AppDialog {
        id: baseDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 420)
        height: Math.min(parent.height - 48, 540)

        title: "Tarik Base"

        contentItem: ColumnLayout {
            spacing: 8

            Label {
                Layout.fillWidth: true
                text: plugin.baseListMessage
                color: "#6B7280"
                font.pixelSize: 13
                wrapMode: Text.WordWrap
            }

            ListView {
                id: baseListView

                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                model: plugin.baseList
                boundsBehavior: Flickable.StopAtBounds

                ScrollBar.vertical: ScrollBar {
                    policy: ScrollBar.AsNeeded
                }

                delegate: Item {
                    id: baseRow

                    required property var modelData
                    required property int index

                    width: ListView.view.width
                    height: 64

                    Rectangle {
                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.bottom: parent.bottom
                        height: 1
                        color: "#F1F5F9"
                        visible: baseRow.index < baseListView.count - 1
                    }

                    RowLayout {
                        anchors.fill: parent
                        anchors.rightMargin: 4
                        spacing: 12

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 2

                            Label {
                                Layout.fillWidth: true
                                text: baseRow.modelData.layerName
                                color: "#111827"
                                font.pixelSize: 14
                                font.weight: Font.DemiBold
                                elide: Text.ElideRight
                            }

                            Label {
                                Layout.fillWidth: true
                                text: baseRow.modelData.featureCount + " fitur  ·  "
                                      + baseRow.modelData.geometryType
                                      + (baseRow.modelData.inProject
                                         ? "  ·  → " + baseRow.modelData.targetName
                                         : "  ·  layer tidak ada di proyek")
                                color: baseRow.modelData.inProject ? "#9CA3AF" : "#B91C1C"
                                font.pixelSize: 11
                                elide: Text.ElideRight
                            }
                        }

                        AppButton {
                            compact: true
                            kind: "primary"
                            text: "Tarik"
                            enabled: baseRow.modelData.inProject && !plugin.pullBusy

                            onClicked: {
                                plugin.pendingBase = baseRow.modelData
                                pullConfirmDialog.open()
                            }
                        }
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                Item {
                    Layout.fillWidth: true
                }

                AppButton {
                    text: "Tutup"
                    onClicked: baseDialog.close()
                }
            }
        }
    }

    AppDialog {
        id: pullConfirmDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 400)
        title: "Tarik base?"

        contentItem: ColumnLayout {
            spacing: 12

            Label {
                Layout.fillWidth: true
                text: plugin.pendingBase
                      ? ("Base '" + plugin.pendingBase.layerName + "' akan dimasukkan ke layer '"
                         + plugin.pendingBase.targetName + "' di GeoPackage QField.\n\n"
                         + "• Feature yang uuid-nya belum ada akan ditambahkan.\n"
                         + "• Feature yang uuid-nya sudah ada akan diperbarui atributnya. "
                         + "Geometrinya tidak diubah.\n"
                         + "• Feature lain di layer QField tidak dihapus.")
                      : ""
                color: "#374151"
                font.pixelSize: 13
                wrapMode: Text.WordWrap
            }

            RowLayout {
                Layout.fillWidth: true

                Item {
                    Layout.fillWidth: true
                }

                AppButton {
                    text: "Batal"
                    onClicked: pullConfirmDialog.close()
                }

                AppButton {
                    kind: "primary"
                    text: "Tarik sekarang"
                    onClicked: {
                        var chosen = plugin.pendingBase
                        pullConfirmDialog.close()
                        baseDialog.close()
                        if (chosen)
                            plugin.startPullBase(chosen)
                    }
                }
            }
        }
    }

    AppDialog {
        id: pullResultDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 24, 480)
        height: Math.min(parent.height - 32, 460)

        title: plugin.pullBusy ? "Menarik base..." : "Hasil Tarik Base"

        contentItem: ColumnLayout {
            spacing: 10

            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                radius: 10
                color: "#F9FAFB"
                border.color: "#E5E7EB"
                clip: true

                ScrollView {
                    anchors.fill: parent
                    anchors.margins: 4

                    TextArea {
                        readOnly: true
                        selectByMouse: true
                        wrapMode: TextEdit.Wrap
                        text: plugin.pullOutput
                        color: "#1F2937"
                        font.family: "monospace"
                        font.pixelSize: 12
                        background: null
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                Item {
                    Layout.fillWidth: true
                }

                AppButton {
                    text: "Tutup"
                    enabled: !plugin.pullBusy
                    onClicked: pullResultDialog.close()
                }
            }
        }
    }

    // =====================================================
    // DIALOG LOGIN
    // =====================================================

    LoginDialog {
        id: loginDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        projectId: "webgis-sctk"
        apiKey: plugin.firebaseApiKey
        loading: plugin.isLoggingIn
        errorMessage: plugin.loginError

        onLoginRequested: function(projectId, apiKey, email, password) {
            plugin.firebaseApiKey = apiKey
            loginSettings.savedApiKey = apiKey
            plugin.loginError = ""
            plugin.isLoggingIn = true

            firebaseAuth.apiKey = apiKey
            firebaseAuth.login(email, password)
        }
    }

    // =====================================================
    // DIALOG AKUN
    // =====================================================

    AppDialog {
        id: accountDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 340)
        title: "Akun SCTK Sync"

        contentItem: ColumnLayout {
            spacing: 14

            RowLayout {
                Layout.fillWidth: true
                spacing: 12

                Rectangle {
                    Layout.preferredWidth: 40
                    Layout.preferredHeight: 40
                    radius: 20
                    color: "#DCFCE7"

                    Label {
                        anchors.centerIn: parent
                        text: plugin.activeUser.length > 0 ? plugin.activeUser.charAt(0).toUpperCase() : "?"
                        color: "#166534"
                        font.pixelSize: 16
                        font.bold: true
                    }
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2

                    Label {
                        text: "Login sebagai"
                        color: "#6B7280"
                        font.pixelSize: 12
                    }

                    Label {
                        Layout.fillWidth: true
                        text: plugin.activeUser
                        color: "#111827"
                        font.pixelSize: 14
                        font.weight: Font.DemiBold
                        elide: Text.ElideMiddle
                    }
                }
            }

            AppButton {
                Layout.fillWidth: true
                kind: "danger"
                text: "Logout"

                onClicked: {
                    plugin.logoutFirebase()
                    accountDialog.close()
                }
            }
        }
    }
}
