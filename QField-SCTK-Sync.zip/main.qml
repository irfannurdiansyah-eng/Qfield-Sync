
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import org.qfield
import org.qfield.core

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var availableLayers: []
    property string layerListMessage: "Tekan tombol untuk memuat layer."
    property string featureCheckOutput: "Pilih layer lalu ketuk Cek fitur."
    property var attributeHeaders: []
    property var attributeRows: []
    property string attributeLayerName: ""
    property string attributeLayerId: ""
    property int attributeFeatureCount: 0
    // Semua fitur dimuat; ListView hanya membuat delegate yang terlihat.
    property int sortColumn: -1
    property bool sortAscending: true
    property var selectedFeatureIds: []
    property var featurePayloads: []
    property var uploadQueue: []
    property int uploadQueueIndex: 0
    property int uploadSuccessCount: 0
    property int uploadFailureCount: 0
    property string uploadSurveyDate: ""
    property string debugOutput: "Tekan Cek API untuk memeriksa API."

    // Firebase Authentication
    property string firebaseApiKey: "ISI_WEB_API_KEY_FIREBASE"
    property string activeUser: "Belum login"
    property string connectionStatus: "Belum terhubung"
    property string idToken: ""
    property string refreshToken: ""
    property string loginError: ""
    property bool isLoggingIn: false

    Settings {
        id: loginSettings
        category: "SCTKSync"

        property string savedEmail: ""
        property string savedRefreshToken: ""
        property string savedApiKey: ""
    }

    // =====================================================
    // PEMERIKSAAN API QFIELD
    // =====================================================

    function debugQFieldApi() {
        var result = "=== QFIELD LAYER API CHECK ===\n"

        try {
            result += "iface: " + typeof iface + "\n"
            result += "iface.mapCanvas: " + typeof iface.mapCanvas + "\n"

            var canvas = iface.mapCanvas()
            var settings = canvas.mapSettings
            var layers = settings.layers

            result += "mapSettings: " + typeof settings + "\n"
            result += "settings.layers: " + typeof layers + "\n"

            if (layers !== undefined && layers !== null) {
                result += "Jumlah layer: " + layers.length + "\n"

                for (var i = 0; i < layers.length; i++) {
                    var item = layers[i]

                    result += (i + 1) + ". " +
                        (item && item.name !== undefined
                            ? String(item.name)
                            : "(nama tidak tersedia)") +
                        " | ID: " +
                        (item && item.id !== undefined
                            ? String(item.id)
                            : "(ID tidak tersedia)") + "\n"
                }
            }
        } catch (error) {
            result += "\nERROR: " + String(error)
        }

        plugin.debugOutput = result
        debugDialog.open()
        console.log(result)
    }

    // =====================================================
    // PEMERIKSAAN FITUR DAN ATRIBUT
    // =====================================================


    function formatFeatureValue(value) {
        if (value === null || value === undefined || String(value) === "")
            return "—"
        if (value === true || String(value) === "true")
            return "Ya"
        if (value === false || String(value) === "false")
            return "Tidak"
        return String(value)
    }

    function sortAttributeRows(columnIndex) {
        if (plugin.sortColumn === columnIndex)
            plugin.sortAscending = !plugin.sortAscending
        else {
            plugin.sortColumn = columnIndex
            plugin.sortAscending = true
        }

        var sorted = plugin.attributeRows.slice(0)
        sorted.sort(function(a, b) {
            var av = String(a[columnIndex])
            var bv = String(b[columnIndex])
            var an = Number(av)
            var bn = Number(bv)
            var numeric = av.trim() !== "" && bv.trim() !== "" &&
                          !isNaN(an) && !isNaN(bn)
            var cmp = numeric ? (an < bn ? -1 : (an > bn ? 1 : 0))
                              : av.toLowerCase().localeCompare(bv.toLowerCase())
            return plugin.sortAscending ? cmp : -cmp
        })
        plugin.attributeRows = sorted
    }

    function isFeatureSelected(featureId) {
        return plugin.selectedFeatureIds.indexOf(String(featureId)) !== -1
    }

    function setFeatureSelected(featureId, checked) {
        var id = String(featureId)
        var selected = plugin.selectedFeatureIds.slice(0)
        var pos = selected.indexOf(id)
        if (checked && pos < 0)
            selected.push(id)
        else if (!checked && pos >= 0)
            selected.splice(pos, 1)
        plugin.selectedFeatureIds = selected
    }

    function findFeaturePayload(featureId) {
        var target = String(featureId)
        for (var i = 0; i < plugin.featurePayloads.length; i++) {
            if (String(plugin.featurePayloads[i].rowId) === target)
                return plugin.featurePayloads[i]
        }
        return null
    }

    function buildSelectedUploadQueue() {
        var selected = plugin.selectedFeatureIds.slice(0)
        var queue = []
        var layer = null
        var layers = iface.mapCanvas().mapSettings.layers
        for (var i = 0; i < layers.length; i++) {
            if (String(layers[i].id) === String(plugin.attributeLayerId)) {
                layer = layers[i]
                break
            }
        }
        if (layer === null)
            throw new Error("Layer tidak ditemukan. Tutup tabel lalu buka kembali.")

        // Hanya ambil geometri fitur yang dipilih. Satu kali scan untuk semua pilihan.
        var wanted = {}
        for (var w = 0; w < selected.length; w++)
            wanted[String(selected[w])] = true
        var iterator = LayerUtils.createFeatureIterator(layer)
        while (iterator.hasNext() && Object.keys(wanted).length > 0) {
            var feature = iterator.next()
            var rowId = String(feature.id)
            if (!wanted[rowId])
                continue
            var payload = plugin.findFeaturePayload(rowId)
            if (payload !== null) {
                var currentAttributes = {}
                var fieldNames = layer.fields.names
                for (var a = 0; a < fieldNames.length; a++) {
                    var fieldName = String(fieldNames[a])
                    var fieldValue = null
                    try { fieldValue = feature.attribute(fieldName) } catch (attributeError) { fieldValue = null }
                    currentAttributes[fieldName] = fieldValue === undefined ? null : fieldValue
                }
                payload.attributes = currentAttributes
                var geom = feature.geometry
                var wkt = ""
                if (geom !== undefined && geom !== null && typeof geom.asWkt === "function")
                    wkt = String(geom.asWkt())
                var geometryType = "Unknown"
                if (geom !== undefined && geom !== null) {
                    var typeNumber = Number(geom.type)
                    geometryType = typeNumber === 0 ? "Point" :
                                   (typeNumber === 1 ? "LineString" :
                                   (typeNumber === 2 ? "Polygon" : "Unknown"))
                }
                payload.geometry = {
                    type: geometryType,
                    wkt: wkt,
                    crs: (layer.crs && layer.crs.authid !== undefined) ? String(layer.crs.authid) : ""
                }
                queue.push(payload)
                delete wanted[rowId]
            }
        }
        return queue
    }

    function startSelectedUpload() {
        if (plugin.idToken === "") {
            mainWindow.displayToast("Silakan login terlebih dahulu.")
            return
        }
        if (plugin.selectedFeatureIds.length === 0) {
            mainWindow.displayToast("Centang minimal satu fitur.")
            return
        }

        var queue = []
        try {
            queue = plugin.buildSelectedUploadQueue()
        } catch (queueError) {
            mainWindow.displayToast("Gagal menyiapkan fitur: " + String(queueError.message || queueError))
            return
        }

        if (queue.length === 0) {
            mainWindow.displayToast("Data fitur terpilih tidak ditemukan. Buka ulang tabel atribut.")
            return
        }

        plugin.uploadQueue = queue
        plugin.uploadQueueIndex = 0
        plugin.uploadSuccessCount = 0
        plugin.uploadFailureCount = 0
        sendSelectionDialog.close()
        uploadProgressDialog.open()
        plugin.uploadNextFeature()
    }

    function uploadNextFeature() {
        if (plugin.uploadQueueIndex >= plugin.uploadQueue.length) {
            uploadProgressDialog.close()
            uploadResultDialog.open()
            return
        }

        var item = plugin.uploadQueue[plugin.uploadQueueIndex]
        uploadProgressText.text = "Mengirim " + (plugin.uploadQueueIndex + 1) +
                                  " dari " + plugin.uploadQueue.length +
                                  "\nLayer: " + plugin.attributeLayerName
        firestoreApi.uploadSurvey(
            item.documentId,
            item.featureUuid,
            plugin.attributeLayerId,
            plugin.attributeLayerName,
            item.geometry,
            item.attributes,
            plugin.activeUser,
            item.surveyDate
        )
    }

    function inspectLayer(layerId) {
        featureCheckDialog.open()
        plugin.featureCheckOutput = "Memuat atribut layer..."
        plugin.attributeHeaders = []
        plugin.attributeRows = []
        plugin.attributeLayerName = ""
        plugin.attributeLayerId = ""
        plugin.attributeFeatureCount = 0
        plugin.featurePayloads = []
        plugin.sortColumn = -1
        plugin.sortAscending = true
        plugin.selectedFeatureIds = []

        try {
            var layers = iface.mapCanvas().mapSettings.layers
            var layer = null
            for (var i = 0; i < layers.length; i++) {
                if (String(layers[i].id) === String(layerId)) {
                    layer = layers[i]
                    break
                }
            }

            if (layer === null) {
                plugin.featureCheckOutput = "Layer tidak ditemukan."
                return
            }

            var names = layer.fields.names
            var headers = ["ID_FITUR"]
            for (var h = 0; h < names.length; h++)
                headers.push(String(names[h]))

            var iterator = LayerUtils.createFeatureIterator(layer)
            var rows = []
            var payloads = []
            while (iterator.hasNext()) {
                var feature = iterator.next()
                var rowId = String(feature.id)
                var row = [rowId]
                var featureUuid = rowId
                var surveyDate = ""

                for (var j = 0; j < names.length; j++) {
                    var fieldName = String(names[j])
                    var rawValue = null
                    try {
                        rawValue = feature.attribute(fieldName)
                    } catch (attributeError) {
                        rawValue = null
                    }
                    row.push(formatFeatureValue(rawValue))
                    var lowerName = fieldName.toLowerCase()
                    if ((lowerName === "uuid" || lowerName === "feature_uuid") &&
                        rawValue !== null && rawValue !== undefined &&
                        String(rawValue).trim() !== "") {
                        featureUuid = String(rawValue).replace(/^\\{|\\}$/g, "")
                    }
                    if ((lowerName === "survey_date" || lowerName === "tanggal_survei" ||
                         lowerName === "tanggal_survey" || lowerName === "tanggal") &&
                        rawValue !== null && rawValue !== undefined &&
                        String(rawValue).trim() !== "") {
                        surveyDate = String(rawValue)
                    }
                }

                // Jangan konversi geometri ke WKT untuk semua fitur saat tabel dibuka.
                // Ini operasi yang relatif berat pada layer besar/perangkat HP.
                // Geometri baru dibaca untuk fitur yang benar-benar dipilih saat upload.
                var geometryObject = null

                rows.push(row)
                payloads.push({
                    "rowId": rowId,
                    "featureUuid": featureUuid,
                    "documentId": featureUuid,
                    // Atribut lengkap dibaca ulang hanya untuk fitur yang dikirim.
                    "geometry": geometryObject,
                    "surveyDate": surveyDate
                })
            }

            plugin.attributeLayerName = String(layer.name)
            plugin.attributeLayerId = String(layer.id)
            plugin.attributeFeatureCount = rows.length
            plugin.attributeHeaders = headers
            plugin.attributeRows = rows
            plugin.featurePayloads = payloads
            plugin.featureCheckOutput = rows.length === 0
                ? "Layer ini belum memiliki fitur."
                : rows.length + " fitur tersedia. Tabel dirender bertahap agar lebih ringan."
        } catch (error) {
            plugin.featureCheckOutput = "Gagal membaca tabel atribut: " + String(error)
        }
        console.log("Tabel atribut layer selesai dibaca.")
    }

    // =====================================================
    // DAFTAR LAYER
    // =====================================================

    function refreshLayerList() {
        var rows = []

        try {
            var canvas = iface.mapCanvas()
            var layers = canvas.mapSettings.layers

            if (layers !== undefined && layers !== null) {
                for (var i = 0; i < layers.length; i++) {
                    var layer = layers[i]
                    var layerName = "Layer " + (i + 1)
                    var layerId = ""

                    try {
                        if (layer && layer.name !== undefined) {
                            layerName = String(layer.name)
                        }
                    } catch (nameError) {
                    }

                    try {
                        if (layer && layer.id !== undefined) {
                            layerId = String(layer.id)
                        }
                    } catch (idError) {
                    }

                    rows.push({
                        "name": layerName,
                        "id": layerId
                    })
                }
            }

            plugin.availableLayers = rows
            plugin.layerListMessage = rows.length > 0
                ? "Ditemukan " + rows.length +
                    " layer pada map canvas."
                : "Tidak ada layer yang ditemukan."
        } catch (error) {
            plugin.availableLayers = []
            plugin.layerListMessage =
                "Gagal membaca layer: " + String(error)
        }

        layerDialog.open()
    }

    // =====================================================
    // FIREBASE AUTHENTICATION
    // =====================================================

    FirebaseAuth {
        id: firebaseAuth
        apiKey: plugin.firebaseApiKey

        onLoginSucceeded: function(email, token, refresh) {
            plugin.isLoggingIn = false
            plugin.idToken = token
            plugin.refreshToken = refresh

            loginSettings.savedEmail = email
            loginSettings.savedRefreshToken = refresh

            plugin.activeUser = email
            plugin.connectionStatus = "Login berhasil"
            plugin.loginError = ""

            loginDialog.close()
            mainWindow.displayToast("Login berhasil")
        }

        onLoginFailed: function(message) {
            plugin.isLoggingIn = false
            plugin.loginError = message
        }

        onTokenRefreshed: function(token, refresh) {
            plugin.idToken = token
            plugin.refreshToken = refresh
            plugin.activeUser = loginSettings.savedEmail
            plugin.connectionStatus = "Login berhasil"
            plugin.loginError = ""

            loginSettings.savedRefreshToken = refresh

            mainWindow.displayToast(
                "Sesi login berhasil dipulihkan"
            )
        }

        onRefreshFailed: function(message) {
            plugin.idToken = ""
            plugin.refreshToken = ""
            plugin.activeUser = "Belum login"
            plugin.connectionStatus =
                "Sesi berakhir, silakan login"
            plugin.loginError = message

            loginSettings.savedRefreshToken = ""
        }
    }

    // =====================================================
    // FIRESTORE API
    // =====================================================

    FirestoreApi {
        id: firestoreApi

        projectId: "webgis-sctk"
        projectDocumentId: "fc98b8f1-78d5-456f-b76a-8ebb3b4b4160"
        idToken: plugin.idToken

        onUploadSucceeded: function(featureId) {
            plugin.uploadSuccessCount += 1
            plugin.uploadQueueIndex += 1
            plugin.uploadNextFeature()
        }

        onUploadFailed: function(message) {
            plugin.uploadFailureCount += 1
            console.log("Upload gagal untuk " + message)
            plugin.uploadQueueIndex += 1
            plugin.uploadNextFeature()
        }
    }

    // =====================================================
    // INISIALISASI
    // =====================================================

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(openDashboardButton)

        if (loginSettings.savedApiKey !== "") {
            plugin.firebaseApiKey = loginSettings.savedApiKey
            firebaseAuth.apiKey = loginSettings.savedApiKey
        }

        if (loginSettings.savedRefreshToken !== "") {
            plugin.activeUser = loginSettings.savedEmail
            plugin.connectionStatus = "Memulihkan sesi login..."

            firebaseAuth.refreshIdToken(
                loginSettings.savedRefreshToken
            )
        }

        mainWindow.displayToast(
            "QField SCTK Sync siap digunakan"
        )
    }

    // =====================================================
    // LOGOUT
    // =====================================================

    function logoutFirebase() {
        plugin.idToken = ""
        plugin.refreshToken = ""
        plugin.activeUser = "Belum login"
        plugin.connectionStatus = "Belum terhubung"
        plugin.loginError = ""
        plugin.isLoggingIn = false

        loginSettings.savedEmail = ""
        loginSettings.savedRefreshToken = ""
        loginSettings.savedApiKey = ""

        plugin.firebaseApiKey = ""
        firebaseAuth.apiKey = ""

        mainWindow.displayToast("Logout berhasil")
    }

    // =====================================================
    // KOMPONEN UI (inline, tidak menambah file baru)
    // Palet: netral + satu aksen hijau.
    //   Aksen #166534 | Teks #111827 | Teks redup #6B7280
    //   Garis #E5E7EB | Permukaan #F9FAFB | Bahaya #B91C1C
    // =====================================================

    component AppButton: Button {
        id: appBtn

        // kind: "primary" | "secondary" | "ghost" | "danger"
        property string kind: "secondary"
        property bool compact: false

        implicitHeight: compact ? 36 : 44
        leftPadding: compact ? 14 : 18
        rightPadding: compact ? 14 : 18
        font.pixelSize: compact ? 13 : 14
        font.weight: Font.Medium
        font.capitalization: Font.MixedCase
        opacity: enabled ? 1.0 : 0.4

        contentItem: Text {
            text: appBtn.text
            font: appBtn.font
            elide: Text.ElideRight
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            color: appBtn.kind === "primary" ? "#FFFFFF"
                 : appBtn.kind === "danger" ? "#B91C1C"
                 : appBtn.kind === "ghost" ? "#166534"
                 : "#111827"
        }

        background: Rectangle {
            radius: 8
            color: appBtn.kind === "primary"
                   ? (appBtn.down ? "#14532D" : "#166534")
                   : appBtn.kind === "danger"
                     ? (appBtn.down ? "#FEE2E2" : "#FFFFFF")
                     : appBtn.kind === "ghost"
                       ? (appBtn.down ? "#F0FDF4" : "transparent")
                       : (appBtn.down ? "#F3F4F6" : "#FFFFFF")
            border.width: (appBtn.kind === "secondary" || appBtn.kind === "danger") ? 1 : 0
            border.color: appBtn.kind === "danger" ? "#FECACA" : "#D1D5DB"
        }
    }

    component AppDialog: Dialog {
        id: appDlg

        property bool showClose: true

        modal: true
        standardButtons: Dialog.NoButton
        padding: 16
        topPadding: 12

        Overlay.modal: Rectangle {
            color: "#66000000"
        }

        background: Rectangle {
            color: "#FFFFFF"
            radius: 16
            border.color: "#E5E7EB"
        }

        header: Item {
            implicitHeight: 56

            Label {
                anchors.left: parent.left
                anchors.leftMargin: 20
                anchors.right: closeButton.left
                anchors.rightMargin: 8
                anchors.verticalCenter: parent.verticalCenter
                text: appDlg.title
                color: "#111827"
                font.pixelSize: 17
                font.weight: Font.DemiBold
                elide: Text.ElideRight
            }

            ToolButton {
                id: closeButton
                visible: appDlg.showClose
                anchors.right: parent.right
                anchors.rightMargin: 8
                anchors.verticalCenter: parent.verticalCenter
                text: "✕"
                font.pixelSize: 16
                onClicked: appDlg.close()
            }

            Rectangle {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                height: 1
                color: "#F1F5F9"
            }
        }
    }

    // =====================================================
    // TOMBOL TOOLBAR
    // =====================================================

    Button {
        id: openDashboardButton

        text: "SCTK"
        width: 48
        height: 48
        font.pixelSize: 11
        font.bold: true
        font.capitalization: Font.MixedCase

        contentItem: Text {
            text: openDashboardButton.text
            font: openDashboardButton.font
            color: "#FFFFFF"
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
        }

        background: Rectangle {
            radius: width / 2
            color: openDashboardButton.down ? "#14532D" : "#166534"
        }

        onClicked: dashboard.open()
    }

    // =====================================================
    // DASHBOARD
    // =====================================================

    AppDialog {
        id: dashboard

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 24, 420)
        height: Math.min(parent.height - 32, 440)

        title: "QField SCTK Sync"

        contentItem: Flickable {
            clip: true
            contentWidth: width
            contentHeight: dashboardColumn.implicitHeight
            boundsBehavior: Flickable.StopAtBounds

            ColumnLayout {
                id: dashboardColumn

                width: parent.width
                spacing: 12

                // Akun & status koneksi
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: accountRow.implicitHeight + 32
                    radius: 12
                    color: "#F9FAFB"
                    border.color: "#E5E7EB"

                    RowLayout {
                        id: accountRow

                        anchors.fill: parent
                        anchors.margins: 16
                        spacing: 12

                        Rectangle {
                            Layout.preferredWidth: 40
                            Layout.preferredHeight: 40
                            radius: 20
                            color: plugin.idToken !== "" ? "#DCFCE7" : "#E5E7EB"

                            Label {
                                anchors.centerIn: parent
                                text: plugin.idToken !== "" && plugin.activeUser.length > 0
                                      ? plugin.activeUser.charAt(0).toUpperCase() : "?"
                                color: plugin.idToken !== "" ? "#166534" : "#6B7280"
                                font.pixelSize: 16
                                font.bold: true
                            }
                        }

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 3

                            Label {
                                Layout.fillWidth: true
                                text: plugin.activeUser
                                color: "#111827"
                                font.pixelSize: 14
                                font.weight: Font.DemiBold
                                elide: Text.ElideMiddle
                            }

                            RowLayout {
                                Layout.fillWidth: true
                                spacing: 6

                                Rectangle {
                                    Layout.preferredWidth: 8
                                    Layout.preferredHeight: 8
                                    Layout.alignment: Qt.AlignVCenter
                                    radius: 4
                                    color: plugin.idToken !== "" ? "#16A34A" : "#D97706"
                                }

                                Label {
                                    Layout.fillWidth: true
                                    text: plugin.connectionStatus
                                    color: "#6B7280"
                                    font.pixelSize: 12
                                    elide: Text.ElideRight
                                }
                            }
                        }

                        AppButton {
                            compact: true
                            kind: plugin.idToken === "" ? "primary" : "secondary"
                            text: plugin.idToken === "" ? "Login" : "Akun"

                            onClicked: {
                                if (plugin.idToken === "") {
                                    plugin.loginError = ""
                                    loginDialog.open()
                                } else {
                                    accountDialog.open()
                                }
                            }
                        }
                    }
                }

                // Survei
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: surveyColumn.implicitHeight + 32
                    radius: 12
                    color: "#FFFFFF"
                    border.color: "#E5E7EB"

                    ColumnLayout {
                        id: surveyColumn

                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.top: parent.top
                        anchors.margins: 16
                        spacing: 6

                        Label {
                            text: "Survei QField"
                            color: "#111827"
                            font.pixelSize: 15
                            font.weight: Font.DemiBold
                        }

                        Label {
                            Layout.fillWidth: true
                            text: "Lihat layer proyek dan siapkan hasil survei untuk dikirim ke Firebase."
                            color: "#6B7280"
                            font.pixelSize: 13
                            wrapMode: Text.WordWrap
                        }

                        AppButton {
                            Layout.fillWidth: true
                            Layout.topMargin: 8
                            kind: "primary"
                            text: "Lihat daftar layer"
                            onClicked: plugin.refreshLayerList()
                        }
                    }
                }

                Label {
                    Layout.fillWidth: true
                    Layout.topMargin: 2
                    text: "Proyek  ·  " + firestoreApi.projectId
                    color: "#9CA3AF"
                    font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                    elide: Text.ElideMiddle
                }
            }
        }
    }

    // =====================================================
    // DIALOG DAFTAR LAYER
    // =====================================================

    AppDialog {
        id: layerDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 420)
        height: Math.min(parent.height - 48, 540)

        title: "Daftar Layer"

        contentItem: ColumnLayout {
            spacing: 8

            Label {
                Layout.fillWidth: true
                text: plugin.layerListMessage
                color: "#6B7280"
                font.pixelSize: 13
                wrapMode: Text.WordWrap
            }

            ListView {
                id: layerList

                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                model: plugin.availableLayers
                boundsBehavior: Flickable.StopAtBounds

                ScrollBar.vertical: ScrollBar {
                    policy: ScrollBar.AsNeeded
                }

                delegate: Item {
                    id: layerRow

                    required property var modelData
                    required property int index

                    width: ListView.view.width
                    height: 64

                    Rectangle {
                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.bottom: parent.bottom
                        height: 1
                        color: "#F1F5F9"
                        visible: layerRow.index < layerList.count - 1
                    }

                    RowLayout {
                        anchors.fill: parent
                        anchors.rightMargin: 4
                        spacing: 12

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 2

                            Label {
                                Layout.fillWidth: true
                                text: layerRow.modelData.name
                                color: "#111827"
                                font.pixelSize: 14
                                font.weight: Font.DemiBold
                                elide: Text.ElideRight
                            }

                            Label {
                                Layout.fillWidth: true
                                text: layerRow.modelData.id !== ""
                                      ? layerRow.modelData.id
                                      : "ID layer tidak tersedia"
                                color: "#9CA3AF"
                                font.pixelSize: 10
                                elide: Text.ElideMiddle
                            }
                        }

                        AppButton {
                            compact: true
                            text: "Cek fitur"

                            onClicked: {
                                try {
                                    var chosenLayerId = layerRow.modelData.id
                                    layerDialog.close()
                                    plugin.inspectLayer(chosenLayerId)
                                } catch (error) {
                                    plugin.featureCheckOutput =
                                        "ERROR TOMBOL CEK FITUR: " + String(error)
                                    featureCheckDialog.open()
                                }
                            }
                        }
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                AppButton {
                    compact: true
                    kind: "ghost"
                    text: "Cek API"
                    onClicked: {
                        layerDialog.close()
                        plugin.debugQFieldApi()
                    }
                }

                Item {
                    Layout.fillWidth: true
                }
            }
        }
    }

    // =====================================================
    // DIALOG TABEL ATRIBUT QFIELD
    // =====================================================

    AppDialog {
        id: featureCheckDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.max(260, Math.min(parent.width - 24, 1040))
        height: Math.max(300, Math.min(parent.height - 24, 780))

        title: "Tabel Atribut"

        contentItem: ColumnLayout {
            spacing: 10

            // Ringkasan layer
            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2

                    Label {
                        Layout.fillWidth: true
                        text: plugin.attributeLayerName
                        color: "#111827"
                        font.pixelSize: 15
                        font.weight: Font.DemiBold
                        elide: Text.ElideRight
                    }

                    Label {
                        Layout.fillWidth: true
                        text: plugin.attributeFeatureCount + " fitur  ·  " +
                              plugin.attributeHeaders.length + " kolom"
                        color: "#6B7280"
                        font.pixelSize: 12
                        elide: Text.ElideRight
                    }
                }

                Rectangle {
                    Layout.preferredWidth: selectedChipLabel.implicitWidth + 24
                    Layout.preferredHeight: 28
                    radius: 14
                    color: plugin.selectedFeatureIds.length > 0 ? "#DCFCE7" : "#F3F4F6"

                    Label {
                        id: selectedChipLabel
                        anchors.centerIn: parent
                        text: plugin.selectedFeatureIds.length + " dipilih"
                        color: plugin.selectedFeatureIds.length > 0 ? "#166534" : "#6B7280"
                        font.pixelSize: 12
                        font.weight: Font.DemiBold
                    }
                }
            }

            Label {
                Layout.fillWidth: true
                text: plugin.featureCheckOutput
                visible: plugin.featureCheckOutput !== ""
                color: "#6B7280"
                font.pixelSize: 12
                wrapMode: Text.WordWrap
            }

            // Tabel
            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                radius: 8
                color: "#FFFFFF"
                border.color: "#E5E7EB"
                clip: true

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 1
                    spacing: 0

                    // Header terpisah dari isi agar tetap terlihat saat scroll vertikal.
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 40
                        color: "#F3F4F6"

                        Flickable {
                            id: attributeHeaderFlick

                            anchors.fill: parent
                            clip: true
                            contentWidth: Math.max(width, 44 + plugin.attributeHeaders.length * 136)
                            contentHeight: height
                            interactive: false
                            boundsBehavior: Flickable.StopAtBounds

                            Row {
                                height: 40
                                spacing: 0

                                Item {
                                    width: 44
                                    height: 40

                                    Text {
                                        anchors.centerIn: parent
                                        text: "Pilih"
                                        color: "#374151"
                                        font.bold: true
                                        font.pixelSize: 11
                                    }
                                }

                                Repeater {
                                    model: plugin.attributeHeaders

                                    delegate: Item {
                                        required property var modelData
                                        required property int index

                                        width: 136
                                        height: 40

                                        Button {
                                            anchors.fill: parent
                                            flat: true
                                            padding: 8
                                            text: String(modelData) +
                                                  (plugin.sortColumn === index
                                                   ? (plugin.sortAscending ? "  ▲" : "  ▼") : "")

                                            contentItem: Text {
                                                text: parent.text
                                                color: plugin.sortColumn === index ? "#166534" : "#374151"
                                                font.bold: true
                                                font.pixelSize: 11
                                                font.capitalization: Font.MixedCase
                                                verticalAlignment: Text.AlignVCenter
                                                horizontalAlignment: Text.AlignLeft
                                                elide: Text.ElideRight
                                            }

                                            background: Rectangle {
                                                color: parent.down ? "#E5E7EB" : "transparent"
                                            }

                                            onClicked: plugin.sortAttributeRows(index)
                                        }
                                    }
                                }
                            }
                        }

                        Rectangle {
                            anchors.left: parent.left
                            anchors.right: parent.right
                            anchors.bottom: parent.bottom
                            height: 1
                            color: "#E5E7EB"
                        }
                    }

                    Item {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true

                        Flickable {
                            id: attributeBodyFlick

                            anchors.fill: parent
                            clip: true
                            contentWidth: Math.max(width, 44 + plugin.attributeHeaders.length * 136)
                            contentHeight: height
                            boundsBehavior: Flickable.StopAtBounds
                            flickableDirection: Flickable.HorizontalFlick
                            onContentXChanged: attributeHeaderFlick.contentX = contentX

                            ListView {
                                id: attributeRowsList

                                x: 0
                                y: 0
                                width: attributeBodyFlick.contentWidth
                                height: attributeBodyFlick.height
                                clip: true
                                model: plugin.attributeRows
                                boundsBehavior: Flickable.StopAtBounds
                                reuseItems: true
                                cacheBuffer: 0
                                spacing: 0

                                delegate: Item {
                                    id: tableRow

                                    required property var modelData

                                    readonly property bool picked: plugin.isFeatureSelected(modelData[0])

                                    width: attributeBodyFlick.contentWidth
                                    height: 40

                                    Rectangle {
                                        anchors.fill: parent
                                        color: tableRow.picked ? "#F0FDF4" : "transparent"
                                    }

                                    Rectangle {
                                        anchors.left: parent.left
                                        anchors.right: parent.right
                                        anchors.bottom: parent.bottom
                                        height: 1
                                        color: "#F1F5F9"
                                    }

                                    Row {
                                        anchors.fill: parent
                                        spacing: 0

                                        Item {
                                            width: 44
                                            height: 40

                                            CheckBox {
                                                anchors.centerIn: parent
                                                checked: tableRow.picked
                                                onToggled: plugin.setFeatureSelected(tableRow.modelData[0], checked)
                                            }
                                        }

                                        Repeater {
                                            model: tableRow.modelData

                                            delegate: Item {
                                                required property var modelData
                                                required property int index

                                                width: 136
                                                height: 40

                                                Text {
                                                    anchors.fill: parent
                                                    anchors.leftMargin: 8
                                                    anchors.rightMargin: 8
                                                    text: String(modelData)
                                                    color: index === 0 ? "#6B7280" : "#1F2937"
                                                    font.pixelSize: 12
                                                    verticalAlignment: Text.AlignVCenter
                                                    elide: Text.ElideRight
                                                }
                                            }
                                        }
                                    }
                                }

                                ScrollBar.vertical: ScrollBar {
                                    policy: ScrollBar.AsNeeded
                                    width: 10
                                    minimumSize: 0.08
                                }
                            }

                            ScrollBar.horizontal: ScrollBar {
                                policy: ScrollBar.AsNeeded
                                height: 10
                                minimumSize: 0.08
                            }
                        }
                    }
                }
            }

            Label {
                Layout.fillWidth: true
                text: plugin.idToken === ""
                      ? "Login diperlukan untuk mengirim data."
                      : "Geser ke samping untuk kolom lain. Ketuk judul kolom untuk mengurutkan."
                color: "#9CA3AF"
                font.pixelSize: 11
                wrapMode: Text.WordWrap
            }

            // Aksi
            RowLayout {
                Layout.fillWidth: true
                spacing: 6

                AppButton {
                    compact: true
                    kind: "ghost"
                    text: "Pilih semua"
                    onClicked: {
                        var ids = []
                        for (var i = 0; i < plugin.attributeRows.length; i++)
                            ids.push(String(plugin.attributeRows[i][0]))
                        plugin.selectedFeatureIds = ids
                    }
                }

                AppButton {
                    compact: true
                    kind: "ghost"
                    text: "Batal pilih"
                    onClicked: plugin.selectedFeatureIds = []
                }

                Item {
                    Layout.fillWidth: true
                }

                AppButton {
                    kind: "primary"
                    text: "Kirim (" + plugin.selectedFeatureIds.length + ")"
                    enabled: plugin.selectedFeatureIds.length > 0 && plugin.idToken !== ""
                    onClicked: sendSelectionDialog.open()
                }
            }
        }
    }

    // =====================================================
    // KONFIRMASI, PROGRES, DAN HASIL PENGIRIMAN
    // =====================================================

    AppDialog {
        id: sendSelectionDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 420)
        title: "Konfirmasi Pengiriman"

        contentItem: ColumnLayout {
            spacing: 14

            Label {
                Layout.fillWidth: true
                text: "Kamu memilih " + plugin.selectedFeatureIds.length +
                      " fitur dari layer " + plugin.attributeLayerName + "."
                color: "#111827"
                font.pixelSize: 14
                wrapMode: Text.WordWrap
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: noteLabel.implicitHeight + 24
                radius: 10
                color: "#FFFBEB"
                border.color: "#FDE68A"

                Label {
                    id: noteLabel

                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.margins: 12
                    text: "Fitur terpilih dikirim ke antrean survei Firebase. Atribut disimpan sebagai properties dan geometri sebagai objek terstruktur dengan koordinat. Data utama tidak ditimpa langsung."
                    color: "#92400E"
                    font.pixelSize: 12
                    wrapMode: Text.WordWrap
                }
            }

            RowLayout {
                Layout.fillWidth: true
                Layout.topMargin: 4
                spacing: 8

                AppButton {
                    Layout.fillWidth: true
                    text: "Batal"
                    onClicked: sendSelectionDialog.close()
                }

                AppButton {
                    Layout.fillWidth: true
                    kind: "primary"
                    text: "Kirim sekarang"
                    onClicked: plugin.startSelectedUpload()
                }
            }
        }
    }

    AppDialog {
        id: uploadProgressDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 420)
        title: "Mengirim Data Survei"
        showClose: false
        closePolicy: Popup.NoAutoClose

        contentItem: ColumnLayout {
            spacing: 14

            Label {
                id: uploadProgressText

                Layout.fillWidth: true
                text: "Menyiapkan pengiriman..."
                color: "#111827"
                font.pixelSize: 14
                wrapMode: Text.WordWrap
            }

            ProgressBar {
                Layout.fillWidth: true
                from: 0
                to: Math.max(1, plugin.uploadQueue.length)
                value: plugin.uploadQueueIndex
            }

            Label {
                Layout.fillWidth: true
                text: "Jangan tutup aplikasi sampai pengiriman selesai."
                color: "#9CA3AF"
                font.pixelSize: 11
                wrapMode: Text.WordWrap
            }
        }
    }

    AppDialog {
        id: uploadResultDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 420)
        title: "Hasil Pengiriman"

        contentItem: ColumnLayout {
            spacing: 14

            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 76
                    radius: 12
                    color: "#F0FDF4"
                    border.color: "#BBF7D0"

                    Column {
                        anchors.centerIn: parent
                        spacing: 2

                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: plugin.uploadSuccessCount
                            color: "#166534"
                            font.pixelSize: 26
                            font.bold: true
                        }

                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: "Berhasil"
                            color: "#166534"
                            font.pixelSize: 12
                        }
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 76
                    radius: 12
                    color: plugin.uploadFailureCount > 0 ? "#FEF2F2" : "#F9FAFB"
                    border.color: plugin.uploadFailureCount > 0 ? "#FECACA" : "#E5E7EB"

                    Column {
                        anchors.centerIn: parent
                        spacing: 2

                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: plugin.uploadFailureCount
                            color: plugin.uploadFailureCount > 0 ? "#B91C1C" : "#6B7280"
                            font.pixelSize: 26
                            font.bold: true
                        }

                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: "Gagal"
                            color: plugin.uploadFailureCount > 0 ? "#B91C1C" : "#6B7280"
                            font.pixelSize: 12
                        }
                    }
                }
            }

            Label {
                Layout.fillWidth: true
                visible: plugin.uploadFailureCount > 0
                text: "Periksa koneksi lalu kirim ulang fitur yang gagal."
                color: "#6B7280"
                font.pixelSize: 12
                wrapMode: Text.WordWrap
            }

            AppButton {
                Layout.fillWidth: true
                kind: "primary"
                text: "Selesai"
                onClicked: uploadResultDialog.close()
            }
        }
    }

    // =====================================================
    // DIALOG HASIL PEMERIKSAAN API
    // =====================================================

    AppDialog {
        id: debugDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 24, 520)
        height: Math.min(parent.height - 32, 540)

        title: "Pemeriksaan API QField"

        contentItem: ColumnLayout {
            spacing: 10

            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                radius: 10
                color: "#F9FAFB"
                border.color: "#E5E7EB"
                clip: true

                ScrollView {
                    anchors.fill: parent
                    anchors.margins: 4

                    TextArea {
                        readOnly: true
                        selectByMouse: true
                        wrapMode: TextEdit.Wrap
                        text: plugin.debugOutput
                        color: "#1F2937"
                        font.family: "monospace"
                        font.pixelSize: 12
                        background: null
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                Item {
                    Layout.fillWidth: true
                }

                AppButton {
                    text: "Tutup"
                    onClicked: debugDialog.close()
                }
            }
        }
    }

    // =====================================================
    // DIALOG LOGIN
    // =====================================================

    LoginDialog {
        id: loginDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        projectId: "webgis-sctk"
        apiKey: plugin.firebaseApiKey
        loading: plugin.isLoggingIn
        errorMessage: plugin.loginError

        onLoginRequested: function(projectId, apiKey, email, password) {
            plugin.firebaseApiKey = apiKey
            loginSettings.savedApiKey = apiKey
            plugin.loginError = ""
            plugin.isLoggingIn = true

            firebaseAuth.apiKey = apiKey
            firebaseAuth.login(email, password)
        }
    }

    // =====================================================
    // DIALOG AKUN
    // =====================================================

    AppDialog {
        id: accountDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 340)
        title: "Akun SCTK Sync"

        contentItem: ColumnLayout {
            spacing: 14

            RowLayout {
                Layout.fillWidth: true
                spacing: 12

                Rectangle {
                    Layout.preferredWidth: 40
                    Layout.preferredHeight: 40
                    radius: 20
                    color: "#DCFCE7"

                    Label {
                        anchors.centerIn: parent
                        text: plugin.activeUser.length > 0 ? plugin.activeUser.charAt(0).toUpperCase() : "?"
                        color: "#166534"
                        font.pixelSize: 16
                        font.bold: true
                    }
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2

                    Label {
                        text: "Login sebagai"
                        color: "#6B7280"
                        font.pixelSize: 12
                    }

                    Label {
                        Layout.fillWidth: true
                        text: plugin.activeUser
                        color: "#111827"
                        font.pixelSize: 14
                        font.weight: Font.DemiBold
                        elide: Text.ElideMiddle
                    }
                }
            }

            AppButton {
                Layout.fillWidth: true
                kind: "danger"
                text: "Logout"

                onClicked: {
                    plugin.logoutFirebase()
                    accountDialog.close()
                }
            }
        }
    }
}
