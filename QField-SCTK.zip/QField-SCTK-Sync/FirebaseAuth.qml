import QtQuick

QtObject {
    id: auth

    property string apiKey: ""
    property bool busy: false

    signal loginSucceeded(string email, string idToken, string refreshToken)
    signal loginFailed(string message)
    signal tokenRefreshed(string idToken, string refreshToken)
    signal refreshFailed(string message)

    function login(email, password) {
        if (email.trim() === "" || password === "") {
            auth.loginFailed("Email dan password wajib diisi.")
            return
        }
        if (apiKey.trim() === "") {
            auth.loginFailed("Web API Key Firebase belum diisi.")
            return
        }
        auth.busy = true
        var request = new XMLHttpRequest()
        request.open("POST", "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + auth.apiKey)
        request.setRequestHeader("Content-Type", "application/json")
        request.onreadystatechange = function() {
            if (request.readyState !== XMLHttpRequest.DONE) return
            auth.busy = false
            var result = {}
            try { result = JSON.parse(request.responseText) }
            catch (error) { auth.loginFailed("Respons server tidak dapat dibaca."); return }
            if (request.status === 200 && result.idToken) {
                auth.loginSucceeded(result.email || email, result.idToken, result.refreshToken || "")
            } else {
                var errorCode = result.error ? result.error.message : "UNKNOWN_ERROR"
                if (errorCode === "EMAIL_NOT_FOUND" || errorCode === "INVALID_LOGIN_CREDENTIALS" || errorCode === "INVALID_PASSWORD") auth.loginFailed("Email atau password salah.")
                else if (errorCode === "USER_DISABLED") auth.loginFailed("Akun ini telah dinonaktifkan.")
                else if (errorCode === "INVALID_EMAIL") auth.loginFailed("Format email tidak valid.")
                else if (errorCode === "TOO_MANY_ATTEMPTS_TRY_LATER") auth.loginFailed("Terlalu banyak percobaan. Coba lagi nanti.")
                else if (errorCode === "API_KEY_INVALID") auth.loginFailed("Web API Key Firebase tidak valid.")
                else auth.loginFailed("Login gagal: " + errorCode)
            }
        }
        request.send(JSON.stringify({email: email.trim(), password: password, returnSecureToken: true}))
    }

    function refreshIdToken(refreshToken) {
        if (refreshToken.trim() === "") { auth.refreshFailed("Refresh token tidak tersedia."); return }
        if (auth.apiKey.trim() === "") { auth.refreshFailed("Web API Key Firebase belum diisi."); return }
        auth.busy = true
        var request = new XMLHttpRequest()
        request.open("POST", "https://securetoken.googleapis.com/v1/token?key=" + auth.apiKey)
        request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
        request.onreadystatechange = function() {
            if (request.readyState !== XMLHttpRequest.DONE) return
            auth.busy = false
            var result = {}
            try { result = JSON.parse(request.responseText) }
            catch (error) { auth.refreshFailed("Respons refresh token tidak dapat dibaca."); return }
            if (request.status === 200 && result.id_token) auth.tokenRefreshed(result.id_token, result.refresh_token || refreshToken)
            else {
                var errorCode = result.error ? result.error.message : "UNKNOWN_ERROR"
                auth.refreshFailed("Refresh token gagal: " + errorCode)
            }
        }
        request.send("grant_type=refresh_token&refresh_token=" + encodeURIComponent(refreshToken))
    }
}
