
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Dialog {
    id: loginDialog

    title: "SCTK Sync - Login"
    modal: true
    anchors.centerIn: parent
    width: 360

    property string projectId: ""
    property string apiKey: ""
    property string email: ""
    property string password: ""

    signal loginRequested(
        string projectId,
        string apiKey,
        string email,
        string password
    )

    standardButtons: Dialog.NoButton

    contentItem: ColumnLayout {
        spacing: 12


        RowLayout {
            Layout.fillWidth: true

            Label {
                text: "Login Firebase"
                font.pixelSize: 20
                font.bold: true
                Layout.fillWidth: true
            }

            ToolButton {
                text: "✕"
                font.pixelSize: 20
                enabled: !loginDialog.loading

                onClicked: loginDialog.close()
            }
        }


        Label { text: "Project ID" }
        TextField {
            id: projectIdField
            placeholderText: "webgis-sctk"
            text: loginDialog.projectId
            Layout.fillWidth: true
        }

        Label { text: "Web API Key" }
        TextField {
            id: apiKeyField
            placeholderText: "Masukkan Web API Key"
            text: loginDialog.apiKey
            Layout.fillWidth: true
        }

        Label { text: "Email" }
        TextField {
            id: emailField
            placeholderText: "Email akun Firebase"
            inputMethodHints: Qt.ImhEmailCharactersOnly
            Layout.fillWidth: true
        }

        Label { text: "Password" }
        TextField {
            id: passwordField
            placeholderText: "Password akun Firebase"
            echoMode: TextInput.Password
            Layout.fillWidth: true
        }

        Label {
            text: loginDialog.errorMessage
            color: "red"
            visible: text !== ""
            wrapMode: Text.WordWrap
            Layout.fillWidth: true
        }

        Button {
            text: loginDialog.loading ? "SEDANG LOGIN..." : "LOGIN"
            enabled: !loginDialog.loading
            Layout.fillWidth: true

            onClicked: {
                loginDialog.errorMessage = ""
                loginDialog.loginRequested(
                    projectIdField.text.trim(),
                    apiKeyField.text.trim(),
                    emailField.text.trim(),
                    passwordField.text
                )
            }
        }
    }

    property bool loading: false
    property string errorMessage: ""
}
