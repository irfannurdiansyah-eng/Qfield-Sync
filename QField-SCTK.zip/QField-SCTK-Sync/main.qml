
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import org.qfield
import org.qfield.core

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var availableLayers: []
    property string layerListMessage: "Tekan tombol untuk memuat layer."
    property string featureCheckOutput: "Pilih layer lalu ketuk Pilih fitur."
    property var attributeHeaders: []
    property var attributeRows: []
    property string attributeLayerName: ""
    property string attributeLayerId: ""
    property int attributeFeatureCount: 0
    // Semua fitur dimuat; ListView hanya membuat delegate yang terlihat.
    property int sortColumn: -1
    property bool sortAscending: true
    property var selectedFeatureIds: []
    property var featurePayloads: []
    property var uploadQueue: []
    property int uploadQueueIndex: 0
    property int uploadSuccessCount: 0
    property int uploadFailureCount: 0
    property var uploadFailureDetails: []
    // Satu percobaan refresh + retry untuk setiap fitur yang mendapat HTTP 401.
    property bool uploadRetryPending: false
    property bool uploadRetryAttempted: false
    property string uploadSurveyDate: ""
    property string debugOutput: "Tekan Diagnostik untuk memeriksa API."

    // Tarik base dari QGIS (qfield_base)
    property var baseList: []
    property string baseListMessage: "Memuat daftar base..."
    property var pendingBase: null
    property bool pullBusy: false
    property string pullOutput: ""

    // Firebase Authentication
    property string firebaseApiKey: "ISI_WEB_API_KEY_FIREBASE"
    property string activeUser: "Belum login"
    property string connectionStatus: "Belum terhubung"
    property string idToken: ""
    property string refreshToken: ""
    property string loginError: ""
    property bool isLoggingIn: false

    Settings {
        id: loginSettings
        category: "SCTKSync"

        property string savedEmail: ""
        property string savedRefreshToken: ""
        property string savedApiKey: ""
        // Daftar layer yang dibuat dari base: { fileProject: { docId: {path, name} } }
        property string baseLayersJson: "{}"
    }

    // =====================================================
    // PEMERIKSAAN API QFIELD
    // =====================================================

    function debugQFieldApi() {
        var result = "=== QFIELD LAYER API CHECK ===\n"

        try {
            result += "iface: " + typeof iface + "\n"
            result += "iface.mapCanvas: " + typeof iface.mapCanvas + "\n"

            var canvas = iface.mapCanvas()
            var settings = canvas.mapSettings
            var layers = settings.layers

            result += "mapSettings: " + typeof settings + "\n"
            result += "settings.layers: " + typeof layers + "\n"

            if (layers !== undefined && layers !== null) {
                result += "Jumlah layer: " + layers.length + "\n"

                for (var i = 0; i < layers.length; i++) {
                    var item = layers[i]

                    result += (i + 1) + ". " +
                        (item && item.name !== undefined
                            ? String(item.name)
                            : "(nama tidak tersedia)") +
                        " | ID: " +
                        (item && item.id !== undefined
                            ? String(item.id)
                            : "(ID tidak tersedia)") + "\n"
                }
            }
            result += "\n=== EDIT API CHECK ===\n"
            result += "LayerUtils.addFeature: " + typeof LayerUtils.addFeature + "\n"
            result += "FeatureUtils.createBlankFeature: " + typeof FeatureUtils.createBlankFeature + "\n"
            result += "FeatureUtils.createFeature: " + typeof FeatureUtils.createFeature + "\n"
            result += "GeometryUtils.createGeometryFromWkt: " + typeof GeometryUtils.createGeometryFromWkt + "\n"
            result += "LayerUtils.createMemoryLayer: " + typeof LayerUtils.createMemoryLayer + "\n"
            result += "LayerUtils.memoryLayerFromJsonString: " + typeof LayerUtils.memoryLayerFromJsonString + "\n"
            result += "LayerUtils.saveVectorLayerAs: " + typeof LayerUtils.saveVectorLayerAs + "\n"
            result += "LayerUtils.loadVectorLayer: " + typeof LayerUtils.loadVectorLayer + "\n"
            result += "FileUtils.writeFileContent: " + (typeof FileUtils !== "undefined" ? typeof FileUtils.writeFileContent : "undefined") + "\n"
            result += "qgisProject: " + typeof qgisProject + "\n"
            if (typeof qgisProject !== "undefined" && qgisProject) {
                result += "ProjectUtils.addMapLayer: " + (typeof ProjectUtils !== "undefined" ? typeof ProjectUtils.addMapLayer : "undefined") + "\n"
                result += "ProjectUtils.mapLayers: " + (typeof ProjectUtils !== "undefined" ? typeof ProjectUtils.mapLayers : "undefined") + "\n"
                result += "qgisProject.mapLayers: " + typeof qgisProject.mapLayers + "\n"
                result += "qgisProject.homePath: " + String(qgisProject.homePath) + "\n"
                result += "qgisProject.fileName: " + String(qgisProject.fileName) + "\n"
            }

            var everyLayer = plugin.allProjectLayers()
            for (var m = 0; m < everyLayer.length; m++) {
                var ly = everyLayer[m]
                if (!ly || ly.fields === undefined) continue
                result += "\n[" + String(ly.name) + "]\n"
                result += "CRS: " + (ly.crs ? String(ly.crs.authid) : "?") + "\n"
                result += "fields: " + ly.fields.names.join(", ") + "\n"
            }

            for (var k = 0; k < layers.length; k++) {
                if (String(layers[k].name) === "Survei_Line") {
                    var t = layers[k]
                    result += "\n[Survei_Line]\n"
                    result += "CRS: " + (t.crs ? String(t.crs.authid) : "?") + "\n"
                    result += "startEditing: " + typeof t.startEditing + "\n"
                    result += "commitChanges: " + typeof t.commitChanges + "\n"
                    result += "changeAttributeValue: " + typeof t.changeAttributeValue + "\n"
                    result += "changeGeometry: " + typeof t.changeGeometry + "\n"
                    result += "fields: " + t.fields.names.join(", ") + "\n"
                }
            }
        } catch (error) {
            result += "\nERROR: " + String(error)
        }

        plugin.debugOutput = result
        debugDialog.open()
        console.log(result)
    }

    // =====================================================
    // PEMERIKSAAN FITUR DAN ATRIBUT
    // =====================================================


    function formatFeatureValue(value) {
        if (value === null || value === undefined || String(value) === "")
            return "—"
        if (value === true || String(value) === "true")
            return "Ya"
        if (value === false || String(value) === "false")
            return "Tidak"
        return String(value)
    }

    function sortAttributeRows(columnIndex) {
        if (plugin.sortColumn === columnIndex)
            plugin.sortAscending = !plugin.sortAscending
        else {
            plugin.sortColumn = columnIndex
            plugin.sortAscending = true
        }

        var sorted = plugin.attributeRows.slice(0)
        sorted.sort(function(a, b) {
            var av = String(a[columnIndex])
            var bv = String(b[columnIndex])
            var an = Number(av)
            var bn = Number(bv)
            var numeric = av.trim() !== "" && bv.trim() !== "" &&
                          !isNaN(an) && !isNaN(bn)
            var cmp = numeric ? (an < bn ? -1 : (an > bn ? 1 : 0))
                              : av.toLowerCase().localeCompare(bv.toLowerCase())
            return plugin.sortAscending ? cmp : -cmp
        })
        plugin.attributeRows = sorted
    }

    function isFeatureSelected(featureId) {
        return plugin.selectedFeatureIds.indexOf(String(featureId)) !== -1
    }

    // UUID v4 fallback for features that do not yet have a UUID attribute.
    // This creates a stable ID for the current upload queue; persistent local
    // UUIDs should be configured as a field default expression in QGIS: uuid().
    function generateUuidV4() {
        function hex4() { return Math.floor(Math.random() * 65536).toString(16).padStart(4, "0") }
        var value = hex4() + hex4() + "-" + hex4() + "-4" + hex4().slice(1) + "-" +
                    ((8 + Math.floor(Math.random() * 4)).toString(16)) + hex4().slice(1) + "-" +
                    hex4() + hex4() + hex4()
        return value.toLowerCase()
    }

    function setFeatureSelected(featureId, checked) {
        var id = String(featureId)
        var selected = plugin.selectedFeatureIds.slice(0)
        var pos = selected.indexOf(id)
        if (checked && pos < 0)
            selected.push(id)
        else if (!checked && pos >= 0)
            selected.splice(pos, 1)
        plugin.selectedFeatureIds = selected
    }

    function findFeaturePayload(featureId) {
        var target = String(featureId)
        for (var i = 0; i < plugin.featurePayloads.length; i++) {
            if (String(plugin.featurePayloads[i].rowId) === target)
                return plugin.featurePayloads[i]
        }
        return null
    }

    function buildSelectedUploadQueue() {
        var selected = plugin.selectedFeatureIds.slice(0)
        var queue = []
        var layer = null
        var layers = iface.mapCanvas().mapSettings.layers
        for (var i = 0; i < layers.length; i++) {
            if (String(layers[i].id) === String(plugin.attributeLayerId)) {
                layer = layers[i]
                break
            }
        }
        if (layer === null)
            throw new Error("Layer tidak ditemukan. Tutup tabel lalu buka kembali.")

        // Hanya ambil geometri fitur yang dipilih. Satu kali scan untuk semua pilihan.
        // WKT hanya format perantara dari QField; FirestoreApi mengubahnya ke map/array Firestore.
        var wanted = {}
        for (var w = 0; w < selected.length; w++)
            wanted[String(selected[w])] = true
        var iterator = LayerUtils.createFeatureIterator(layer)
        while (iterator.hasNext() && Object.keys(wanted).length > 0) {
            var feature = iterator.next()
            var rowId = String(feature.id)
            if (!wanted[rowId])
                continue
            var payload = plugin.findFeaturePayload(rowId)
            if (payload !== null) {
                // Prefer an existing UUID field; otherwise generate one for upload.
                var currentAttributes = {}
                var fieldNames = layer.fields.names
                for (var a = 0; a < fieldNames.length; a++) {
                    var fieldName = String(fieldNames[a])
                    var fieldValue = null
                    try { fieldValue = feature.attribute(fieldName) } catch (attributeError) { fieldValue = null }
                    currentAttributes[fieldName] = fieldValue === undefined ? null : fieldValue
                }
                var uuidFieldValue = ""
                for (var u = 0; u < fieldNames.length; u++) {
                    var candidateName = String(fieldNames[u]).toLowerCase()
                    if (candidateName === "uuid" || candidateName === "feature_uuid") {
                        var candidateValue = currentAttributes[String(fieldNames[u])]
                        if (candidateValue !== null && candidateValue !== undefined && String(candidateValue).trim() !== "") {
                            uuidFieldValue = String(candidateValue).replace(/^\{|\}$/g, "")
                            break
                        }
                    }
                }
                if (uuidFieldValue === "")
                    uuidFieldValue = plugin.generateUuidV4()
                payload.featureUuid = uuidFieldValue
                payload.documentId = uuidFieldValue
                // Keep the outgoing feature properties consistent with the document UUID.
                currentAttributes.uuid = uuidFieldValue
                payload.attributes = currentAttributes
                var geom = feature.geometry
                var wkt = ""
                if (geom !== undefined && geom !== null && typeof geom.asWkt === "function")
                    wkt = String(geom.asWkt())
                var geometryType = "Unknown"
                if (geom !== undefined && geom !== null) {
                    var typeNumber = Number(geom.type)
                    geometryType = typeNumber === 0 ? "Point" :
                                   (typeNumber === 1 ? "LineString" :
                                   (typeNumber === 2 ? "Polygon" : "Unknown"))
                }
                // Kirim WKT + CRS sebagai input perantara. Jangan kirim WKT
                // langsung sebagai geometry Firestore: FirestoreApi.qml akan
                // membentuk mapValue/arrayValue sesuai plugin QGIS SCTK Sync.
                payload.geometry = {
                    type: geometryType,
                    wkt: wkt,
                    crs: (layer.crs && layer.crs.authid !== undefined) ? String(layer.crs.authid) : ""
                }
                queue.push(payload)
                delete wanted[rowId]
            }
        }
        return queue
    }

    function startSelectedUpload() {
        if (plugin.idToken === "") {
            mainWindow.displayToast("Silakan login terlebih dahulu.")
            return
        }
        if (plugin.selectedFeatureIds.length === 0) {
            mainWindow.displayToast("Centang minimal satu fitur.")
            return
        }

        var queue = []
        try {
            queue = plugin.buildSelectedUploadQueue()
        } catch (queueError) {
            mainWindow.displayToast("Gagal menyiapkan fitur: " + String(queueError.message || queueError))
            return
        }

        if (queue.length === 0) {
            mainWindow.displayToast("Data fitur terpilih tidak ditemukan. Buka ulang tabel atribut.")
            return
        }

        plugin.uploadQueue = queue
        plugin.uploadQueueIndex = 0
        plugin.uploadSuccessCount = 0
        plugin.uploadFailureCount = 0
        plugin.uploadFailureDetails = []
        plugin.uploadRetryPending = false
        plugin.uploadRetryAttempted = false
        sendSelectionDialog.close()
        uploadProgressDialog.open()
        plugin.uploadNextFeature()
    }

    // Cari docId base kalau layer ini dibuat dari base (Survei_Line, Survei_Point, ...)
    function baseDocIdForLayer(layerName) {
        var entries = plugin.readBaseRegistry()[String(qgisProject.fileName)] || {}
        var target = plugin.normalizeLayerName(layerName)
        for (var docId in entries) {
            if (plugin.layerNameVariants(entries[docId].name).indexOf(target) !== -1)
                return docId
        }
        return ""
    }

    function uploadNextFeature() {
        if (plugin.uploadQueueIndex >= plugin.uploadQueue.length) {
            uploadProgressDialog.close()
            uploadResultDialog.open()
            return
        }

        var item = plugin.uploadQueue[plugin.uploadQueueIndex]
        var baseDocId = plugin.baseDocIdForLayer(plugin.attributeLayerName)
        uploadProgressText.text = "Mengirim " + (plugin.uploadQueueIndex + 1) +
                                  " dari " + plugin.uploadQueue.length +
                                  "\nLayer: " + plugin.attributeLayerName +
                                  "\nTujuan: " + (baseDocId !== ""
                                      ? "qfield_base/" + baseDocId + "/survey"
                                      : "qfield_inbox")
        firestoreApi.uploadSurvey(
            item.documentId,
            item.featureUuid,
            plugin.attributeLayerId,
            plugin.attributeLayerName,
            item.geometry,
            item.attributes,
            plugin.activeUser,
            item.surveyDate,
            baseDocId
        )
    }

    function inspectLayer(layerId) {
        featureCheckDialog.open()
        plugin.featureCheckOutput = "Memuat atribut layer..."
        plugin.attributeHeaders = []
        plugin.attributeRows = []
        plugin.attributeLayerName = ""
        plugin.attributeLayerId = ""
        plugin.attributeFeatureCount = 0
        plugin.featurePayloads = []
        plugin.sortColumn = -1
        plugin.sortAscending = true
        plugin.selectedFeatureIds = []

        try {
            var layers = iface.mapCanvas().mapSettings.layers
            var layer = null
            for (var i = 0; i < layers.length; i++) {
                if (String(layers[i].id) === String(layerId)) {
                    layer = layers[i]
                    break
                }
            }

            if (layer === null) {
                plugin.featureCheckOutput = "Layer tidak ditemukan."
                return
            }

            var names = layer.fields.names
            var headers = ["ID_FITUR"]
            for (var h = 0; h < names.length; h++)
                headers.push(String(names[h]))

            var iterator = LayerUtils.createFeatureIterator(layer)
            var rows = []
            var payloads = []
            while (iterator.hasNext()) {
                var feature = iterator.next()
                var rowId = String(feature.id)
                var row = [rowId]
                var featureUuid = ""
                var surveyDate = ""

                for (var j = 0; j < names.length; j++) {
                    var fieldName = String(names[j])
                    var rawValue = null
                    try {
                        rawValue = feature.attribute(fieldName)
                    } catch (attributeError) {
                        rawValue = null
                    }
                    row.push(formatFeatureValue(rawValue))
                    var lowerName = fieldName.toLowerCase()
                    if ((lowerName === "uuid" || lowerName === "feature_uuid") &&
                        rawValue !== null && rawValue !== undefined &&
                        String(rawValue).trim() !== "") {
                        featureUuid = String(rawValue).replace(/^\\{|\\}$/g, "")
                    }
                    if ((lowerName === "survey_date" || lowerName === "tanggal_survei" ||
                         lowerName === "tanggal_survey" || lowerName === "tanggal") &&
                        rawValue !== null && rawValue !== undefined &&
                        String(rawValue).trim() !== "") {
                        surveyDate = String(rawValue)
                    }
                }

                // Jangan konversi geometri ke WKT untuk semua fitur saat tabel dibuka.
                // Ini operasi yang relatif berat pada layer besar/perangkat HP.
                // Geometri baru dibaca untuk fitur yang benar-benar dipilih saat upload.
                var geometryObject = null

                rows.push(row)
                payloads.push({
                    "rowId": rowId,
                    "featureUuid": featureUuid,
                    "documentId": featureUuid || "",
                    // Atribut lengkap dibaca ulang hanya untuk fitur yang dikirim.
                    "geometry": geometryObject,
                    "surveyDate": surveyDate
                })
            }

            plugin.attributeLayerName = String(layer.name)
            plugin.attributeLayerId = String(layer.id)
            plugin.attributeFeatureCount = rows.length
            plugin.attributeHeaders = headers
            plugin.attributeRows = rows
            plugin.featurePayloads = payloads
            plugin.featureCheckOutput = rows.length === 0
                ? "Layer ini belum memiliki fitur."
                : rows.length + " fitur tersedia. Tabel dirender bertahap agar lebih ringan."
        } catch (error) {
            plugin.featureCheckOutput = "Gagal membaca tabel atribut: " + String(error)
        }
        console.log("Tabel atribut layer selesai dibaca.")
    }

    // =====================================================
    // DAFTAR LAYER
    // =====================================================

    function refreshLayerList() {
        var rows = []

        try {
            var canvas = iface.mapCanvas()
            var layers = canvas.mapSettings.layers

            if (layers !== undefined && layers !== null) {
                for (var i = 0; i < layers.length; i++) {
                    var layer = layers[i]
                    // Lewati layer raster (mis. Google Satellite): tidak punya fitur
                    if (!layer || layer.fields === undefined)
                        continue
                    var layerName = "Layer " + (i + 1)
                    var layerId = ""

                    try {
                        if (layer && layer.name !== undefined) {
                            layerName = String(layer.name)
                        }
                    } catch (nameError) {
                    }

                    try {
                        if (layer && layer.id !== undefined) {
                            layerId = String(layer.id)
                        }
                    } catch (idError) {
                    }

                    rows.push({
                        "name": layerName,
                        "id": layerId
                    })
                }
            }

            plugin.availableLayers = rows
            plugin.layerListMessage = rows.length > 0
                ? "Pilih layer yang hasil surveinya mau dikirim."
                : "Tidak ada layer vektor yang tampil di peta."
        } catch (error) {
            plugin.availableLayers = []
            plugin.layerListMessage =
                "Gagal membaca layer: " + String(error)
        }

        layerDialog.open()
    }

    // =====================================================
    // FIREBASE AUTHENTICATION
    // =====================================================

    FirebaseAuth {
        id: firebaseAuth
        apiKey: plugin.firebaseApiKey

        onLoginSucceeded: function(email, token, refresh) {
            plugin.isLoggingIn = false
            plugin.idToken = token
            plugin.refreshToken = refresh

            loginSettings.savedEmail = email
            loginSettings.savedRefreshToken = refresh

            plugin.activeUser = email
            plugin.connectionStatus = "Login berhasil"
            plugin.loginError = ""

            loginDialog.close()
            mainWindow.displayToast("Login berhasil")
        }

        onLoginFailed: function(message) {
            plugin.isLoggingIn = false
            plugin.loginError = message
        }

        onTokenRefreshed: function(token, refresh) {
            plugin.idToken = token
            plugin.refreshToken = refresh
            plugin.activeUser = loginSettings.savedEmail
            plugin.connectionStatus = "Login berhasil"
            plugin.loginError = ""
            loginSettings.savedRefreshToken = refresh

            if (plugin.uploadRetryPending) {
                // Ulangi fitur saat ini; jangan menaikkan indeks antrean dulu.
                plugin.uploadRetryPending = false
                mainWindow.displayToast("Sesi diperbarui, mencoba ulang upload...")
                plugin.uploadNextFeature()
            } else {
                mainWindow.displayToast("Sesi login berhasil dipulihkan")
            }
        }

        onRefreshFailed: function(message) {
            plugin.idToken = ""
            plugin.refreshToken = ""
            plugin.activeUser = "Belum login"
            plugin.connectionStatus = "Sesi berakhir, silakan login"
            plugin.loginError = message
            loginSettings.savedRefreshToken = ""

            if (plugin.uploadRetryPending) {
                plugin.uploadRetryPending = false
                var failedItem = plugin.uploadQueue[plugin.uploadQueueIndex]
                var details = plugin.uploadFailureDetails.slice(0)
                details.push("Fitur " + (failedItem ? failedItem.featureUuid : "tidak diketahui") +
                             ": refresh token gagal; " + String(message))
                plugin.uploadFailureDetails = details
                plugin.uploadFailureCount += 1
                plugin.uploadQueueIndex += 1
                plugin.uploadRetryAttempted = false
                plugin.uploadNextFeature()
            }
        }
    }

    // =====================================================
    // FIRESTORE API
    // =====================================================

    FirestoreApi {
        id: firestoreApi

        projectId: "webgis-sctk"
        projectDocumentId: "fc98b8f1-78d5-456f-b76a-8ebb3b4b4160"
        idToken: plugin.idToken

        onUploadSucceeded: function(featureId) {
            plugin.uploadSuccessCount += 1
            plugin.uploadRetryAttempted = false
            plugin.uploadRetryPending = false
            plugin.uploadQueueIndex += 1
            plugin.uploadNextFeature()
        }

        onUploadFailed: function(message) {
            var errorText = String(message)
            var isUnauthorized = errorText.indexOf("HTTP 401") !== -1 ||
                                 errorText.indexOf("UNAUTHENTICATED") !== -1

            if (isUnauthorized && !plugin.uploadRetryAttempted &&
                    plugin.refreshToken !== "") {
                plugin.uploadRetryAttempted = true
                plugin.uploadRetryPending = true
                plugin.connectionStatus = "Memperbarui sesi untuk upload..."
                firebaseAuth.refreshIdToken(plugin.refreshToken)
                return
            }

            plugin.uploadFailureCount += 1
            var details = plugin.uploadFailureDetails.slice(0)
            var failedItem = plugin.uploadQueue[plugin.uploadQueueIndex]
            details.push("Fitur " + (failedItem ? failedItem.featureUuid : "tidak diketahui") +
                         ": " + errorText)
            plugin.uploadFailureDetails = details
            console.log("Upload gagal: " + errorText)
            plugin.uploadRetryAttempted = false
            plugin.uploadQueueIndex += 1
            plugin.uploadNextFeature()
        }
    }


    // =====================================================
    // TARIK BASE DARI QGIS (qfield_base -> GPKG QField)
    // =====================================================

    // Normalisasi nama layer supaya "Pipa rencana" (QGIS) cocok dengan
    // "Pipa Rencana — pipa_rencana" (QField): huruf kecil, "_" jadi spasi,
    // spasi ganda dirapikan.
    function normalizeLayerName(name) {
        return String(name || "").toLowerCase().replace(/_/g, " ")
                                 .replace(/\s+/g, " ").trim()
    }

    // Semua kemungkinan nama untuk satu layer QField: nama lengkap,
    // bagian sebelum " — " (nama tampilan), dan bagian sesudahnya (nama tabel).
    function layerNameVariants(name) {
        var full = String(name || "")
        var variants = [plugin.normalizeLayerName(full)]
        var parts = full.split(/\s+[—–-]\s+/)
        for (var i = 0; i < parts.length; i++)
            variants.push(plugin.normalizeLayerName(parts[i]))
        return variants
    }

    function allProjectLayers() {
        var result = []
        try {
            if (typeof ProjectUtils !== "undefined"
                    && typeof ProjectUtils.mapLayers === "function") {
                var all = ProjectUtils.mapLayers(qgisProject)
                for (var id in all) {
                    if (all[id])
                        result.push(all[id])
                }
            }
        } catch (e) {
            console.log("ProjectUtils.mapLayers gagal: " + e)
        }
        if (result.length === 0) {
            var layers = iface.mapCanvas().mapSettings.layers
            for (var i = 0; i < layers.length; i++)
                result.push(layers[i])
        }
        return result
    }

    // Cari layer di seluruh proyek berdasarkan nama base dari QGIS.
    function findProjectLayerByName(name) {
        var target = plugin.normalizeLayerName(name)
        var layers = plugin.allProjectLayers()
        for (var i = 0; i < layers.length; i++) {
            if (!layers[i] || layers[i].fields === undefined)
                continue   // lewati layer raster seperti Google Satellite
            if (plugin.layerNameVariants(layers[i].name).indexOf(target) !== -1)
                return layers[i]
        }
        return null
    }

    function openBaseList() {
        if (plugin.idToken === "") {
            mainWindow.displayToast("Silakan login terlebih dahulu")
            return
        }
        plugin.baseList = []
        plugin.baseListMessage = "Memuat daftar base..."
        baseDialog.open()

        firestoreApi.listBases(function(error, documents) {
            if (error !== "") {
                plugin.baseListMessage = "Gagal memuat base: " + error
                return
            }
            var items = []
            for (var i = 0; i < documents.length; i++) {
                var d = documents[i]
                var layerName = String(d.layer_name || d._docId)
                var target = plugin.findProjectLayerByName(layerName)
                var createdEntries = plugin.readBaseRegistry()[String(qgisProject.fileName)] || {}
                items.push({
                    docId: d._docId,
                    layerName: layerName,
                    geometryType: String(d.geometry_type || "-"),
                    crs: String(d.crs || ""),
                    featureCount: Number(d.feature_count || 0),
                    fields: d.fields || [],
                    styleQml: String(d.style_qml || ""),
                    inProject: target !== null,
                    createdByPlugin: createdEntries[d._docId] !== undefined,
                    targetName: target !== null ? String(target.name) : ""
                })
            }
            plugin.baseList = items
            plugin.baseListMessage = items.length === 0
                ? "Belum ada base di Firebase. Upload dulu dari QGIS lewat QField SCTK."
                : "Pilih base untuk dimasukkan ke layer dengan nama yang sama di proyek ini."
        })
    }

    function startPullBase(base) {
        plugin.pullBusy = true
        plugin.pullOutput = "Menarik base '" + base.layerName + "'...\n"
        pullResultDialog.open()

        var layer = plugin.findProjectLayerByName(base.layerName)
        if (layer === null) {
            plugin.pullOutput += "Layer belum ada di proyek. Membuat layer baru dari base...\n"
            firestoreApi.listBaseFeatures(base.docId, function(error, documents) {
                if (error !== "") {
                    plugin.pullBusy = false
                    plugin.pullOutput += "GAGAL mengambil feature: " + error
                    return
                }
                plugin.pullOutput += "Feature di Firebase: " + documents.length + "\n"
                try {
                    plugin.createLayerFromBase(base, documents)
                } catch (e) {
                    plugin.pullOutput += "\nERROR: " + String(e)
                }
                plugin.pullBusy = false
            })
            return
        }

        var layerCrs = (layer.crs && layer.crs.authid !== undefined) ? String(layer.crs.authid) : ""
        if (base.crs !== "" && layerCrs !== "" && base.crs !== layerCrs) {
            plugin.pullBusy = false
            plugin.pullOutput += "GAGAL: CRS berbeda.\n"
                + "Base: " + base.crs + "\nLayer QField: " + layerCrs + "\n"
                + "Samakan CRS layer di QGIS dan QField dulu."
            return
        }

        firestoreApi.listBaseFeatures(base.docId, function(error, documents) {
            if (error !== "") {
                plugin.pullBusy = false
                plugin.pullOutput += "GAGAL mengambil feature: " + error
                return
            }
            plugin.pullOutput += "Feature di Firebase: " + documents.length + "\n"

            // Layer yang dulu dibuat dari base: perbarui juga file style-nya
            var registry = plugin.readBaseRegistry()
            var entries = registry[String(qgisProject.fileName)] || {}
            if (entries[base.docId]) {
                var fixNote = plugin.ensureLayerCrs(layer, base.crs || entries[base.docId].crs || "EPSG:4326")
                if (fixNote !== "")
                    plugin.pullOutput += fixNote + "\n"
                var note = plugin.writeStyleSidecar(entries[base.docId].path, base.styleQml)
                plugin.pullOutput += note === ""
                    ? "Style/form diperbarui. Tutup-buka proyek supaya dropdown terbaru dipakai.\n"
                    : "Style/form: " + note + "\n"
            }

            if (entries[base.docId]) {
                var diff = plugin.schemaDiff(base, layer)
                if (diff.changed) {
                    try {
                        plugin.migrateBaseLayer(base, layer, documents, entries[base.docId], diff)
                    } catch (eMig) {
                        plugin.pullOutput += "\nERROR: " + String(eMig)
                    }
                    plugin.pullBusy = false
                    return
                }
            }

            try {
                plugin.applyBaseFeatures(layer, base, documents)
            } catch (e) {
                plugin.pullOutput += "\nERROR: " + String(e)
            }
            plugin.pullBusy = false
        })
    }

    function applyBaseFeatures(layer, base, documents) {
        var fieldNames = []
        var rawNames = layer.fields.names
        for (var n = 0; n < rawNames.length; n++)
            fieldNames.push(String(rawNames[n]))

        // Cari kolom uuid (tidak peka huruf besar/kecil)
        var uuidIndex = -1
        for (var u = 0; u < fieldNames.length; u++) {
            if (fieldNames[u].toLowerCase() === "uuid") { uuidIndex = u; break }
        }
        if (uuidIndex < 0) {
            plugin.pullOutput += "GAGAL: layer QField tidak punya kolom uuid untuk mencocokkan feature."
            return
        }
        var uuidFieldName = fieldNames[uuidIndex]

        // Index uuid -> fid untuk feature yang sudah ada di GPKG QField
        var existing = {}
        var iterator = LayerUtils.createFeatureIterator(layer)
        while (iterator.hasNext()) {
            var f = iterator.next()
            var val = f.attribute(uuidFieldName)
            if (val !== null && val !== undefined && String(val).trim() !== "")
                existing[String(val).replace(/^\{|\}$/g, "").toLowerCase()] = f.id
        }
        if (typeof iterator.close === "function")
            iterator.close()

        // Indeks kolom yang akan diisi: semua kolom yang namanya ada di layer, kecuali fid
        function fieldIndexOf(name) {
            var lower = String(name).toLowerCase()
            if (lower === "fid") return -1
            var exact = fieldNames.indexOf(String(name))
            if (exact >= 0) return exact
            for (var i = 0; i < fieldNames.length; i++)
                if (fieldNames[i].toLowerCase() === lower) return i
            return -1
        }

        layer.startEditing()

        var added = 0, updated = 0, skipped = 0, failed = 0
        var notes = []
        var attrCheckDone = false

        for (var d = 0; d < documents.length; d++) {
            var doc = documents[d]
            var props = doc.properties || {}
            var featureUuid = String(doc.uuid || props[uuidFieldName] || props.uuid || props.UUID || doc._docId)
                              .replace(/^\{|\}$/g, "")
            var key = featureUuid.toLowerCase()

            if (existing[key] !== undefined) {
                // UPDATE: atribut saja (QField belum menyediakan changeGeometry)
                var fid = existing[key]
                for (var pName in props) {
                    if (!props.hasOwnProperty(pName)) continue
                    var idx = fieldIndexOf(pName)
                    if (idx < 0 || idx === uuidIndex) continue
                    layer.changeAttributeValue(fid, idx, props[pName])
                }
                updated++
                continue
            }

            // INSERT: feature baru
            var wkt = String(doc.geometry_wkt || "").trim()
            if (wkt === "") {
                skipped++
                if (notes.length < 10) notes.push(featureUuid + ": tidak punya geometri, dilewati")
                continue
            }

            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            var feature = FeatureUtils.createBlankFeature(layer.fields, geometry)

            for (var aName in props) {
                if (!props.hasOwnProperty(aName)) continue
                var aIdx = fieldIndexOf(aName)
                if (aIdx < 0) continue
                feature.setAttribute(aIdx, props[aName])
            }
            feature.setAttribute(uuidIndex, featureUuid)

            if (!attrCheckDone) {
                attrCheckDone = true
                if (String(feature.attribute(uuidFieldName) || "") === "")
                    notes.push("PERINGATAN: atribut tidak terisi ke feature baru (setAttribute tidak berpengaruh).")
            }

            if (LayerUtils.addFeature(layer, feature)) {
                added++
                existing[key] = -1
            } else {
                failed++
                if (notes.length < 10) notes.push(featureUuid + ": gagal ditambahkan")
            }
        }

        var committed = layer.commitChanges()
        if (!committed) {
            var errors = ""
            if (typeof layer.commitErrors === "function") {
                try { errors = String(layer.commitErrors()) } catch (e) { errors = "" }
            }
            if (typeof layer.rollBack === "function")
                layer.rollBack()
            plugin.pullOutput += "\nGAGAL menyimpan ke GPKG. Semua perubahan dibatalkan.\n" + errors
            return
        }

        plugin.pullOutput += "\nSELESAI\n"
            + "Ditambahkan : " + added + "\n"
            + "Diperbarui  : " + updated + " (atribut saja, geometri tidak diubah)\n"
            + "Dilewati    : " + skipped + "\n"
            + "Gagal       : " + failed + "\n"
        if (notes.length > 0)
            plugin.pullOutput += "\nCatatan:\n- " + notes.join("\n- ")

        if (typeof layer.triggerRepaint === "function")
            layer.triggerRepaint()
        mainWindow.displayToast("Base '" + base.layerName + "' selesai ditarik")
    }


    // =====================================================
    // MEMBUAT LAYER BARU DARI BASE (GeoJSON -> GPKG)
    // =====================================================

    readonly property string dummyUuid: "__sctk_dummy__"

    // WKT -> objek geometri GeoJSON (koordinat Z/M diabaikan)
    function wktToGeoJson(wkt) {
        var text = String(wkt || "").trim()
        var m = text.match(/^\s*([A-Za-z]+)\s*(?:ZM|Z|M)?\s*(\([\s\S]*\))\s*$/i)
        if (!m)
            return null
        var type = m[1].toUpperCase().replace(/(ZM|Z|M)$/, "")
        var parsed
        try { parsed = firestoreApi.parseWktCoordinates(m[2]) } catch (e) { return null }

        function unwrap(p) {
            while (p instanceof Array && p.length === 1 && p[0] instanceof Array)
                p = p[0]
            return p
        }

        if (type === "POINT")
            return { type: "Point", coordinates: unwrap(parsed) }
        if (type === "LINESTRING")
            return { type: "LineString", coordinates: parsed }
        if (type === "POLYGON")
            return { type: "Polygon", coordinates: parsed }
        if (type === "MULTIPOINT")
            return { type: "MultiPoint", coordinates: parsed.map(unwrap) }
        if (type === "MULTILINESTRING")
            return { type: "MultiLineString", coordinates: parsed }
        if (type === "MULTIPOLYGON")
            return { type: "MultiPolygon", coordinates: parsed }
        return null
    }

    // Geometri bantuan sesuai tipe geometri base
    function dummyGeometry(geometryType) {
        var t = String(geometryType || "").toLowerCase().replace(/(zm|z|m)$/, "")
        if (t === "point") return { type: "Point", coordinates: [0, 0] }
        if (t === "multipoint") return { type: "MultiPoint", coordinates: [[0, 0]] }
        if (t === "linestring") return { type: "LineString", coordinates: [[0, 0], [0.0001, 0.0001]] }
        if (t === "multilinestring") return { type: "MultiLineString", coordinates: [[[0, 0], [0.0001, 0.0001]]] }
        var ring = [[0, 0], [0.0001, 0], [0.0001, 0.0001], [0, 0]]
        if (t === "polygon") return { type: "Polygon", coordinates: [ring] }
        if (t === "multipolygon") return { type: "MultiPolygon", coordinates: [[ring]] }
        return null
    }

    // Nilai contoh supaya tipe kolom terbaca benar dari GeoJSON
    function sampleValueForType(typeName) {
        var t = String(typeName || "").toLowerCase()
        if (t.indexOf("int") !== -1) return 0
        if (t.indexOf("real") !== -1 || t.indexOf("double") !== -1 || t.indexOf("float") !== -1
                || t.indexOf("numeric") !== -1 || t.indexOf("decimal") !== -1) return 0.5
        if (t.indexOf("datetime") !== -1) return "2000-01-01T00:00:00"
        if (t.indexOf("date") !== -1) return "2000-01-01"
        if (t.indexOf("bool") !== -1) return false
        return "-"
    }

    function crsForAuthId(authid) {
        var target = String(authid || "").toUpperCase()
        try {
            if (typeof CoordinateReferenceSystemUtils !== "undefined"
                    && typeof CoordinateReferenceSystemUtils.fromDescription === "function") {
                var c = CoordinateReferenceSystemUtils.fromDescription(target)
                if (c && c.isValid) return c
            }
        } catch (e) {}
        try {
            if (qgisProject.crs && String(qgisProject.crs.authid).toUpperCase() === target)
                return qgisProject.crs
        } catch (e2) {}
        var layers = plugin.allProjectLayers()
        for (var i = 0; i < layers.length; i++) {
            try {
                if (layers[i].crs && String(layers[i].crs.authid).toUpperCase() === target)
                    return layers[i].crs
            } catch (e3) {}
        }
        return undefined
    }

    function safeFileName(name) {
        return String(name).replace(/[^A-Za-z0-9_\-]+/g, "_").replace(/^_+|_+$/g, "") || "base"
    }

    function readBaseRegistry() {
        try { return JSON.parse(loginSettings.baseLayersJson || "{}") } catch (e) { return {} }
    }

    function writeBaseRegistry(registry) {
        loginSettings.baseLayersJson = JSON.stringify(registry)
    }

    // Pastikan layer punya CRS yang benar. Tanpa CRS, sorotan kuning saat
    // feature dipencet dan rumus seperti transform()/length() tidak jalan.
    function ensureLayerCrs(layer, authid) {
        var target = String(authid || "EPSG:4326").toUpperCase()
        var current = ""
        try { current = layer.crs ? String(layer.crs.authid || "").toUpperCase() : "" } catch (e) {}
        if (current === target)
            return ""
        var crs = plugin.crsForAuthId(target)
        if (crs === undefined)
            return "CRS " + target + " tidak ditemukan di QField"
        try {
            layer.crs = crs
        } catch (e2) {
            return "gagal memasang CRS: " + e2
        }
        if (typeof layer.triggerRepaint === "function")
            layer.triggerRepaint()
        return "CRS dipasang ke " + target + (current === "" ? " (sebelumnya kosong)" : " (sebelumnya " + current + ")")
    }

    function loadAndAddLayer(path, name) {
        var newLayer = LayerUtils.loadVectorLayer(path, name)
        if (!newLayer || !newLayer.isValid)
            return null
        if (!ProjectUtils.addMapLayer(qgisProject, newLayer))
            return null
        return newLayer
    }

    // Tulis style QGIS (form/dropdown + simbologi) sebagai file .qml
    // di sebelah file GPKG. QGIS di QField otomatis membaca file style
    // dengan nama yang sama saat layer dimuat.
    function styleSidecarPath(gpkgPath) {
        return String(gpkgPath).split("|")[0].replace(/\.gpkg$/i, "") + ".qml"
    }

    function writeStyleSidecar(gpkgPath, styleQml) {
        if (String(styleQml || "") === "")
            return "tidak ada style di base"
        if (typeof FileUtils === "undefined" || typeof FileUtils.writeFileContent !== "function")
            return "QField ini belum mendukung FileUtils.writeFileContent"
        var path = plugin.styleSidecarPath(gpkgPath)
        try {
            if (FileUtils.writeFileContent(path, styleQml))
                return ""
        } catch (e) {
            return "gagal menulis style: " + e
        }
        return "gagal menulis style ke " + path
    }

    // Kolom yang dipakai layer base (tanpa fid, karena GPKG membuat fid sendiri)
    function baseColumns(base) {
        var fields = base.fields || []
        var columns = []
        var uuidField = ""
        for (var i = 0; i < fields.length; i++) {
            var fname = String(fields[i].name)
            if (fname.toLowerCase() === "fid") continue
            columns.push({ name: fname, type: String(fields[i].type || "") })
            if (fname.toLowerCase() === "uuid") uuidField = fname
        }
        if (uuidField === "") {
            uuidField = "uuid"
            columns.push({ name: "uuid", type: "String" })
        }
        return { columns: columns, uuidField: uuidField }
    }

    // Bandingkan kolom base dengan kolom layer di QField
    function schemaDiff(base, layer) {
        var cols = plugin.baseColumns(base).columns
        var layerNames = []
        var raw = layer.fields.names
        for (var i = 0; i < raw.length; i++)
            layerNames.push(String(raw[i]).toLowerCase())

        var added = [], removed = []
        var baseNames = []
        for (var c = 0; c < cols.length; c++) {
            var n = cols[c].name.toLowerCase()
            baseNames.push(n)
            if (layerNames.indexOf(n) === -1) added.push(cols[c].name)
        }
        for (var j = 0; j < layerNames.length; j++) {
            if (layerNames[j] === "fid") continue
            if (baseNames.indexOf(layerNames[j]) === -1) removed.push(String(raw[j]))
        }
        return { added: added, removed: removed, changed: added.length + removed.length > 0 }
    }

    // Nilai atribut QGIS -> nilai JSON (tanggal tanpa geser zona waktu)
    function jsonValue(value, typeName) {
        if (value === undefined || value === null) return null
        if (value instanceof Date) {
            var t = String(typeName || "").toLowerCase()
            if (t.indexOf("datetime") !== -1) return Qt.formatDateTime(value, "yyyy-MM-ddTHH:mm:ss")
            if (t.indexOf("date") !== -1) return Qt.formatDate(value, "yyyy-MM-dd")
            return Qt.formatDateTime(value, "yyyy-MM-ddTHH:mm:ss")
        }
        if (typeof value === "object") {
            try { return JSON.parse(JSON.stringify(value)) } catch (e) { return String(value) }
        }
        return value
    }

    // Baca semua feature lokal di layer QField -> [{uuid, props, geometry}]
    // Return null kalau ada geometri yang tidak bisa dibaca (supaya data aman).
    function readLocalEntries(layer, columns, uuidField) {
        var layerNames = []
        var raw = layer.fields.names
        for (var i = 0; i < raw.length; i++) layerNames.push(String(raw[i]))
        function layerNameFor(col) {
            var lower = col.toLowerCase()
            for (var k = 0; k < layerNames.length; k++)
                if (layerNames[k].toLowerCase() === lower) return layerNames[k]
            return ""
        }

        var entries = []
        var iterator = LayerUtils.createFeatureIterator(layer)
        while (iterator.hasNext()) {
            var f = iterator.next()
            var props = {}
            for (var c = 0; c < columns.length; c++) {
                var src = layerNameFor(columns[c].name)
                props[columns[c].name] = src === "" ? null
                    : plugin.jsonValue(f.attribute(src), columns[c].type)
            }
            var wkt = ""
            try { wkt = String(f.geometry.asWkt()) } catch (e) { wkt = "" }
            var geom = wkt === "" ? null : plugin.wktToGeoJson(wkt)
            if (wkt !== "" && geom === null) {
                if (typeof iterator.close === "function") iterator.close()
                return null
            }
            var u = props[uuidField]
            entries.push({
                uuid: (u === null || u === undefined) ? "" : String(u).replace(/^\{|\}$/g, ""),
                props: props,
                geometry: geom
            })
        }
        if (typeof iterator.close === "function") iterator.close()
        return entries
    }

    // Buat layer baru dari base. Kalau oldEntry diisi (migrasi kolom),
    // localEntries = data lama di HP yang ikut dipindahkan ke layer baru.
    function createLayerFromBase(base, documents, localEntries, oldEntry) {
        if ((base.fields || []).length === 0) {
            plugin.pullOutput += "GAGAL: base tidak punya skema kolom. Upload ulang base dari QGIS."
            return
        }
        var schema = plugin.baseColumns(base)
        var columns = schema.columns
        var uuidField = schema.uuidField

        var dummyGeom = plugin.dummyGeometry(base.geometryType)
        if (dummyGeom === null) {
            plugin.pullOutput += "GAGAL: tipe geometri '" + base.geometryType + "' belum didukung."
            return
        }

        // Feature bantuan di urutan pertama -> menentukan tipe kolom & geometri
        var dummyProps = {}
        for (var c = 0; c < columns.length; c++)
            dummyProps[columns[c].name] = plugin.sampleValueForType(columns[c].type)
        dummyProps[uuidField] = plugin.dummyUuid

        // 1) Data lama di HP (kalau migrasi)
        var list = []
        var byUuid = {}
        var locals = localEntries || []
        for (var l = 0; l < locals.length; l++) {
            var le = { props: locals[l].props, geometry: locals[l].geometry }
            list.push(le)
            if (locals[l].uuid !== "")
                byUuid[locals[l].uuid.toLowerCase()] = le
        }

        // 2) Data base: perbarui atribut yang sudah ada, tambah yang belum ada
        var added = 0, updated = 0, noGeom = 0
        for (var d = 0; d < documents.length; d++) {
            var doc = documents[d]
            var src = doc.properties || {}
            var fu = String(doc.uuid || src[uuidField] || doc._docId).replace(/^\{|\}$/g, "")
            var existing = byUuid[fu.toLowerCase()]
            if (existing) {
                for (var k = 0; k < columns.length; k++) {
                    var col = columns[k].name
                    if (src[col] !== undefined && col !== uuidField)
                        existing.props[col] = src[col]
                }
                updated++
                continue
            }
            var props = {}
            for (var m = 0; m < columns.length; m++) {
                var v = src[columns[m].name]
                props[columns[m].name] = (v === undefined) ? null : v
            }
            props[uuidField] = fu
            var geom = plugin.wktToGeoJson(doc.geometry_wkt)
            if (geom === null) noGeom++
            list.push({ props: props, geometry: geom })
            byUuid[fu.toLowerCase()] = list[list.length - 1]
            added++
        }

        var collection = { type: "FeatureCollection", features: [
            { type: "Feature", geometry: dummyGeom, properties: dummyProps }
        ] }
        for (var f = 0; f < list.length; f++)
            collection.features.push({ type: "Feature", geometry: list[f].geometry, properties: list[f].props })

        var crs = plugin.crsForAuthId(base.crs || "EPSG:4326")
        var memLayer = crs !== undefined
            ? LayerUtils.memoryLayerFromJsonString(base.layerName, JSON.stringify(collection), crs)
            : LayerUtils.memoryLayerFromJsonString(base.layerName, JSON.stringify(collection))
        if (!memLayer || !memLayer.isValid) {
            plugin.pullOutput += "GAGAL: layer sementara tidak bisa dibuat dari data base."
            return
        }
        if (crs === undefined) {
            plugin.pullOutput += "Catatan: CRS " + base.crs + " tidak ditemukan di QField, layer disimpan tanpa CRS.\n"
        } else {
            try { memLayer.crs = crs } catch (eCrs) {}
        }

        var home = String(qgisProject.homePath || "")
        if (home === "") {
            plugin.pullOutput += "GAGAL: folder proyek QField tidak diketahui."
            return
        }
        var stamp = Qt.formatDateTime(new Date(), "yyyyMMddHHmmss")
        var filePath = home + "/sctk_base_" + plugin.safeFileName(base.layerName) + "_" + stamp + ".gpkg"
        var filter = "\"" + uuidField + "\" IS NULL OR \"" + uuidField + "\" <> '" + plugin.dummyUuid + "'"

        var savedPath = LayerUtils.saveVectorLayerAs(memLayer, filePath, "GPKG", filter)
        if (!savedPath || String(savedPath) === "") {
            plugin.pullOutput += "GAGAL menyimpan GeoPackage ke:\n" + filePath
                + (oldEntry ? "\nLayer lama tidak diubah." : "")
            return
        }

        var styleNote = plugin.writeStyleSidecar(String(savedPath), base.styleQml)

        // Migrasi: keluarkan layer lama dulu supaya nama tidak bentrok
        if (oldEntry) {
            var oldLayer = plugin.findProjectLayerByName(oldEntry.name)
            if (oldLayer !== null)
                ProjectUtils.removeMapLayer(qgisProject, oldLayer)
        }

        var newLayer = plugin.loadAndAddLayer(String(savedPath), base.layerName)
        if (newLayer === null) {
            plugin.pullOutput += "GeoPackage tersimpan, tapi gagal dimuat ke peta:\n" + savedPath
            if (oldEntry) {
                var back = plugin.loadAndAddLayer(oldEntry.path, oldEntry.name)
                plugin.pullOutput += back !== null
                    ? "\nLayer lama dikembalikan, data aman."
                    : "\nLayer lama juga gagal dimuat ulang. Tutup-buka proyek."
            }
            return
        }

        var crsNote = plugin.ensureLayerCrs(newLayer, base.crs || "EPSG:4326")
        if (crsNote !== "")
            plugin.pullOutput += crsNote + "\n"

        // Catat supaya layer dimuat ulang otomatis saat proyek dibuka lagi
        var registry = plugin.readBaseRegistry()
        var projectKey = String(qgisProject.fileName)
        if (!registry[projectKey]) registry[projectKey] = {}
        registry[projectKey][base.docId] = {
            path: String(savedPath),
            name: base.layerName,
            crs: String(base.crs || "EPSG:4326")
        }
        plugin.writeBaseRegistry(registry)

        // File lama dikosongkan (plugin tidak bisa menghapus file)
        if (oldEntry && typeof FileUtils !== "undefined" && typeof FileUtils.writeFileContent === "function") {
            try { FileUtils.writeFileContent(String(oldEntry.path).split("|")[0], "") } catch (e1) {}
            try { FileUtils.writeFileContent(plugin.styleSidecarPath(oldEntry.path), "") } catch (e2) {}
        }

        if (oldEntry) {
            plugin.pullOutput += "\nSELESAI (struktur kolom diperbarui)\n"
                + "Data lama dipindahkan : " + locals.length + "\n"
                + "Diperbarui dari base  : " + updated + "\n"
                + "Ditambahkan dari base : " + added + "\n"
        } else {
            plugin.pullOutput += "\nSELESAI\n"
                + "Layer baru  : " + base.layerName + "\n"
                + "Feature     : " + added + "\n"
        }
        plugin.pullOutput += (noGeom > 0 ? "Tanpa geometri: " + noGeom + "\n" : "")
            + "File        : " + savedPath + "\n"
            + "Style/form  : " + (styleNote === "" ? "ikut dipasang (dropdown & simbol)" : styleNote) + "\n"
        mainWindow.displayToast(oldEntry
            ? "Layer '" + base.layerName + "' diperbarui ke struktur baru"
            : "Layer '" + base.layerName + "' dibuat dari base")
    }

    // Migrasi layer buatan plugin ke struktur kolom baru, data lama dibawa
    function migrateBaseLayer(base, layer, documents, entry, diff) {
        plugin.pullOutput += "Struktur kolom berubah.\n"
            + (diff.added.length ? "Kolom baru   : " + diff.added.join(", ") + "\n" : "")
            + (diff.removed.length ? "Kolom dihapus: " + diff.removed.join(", ") + "\n" : "")
            + "Membuat ulang layer dan memindahkan data lama...\n"

        var schema = plugin.baseColumns(base)
        var locals = plugin.readLocalEntries(layer, schema.columns, schema.uuidField)
        if (locals === null) {
            plugin.pullOutput += "GAGAL: ada geometri di HP yang tidak bisa dibaca. "
                + "Layer lama tidak diubah supaya data aman."
            return
        }
        plugin.createLayerFromBase(base, documents, locals, entry)
    }

    // Hapus layer yang dulu dibuat dari base: keluarkan dari proyek,
    // hentikan pemuatan otomatis, dan kosongkan file GPKG + style-nya.
    function deleteBaseLayer(base) {
        var registry = plugin.readBaseRegistry()
        var projectKey = String(qgisProject.fileName)
        var entries = registry[projectKey] || {}
        var entry = entries[base.docId]
        if (!entry) {
            mainWindow.displayToast("Layer ini bukan buatan plugin, tidak bisa dihapus dari sini")
            return
        }

        var layer = plugin.findProjectLayerByName(entry.name)
        if (layer !== null) {
            try {
                if (typeof layer.rollBack === "function")
                    layer.rollBack()
            } catch (e) {}
            ProjectUtils.removeMapLayer(qgisProject, layer)
        }

        delete entries[base.docId]
        registry[projectKey] = entries
        plugin.writeBaseRegistry(registry)

        // File tidak bisa dihapus dari plugin, jadi dikosongkan
        // supaya tidak memakan ruang penyimpanan.
        if (typeof FileUtils !== "undefined" && typeof FileUtils.writeFileContent === "function") {
            try { FileUtils.writeFileContent(String(entry.path).split("|")[0], "") } catch (e2) {}
            try { FileUtils.writeFileContent(plugin.styleSidecarPath(entry.path), "") } catch (e3) {}
        }

        mainWindow.displayToast("Layer '" + entry.name + "' dihapus")
        plugin.openBaseList()
    }

    // Muat ulang layer-layer base yang pernah dibuat untuk proyek ini
    function restoreBaseLayers() {
        if (typeof qgisProject === "undefined" || !qgisProject)
            return
        var projectKey = String(qgisProject.fileName || "")
        if (projectKey === "")
            return
        var registry = plugin.readBaseRegistry()
        var entries = registry[projectKey]
        if (!entries)
            return

        var changed = false
        for (var docId in entries) {
            var entry = entries[docId]
            var existingLayer = plugin.findProjectLayerByName(entry.name)
            if (existingLayer !== null) {
                plugin.ensureLayerCrs(existingLayer, entry.crs || "EPSG:4326")
                continue
            }
            var restored = plugin.loadAndAddLayer(entry.path, entry.name)
            if (restored === null) {
                console.log("Layer base tidak bisa dimuat, dihapus dari daftar: " + entry.path)
                delete entries[docId]
                changed = true
            } else {
                plugin.ensureLayerCrs(restored, entry.crs || "EPSG:4326")
            }
        }
        if (changed)
            plugin.writeBaseRegistry(registry)
    }

    Connections {
        target: (typeof qgisProject !== "undefined") ? qgisProject : null
        ignoreUnknownSignals: true
        function onReadProject() { Qt.callLater(plugin.restoreBaseLayers) }
    }

    // =====================================================
    // INISIALISASI
    // =====================================================

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(openDashboardButton)
        Qt.callLater(plugin.restoreBaseLayers)

        if (loginSettings.savedApiKey !== "") {
            plugin.firebaseApiKey = loginSettings.savedApiKey
            firebaseAuth.apiKey = loginSettings.savedApiKey
        }

        if (loginSettings.savedRefreshToken !== "") {
            plugin.activeUser = loginSettings.savedEmail
            plugin.connectionStatus = "Memulihkan sesi login..."

            firebaseAuth.refreshIdToken(
                loginSettings.savedRefreshToken
            )
        }

        mainWindow.displayToast(
            "QField SCTK Sync siap digunakan"
        )
    }

    // =====================================================
    // LOGOUT
    // =====================================================

    function logoutFirebase() {
        plugin.idToken = ""
        plugin.refreshToken = ""
        plugin.activeUser = "Belum login"
        plugin.connectionStatus = "Belum terhubung"
        plugin.loginError = ""
        plugin.isLoggingIn = false

        loginSettings.savedEmail = ""
        loginSettings.savedRefreshToken = ""
        loginSettings.savedApiKey = ""

        plugin.firebaseApiKey = ""
        firebaseAuth.apiKey = ""

        mainWindow.displayToast("Logout berhasil")
    }

    // =====================================================
    // KOMPONEN UI (inline, tidak menambah file baru)
    // Palet: netral + satu aksen hijau.
    //   Aksen #166534 | Teks #111827 | Teks redup #6B7280
    //   Utama #0369A1 (biru air) | Tekan #075985 | Tint #E0F2FE
    //   Garis #E5E7EB | Permukaan #F9FAFB | Bahaya #B91C1C
    // =====================================================

    component AppButton: Button {
        id: appBtn

        // kind: "primary" | "secondary" | "ghost" | "danger"
        property string kind: "secondary"
        property bool compact: false

        implicitHeight: compact ? 36 : 44
        leftPadding: compact ? 14 : 18
        rightPadding: compact ? 14 : 18
        font.pixelSize: compact ? 13 : 14
        font.weight: Font.Medium
        font.capitalization: Font.MixedCase
        opacity: enabled ? 1.0 : 0.4

        contentItem: Text {
            text: appBtn.text
            font: appBtn.font
            elide: Text.ElideRight
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            color: appBtn.kind === "primary" ? "#FFFFFF"
                 : appBtn.kind === "danger" ? "#B91C1C"
                 : appBtn.kind === "ghost" ? "#0369A1"
                 : "#111827"
        }

        background: Rectangle {
            radius: 8
            color: appBtn.kind === "primary"
                   ? (appBtn.down ? "#075985" : "#0369A1")
                   : appBtn.kind === "danger"
                     ? (appBtn.down ? "#FEE2E2" : "#FFFFFF")
                     : appBtn.kind === "ghost"
                       ? (appBtn.down ? "#F0F9FF" : "transparent")
                       : (appBtn.down ? "#F3F4F6" : "#FFFFFF")
            border.width: (appBtn.kind === "secondary" || appBtn.kind === "danger") ? 1 : 0
            border.color: appBtn.kind === "danger" ? "#FECACA" : "#D1D5DB"
        }
    }

    component AppDialog: Dialog {
        id: appDlg

        property bool showClose: true

        modal: true
        standardButtons: Dialog.NoButton
        padding: 16
        topPadding: 12

        Overlay.modal: Rectangle {
            color: "#66000000"
        }

        background: Rectangle {
            color: "#FFFFFF"
            radius: 16
            border.color: "#E5E7EB"
        }

        header: Item {
            implicitHeight: 56

            Label {
                anchors.left: parent.left
                anchors.leftMargin: 20
                anchors.right: closeButton.left
                anchors.rightMargin: 8
                anchors.verticalCenter: parent.verticalCenter
                text: appDlg.title
                color: "#111827"
                font.pixelSize: 17
                font.weight: Font.DemiBold
                elide: Text.ElideRight
            }

            ToolButton {
                id: closeButton
                visible: appDlg.showClose
                z: 20
                width: 44
                height: 44
                anchors.right: parent.right
                anchors.rightMargin: 4
                anchors.verticalCenter: parent.verticalCenter
                padding: 0
                // Ikon X digambar sendiri supaya tidak bergantung pada font HP
                contentItem: Item {
                    Rectangle {
                        anchors.centerIn: parent
                        width: 18
                        height: 2
                        radius: 1
                        rotation: 45
                        antialiasing: true
                        color: "#374151"
                    }
                    Rectangle {
                        anchors.centerIn: parent
                        width: 18
                        height: 2
                        radius: 1
                        rotation: -45
                        antialiasing: true
                        color: "#374151"
                    }
                }
                background: Rectangle {
                    radius: 10
                    color: closeButton.down ? "#E5E7EB" : "transparent"
                }
                onClicked: appDlg.close()
            }

            Rectangle {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                height: 1
                color: "#F1F5F9"
            }
        }
    }

    // Kartu aksi besar di dashboard: ikon panah, judul, keterangan, chevron
    component ActionTile: AbstractButton {
        id: tile

        property string subtitle: ""
        property string iconKind: "up"    // "up" = kirim, "down" = ambil
        property bool emphasized: false

        Layout.fillWidth: true
        implicitHeight: 76
        opacity: enabled ? 1.0 : 0.45

        background: Rectangle {
            radius: 12
            color: tile.down ? "#F0F9FF" : "#FFFFFF"
            border.color: tile.emphasized ? "#7DD3FC" : "#E5E7EB"
            border.width: 1
        }

        contentItem: RowLayout {
            spacing: 14

            Rectangle {
                Layout.leftMargin: 14
                Layout.preferredWidth: 44
                Layout.preferredHeight: 44
                radius: 22
                color: tile.emphasized ? "#0369A1" : "#E0F2FE"

                Canvas {
                    anchors.fill: parent
                    property color ink: tile.emphasized ? "#FFFFFF" : "#0369A1"
                    onInkChanged: requestPaint()
                    onPaint: {
                        var ctx = getContext("2d")
                        ctx.reset()
                        ctx.strokeStyle = ink
                        ctx.lineWidth = 2.4
                        ctx.lineCap = "round"
                        ctx.lineJoin = "round"
                        var cx = width / 2, cy = height / 2
                        var up = tile.iconKind === "up"
                        var tip = up ? cy - 9 : cy + 5
                        var tail = up ? cy + 5 : cy - 9
                        var wing = up ? tip + 6 : tip - 6
                        ctx.beginPath()
                        ctx.moveTo(cx, tail); ctx.lineTo(cx, tip)
                        ctx.moveTo(cx - 6, wing); ctx.lineTo(cx, tip); ctx.lineTo(cx + 6, wing)
                        ctx.moveTo(cx - 9, cy + 10); ctx.lineTo(cx + 9, cy + 10)
                        ctx.stroke()
                    }
                    Component.onCompleted: requestPaint()
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2

                Label {
                    Layout.fillWidth: true
                    text: tile.text
                    color: "#111827"
                    font.pixelSize: 15
                    font.weight: Font.DemiBold
                    elide: Text.ElideRight
                }
                Label {
                    Layout.fillWidth: true
                    text: tile.subtitle
                    color: "#6B7280"
                    font.pixelSize: 12
                    wrapMode: Text.WordWrap
                    maximumLineCount: 2
                    elide: Text.ElideRight
                }
            }

            // Chevron >
            Item {
                Layout.rightMargin: 14
                Layout.preferredWidth: 12
                Layout.preferredHeight: 16
                Rectangle {
                    x: 2; y: 4; width: 9; height: 2; radius: 1
                    rotation: 45; antialiasing: true; color: "#9CA3AF"
                    transformOrigin: Item.Right
                }
                Rectangle {
                    x: 2; y: 10; width: 9; height: 2; radius: 1
                    rotation: -45; antialiasing: true; color: "#9CA3AF"
                    transformOrigin: Item.Right
                }
            }
        }
    }

    // =====================================================
    // TOMBOL TOOLBAR
    // =====================================================

    Button {
        id: openDashboardButton

        width: 48
        height: 48
        padding: 0

        // Logo: tetes air putih di lingkaran biru (SCTK = perusahaan air)
        contentItem: Canvas {
            id: dropIcon
            anchors.fill: parent
            onPaint: {
                var ctx = getContext("2d")
                ctx.reset()
                var cx = width / 2
                var top = height * 0.22
                var cy = height * 0.58
                var r = width * 0.17
                ctx.fillStyle = "#FFFFFF"
                ctx.beginPath()
                ctx.moveTo(cx, top)
                ctx.bezierCurveTo(cx - r * 0.35, top + r * 0.9, cx - r, cy - r * 0.6, cx - r, cy)
                ctx.arc(cx, cy, r, Math.PI, 0, true)
                ctx.bezierCurveTo(cx + r, cy - r * 0.6, cx + r * 0.35, top + r * 0.9, cx, top)
                ctx.closePath()
                ctx.fill()
                // kilau kecil
                ctx.fillStyle = "#0369A1"
                ctx.beginPath()
                ctx.arc(cx - r * 0.38, cy + r * 0.05, r * 0.2, 0, Math.PI * 2)
                ctx.fill()
            }
            Component.onCompleted: requestPaint()
        }

        background: Rectangle {
            radius: width / 2
            color: openDashboardButton.down ? "#075985" : "#0369A1"
        }

        onClicked: dashboard.open()
    }

    // =====================================================
    // DASHBOARD
    // =====================================================

    AppDialog {
        id: dashboard

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 24, 420)
        height: Math.min(parent.height - 32, 440)

        title: "SCTK Sync"

        contentItem: Flickable {
            clip: true
            contentWidth: width
            contentHeight: dashboardColumn.implicitHeight
            boundsBehavior: Flickable.StopAtBounds

            ColumnLayout {
                id: dashboardColumn

                width: parent.width
                spacing: 12

                // Akun & status koneksi
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: accountRow.implicitHeight + 32
                    radius: 12
                    color: "#F9FAFB"
                    border.color: "#E5E7EB"

                    RowLayout {
                        id: accountRow

                        anchors.fill: parent
                        anchors.margins: 16
                        spacing: 12

                        Rectangle {
                            Layout.preferredWidth: 40
                            Layout.preferredHeight: 40
                            radius: 20
                            color: plugin.idToken !== "" ? "#E0F2FE" : "#E5E7EB"

                            Label {
                                anchors.centerIn: parent
                                text: plugin.idToken !== "" && plugin.activeUser.length > 0
                                      ? plugin.activeUser.charAt(0).toUpperCase() : "?"
                                color: plugin.idToken !== "" ? "#0369A1" : "#6B7280"
                                font.pixelSize: 16
                                font.bold: true
                            }
                        }

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 3

                            Label {
                                Layout.fillWidth: true
                                text: plugin.activeUser
                                color: "#111827"
                                font.pixelSize: 14
                                font.weight: Font.DemiBold
                                elide: Text.ElideMiddle
                            }

                            RowLayout {
                                Layout.fillWidth: true
                                spacing: 6

                                Rectangle {
                                    Layout.preferredWidth: 8
                                    Layout.preferredHeight: 8
                                    Layout.alignment: Qt.AlignVCenter
                                    radius: 4
                                    color: plugin.idToken !== "" ? "#16A34A" : "#D97706"
                                }

                                Label {
                                    Layout.fillWidth: true
                                    text: plugin.connectionStatus
                                    color: "#6B7280"
                                    font.pixelSize: 12
                                    elide: Text.ElideRight
                                }
                            }
                        }

                        AppButton {
                            compact: true
                            kind: plugin.idToken === "" ? "primary" : "secondary"
                            text: plugin.idToken === "" ? "Login" : "Akun"

                            onClicked: {
                                if (plugin.idToken === "") {
                                    plugin.loginError = ""
                                    loginDialog.open()
                                } else {
                                    accountDialog.open()
                                }
                            }
                        }
                    }
                }

                Label {
                    Layout.topMargin: 4
                    text: "Mau ngapain?"
                    color: "#6B7280"
                    font.pixelSize: 12
                    font.weight: Font.Medium
                }

                ActionTile {
                    text: "Kirim hasil survei"
                    subtitle: plugin.idToken !== ""
                              ? "Pilih layer dan fitur, lalu kirim ke Firebase."
                              : "Login dulu untuk mengirim hasil survei."
                    iconKind: "up"
                    emphasized: true
                    enabled: plugin.idToken !== ""
                    onClicked: plugin.refreshLayerList()
                }

                ActionTile {
                    text: "Ambil base dari QGIS"
                    subtitle: plugin.idToken !== ""
                              ? "Buat atau perbarui layer acuan di HP ini."
                              : "Login dulu untuk mengambil base."
                    iconKind: "down"
                    enabled: plugin.idToken !== ""
                    onClicked: plugin.openBaseList()
                }

                RowLayout {
                    Layout.fillWidth: true
                    Layout.topMargin: 4

                    Label {
                        Layout.fillWidth: true
                        text: "Proyek · " + firestoreApi.projectId
                        color: "#9CA3AF"
                        font.pixelSize: 11
                        elide: Text.ElideMiddle
                    }

                    AppButton {
                        compact: true
                        kind: "ghost"
                        text: "Diagnostik"
                        onClicked: plugin.debugQFieldApi()
                    }
                }
            }
        }
    }

    // =====================================================
    // DIALOG DAFTAR LAYER
    // =====================================================

    AppDialog {
        id: layerDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 420)
        height: Math.min(parent.height - 48, 540)

        title: "Pilih layer"

        contentItem: ColumnLayout {
            spacing: 8

            Label {
                Layout.fillWidth: true
                text: plugin.layerListMessage
                color: "#6B7280"
                font.pixelSize: 13
                wrapMode: Text.WordWrap
            }

            ListView {
                id: layerList

                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                model: plugin.availableLayers
                boundsBehavior: Flickable.StopAtBounds

                ScrollBar.vertical: ScrollBar {
                    policy: ScrollBar.AsNeeded
                }

                delegate: Item {
                    id: layerRow

                    required property var modelData
                    required property int index

                    width: ListView.view.width
                    height: 64

                    Rectangle {
                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.bottom: parent.bottom
                        height: 1
                        color: "#F1F5F9"
                        visible: layerRow.index < layerList.count - 1
                    }

                    RowLayout {
                        anchors.fill: parent
                        anchors.rightMargin: 4
                        spacing: 12

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 2

                            Label {
                                Layout.fillWidth: true
                                text: layerRow.modelData.name
                                color: "#111827"
                                font.pixelSize: 14
                                font.weight: Font.DemiBold
                                elide: Text.ElideRight
                            }

                            Label {
                                Layout.fillWidth: true
                                text: plugin.baseDocIdForLayer(layerRow.modelData.name) !== ""
                                      ? "Dikirim ke base " + plugin.baseDocIdForLayer(layerRow.modelData.name)
                                      : "Dikirim ke kotak masuk (qfield_inbox)"
                                color: plugin.baseDocIdForLayer(layerRow.modelData.name) !== ""
                                       ? "#0369A1" : "#9CA3AF"
                                font.pixelSize: 11
                                elide: Text.ElideRight
                            }
                        }

                        AppButton {
                            compact: true
                            kind: "primary"
                            text: "Pilih fitur"

                            onClicked: {
                                try {
                                    var chosenLayerId = layerRow.modelData.id
                                    layerDialog.close()
                                    plugin.inspectLayer(chosenLayerId)
                                } catch (error) {
                                    plugin.featureCheckOutput =
                                        "ERROR TOMBOL CEK FITUR: " + String(error)
                                    featureCheckDialog.open()
                                }
                            }
                        }
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true


                Item {
                    Layout.fillWidth: true
                }
            }
        }
    }

    // =====================================================
    // DIALOG TABEL ATRIBUT QFIELD
    // =====================================================

    AppDialog {
        id: featureCheckDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.max(260, Math.min(parent.width - 24, 1040))
        height: Math.max(300, Math.min(parent.height - 24, 780))

        title: "Tabel Atribut"

        contentItem: ColumnLayout {
            spacing: 10

            // Ringkasan layer
            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2

                    Label {
                        Layout.fillWidth: true
                        text: plugin.attributeLayerName
                        color: "#111827"
                        font.pixelSize: 15
                        font.weight: Font.DemiBold
                        elide: Text.ElideRight
                    }

                    Label {
                        Layout.fillWidth: true
                        text: plugin.attributeFeatureCount + " fitur  ·  " +
                              plugin.attributeHeaders.length + " kolom"
                        color: "#6B7280"
                        font.pixelSize: 12
                        elide: Text.ElideRight
                    }
                }

                Rectangle {
                    Layout.preferredWidth: selectedChipLabel.implicitWidth + 24
                    Layout.preferredHeight: 28
                    radius: 14
                    color: plugin.selectedFeatureIds.length > 0 ? "#E0F2FE" : "#F3F4F6"

                    Label {
                        id: selectedChipLabel
                        anchors.centerIn: parent
                        text: plugin.selectedFeatureIds.length + " dipilih"
                        color: plugin.selectedFeatureIds.length > 0 ? "#0369A1" : "#6B7280"
                        font.pixelSize: 12
                        font.weight: Font.DemiBold
                    }
                }
            }

            Label {
                Layout.fillWidth: true
                text: plugin.featureCheckOutput
                visible: plugin.featureCheckOutput !== ""
                color: "#6B7280"
                font.pixelSize: 12
                wrapMode: Text.WordWrap
            }

            // Tabel
            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                radius: 8
                color: "#FFFFFF"
                border.color: "#E5E7EB"
                clip: true

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 1
                    spacing: 0

                    // Header terpisah dari isi agar tetap terlihat saat scroll vertikal.
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 40
                        color: "#F3F4F6"

                        Flickable {
                            id: attributeHeaderFlick

                            anchors.fill: parent
                            clip: true
                            contentWidth: Math.max(width, 48 + plugin.attributeHeaders.length * 136)
                            contentHeight: height
                            interactive: false
                            boundsBehavior: Flickable.StopAtBounds

                            Row {
                                height: 40
                                spacing: 0

                                Item {
                                    width: 48
                                    height: 40

                                    Text {
                                        anchors.centerIn: parent
                                        text: "Pilih"
                                        color: "#374151"
                                        font.bold: true
                                        font.pixelSize: 11
                                    }
                                }

                                Repeater {
                                    model: plugin.attributeHeaders

                                    delegate: Item {
                                        required property var modelData
                                        required property int index

                                        width: 136
                                        height: 40

                                        Button {
                                            anchors.fill: parent
                                            flat: true
                                            padding: 8
                                            text: String(modelData) +
                                                  (plugin.sortColumn === index
                                                   ? (plugin.sortAscending ? "  ▲" : "  ▼") : "")

                                            contentItem: Text {
                                                text: parent.text
                                                color: plugin.sortColumn === index ? "#0369A1" : "#374151"
                                                font.bold: true
                                                font.pixelSize: 11
                                                font.capitalization: Font.MixedCase
                                                verticalAlignment: Text.AlignVCenter
                                                horizontalAlignment: Text.AlignLeft
                                                elide: Text.ElideRight
                                            }

                                            background: Rectangle {
                                                color: parent.down ? "#E5E7EB" : "transparent"
                                            }

                                            onClicked: plugin.sortAttributeRows(index)
                                        }
                                    }
                                }
                            }
                        }

                        Rectangle {
                            anchors.left: parent.left
                            anchors.right: parent.right
                            anchors.bottom: parent.bottom
                            height: 1
                            color: "#E5E7EB"
                        }
                    }

                    Item {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true

                        Flickable {
                            id: attributeBodyFlick

                            anchors.fill: parent
                            clip: true
                            contentWidth: Math.max(width, 48 + plugin.attributeHeaders.length * 136)
                            contentHeight: height
                            boundsBehavior: Flickable.StopAtBounds
                            flickableDirection: Flickable.HorizontalFlick
                            onContentXChanged: attributeHeaderFlick.contentX = contentX

                            ListView {
                                id: attributeRowsList

                                x: 0
                                y: 0
                                width: attributeBodyFlick.contentWidth
                                height: attributeBodyFlick.height
                                clip: true
                                model: plugin.attributeRows
                                boundsBehavior: Flickable.StopAtBounds
                                reuseItems: true
                                cacheBuffer: 0
                                spacing: 0

                                delegate: Item {
                                    id: tableRow

                                    required property var modelData

                                    readonly property bool picked: plugin.isFeatureSelected(modelData[0])

                                    width: attributeBodyFlick.contentWidth
                                    height: 40

                                    Rectangle {
                                        anchors.fill: parent
                                        color: tableRow.picked ? "#F0F9FF" : "transparent"
                                    }

                                    Rectangle {
                                        anchors.left: parent.left
                                        anchors.right: parent.right
                                        anchors.bottom: parent.bottom
                                        height: 1
                                        color: "#F1F5F9"
                                    }

                                    Row {
                                        anchors.fill: parent
                                        spacing: 0

                                        Item {
                                            id: checkboxCell
                                            width: 48
                                            height: 40

                                            Rectangle {
                                                id: checkboxVisual
                                                width: 20
                                                height: 20
                                                radius: 4
                                                anchors.centerIn: parent
                                                color: tableRow.picked ? "#0369A1" : "#FFFFFF"
                                                border.width: tableRow.picked ? 0 : 1.5
                                                border.color: tableRow.picked ? "#0369A1" : "#9CA3AF"

                                                Text {
                                                    anchors.centerIn: parent
                                                    visible: tableRow.picked
                                                    text: "✓"
                                                    color: "#FFFFFF"
                                                    font.pixelSize: 15
                                                    font.bold: true
                                                }
                                            }

                                            MouseArea {
                                                anchors.fill: parent
                                                onClicked: plugin.setFeatureSelected(tableRow.modelData[0], !tableRow.picked)
                                            }
                                        }

                                        Repeater {
                                            model: tableRow.modelData

                                            delegate: Item {
                                                required property var modelData
                                                required property int index

                                                width: 136
                                                height: 40

                                                Text {
                                                    anchors.fill: parent
                                                    anchors.leftMargin: 8
                                                    anchors.rightMargin: 8
                                                    text: String(modelData)
                                                    color: index === 0 ? "#6B7280" : "#1F2937"
                                                    font.pixelSize: 12
                                                    verticalAlignment: Text.AlignVCenter
                                                    elide: Text.ElideRight
                                                }
                                            }
                                        }
                                    }
                                }

                                ScrollBar.vertical: ScrollBar {
                                    policy: ScrollBar.AsNeeded
                                    width: 10
                                    minimumSize: 0.08
                                }
                            }

                            ScrollBar.horizontal: ScrollBar {
                                policy: ScrollBar.AsNeeded
                                height: 10
                                minimumSize: 0.08
                            }
                        }
                    }
                }
            }

            Label {
                Layout.fillWidth: true
                text: plugin.idToken === ""
                      ? "Login diperlukan untuk mengirim data."
                      : "Geser ke samping untuk kolom lain. Ketuk judul kolom untuk mengurutkan."
                color: "#9CA3AF"
                font.pixelSize: 11
                wrapMode: Text.WordWrap
            }

            // Aksi
            RowLayout {
                Layout.fillWidth: true
                spacing: 6

                AppButton {
                    compact: true
                    kind: "ghost"
                    text: "Pilih semua"
                    onClicked: {
                        var ids = []
                        for (var i = 0; i < plugin.attributeRows.length; i++)
                            ids.push(String(plugin.attributeRows[i][0]))
                        plugin.selectedFeatureIds = ids
                    }
                }

                AppButton {
                    compact: true
                    kind: "ghost"
                    text: "Batal pilih"
                    onClicked: plugin.selectedFeatureIds = []
                }

                Item {
                    Layout.fillWidth: true
                }

                AppButton {
                    kind: "primary"
                    text: "Kirim (" + plugin.selectedFeatureIds.length + ")"
                    enabled: plugin.selectedFeatureIds.length > 0 && plugin.idToken !== ""
                    onClicked: sendSelectionDialog.open()
                }
            }
        }
    }

    // =====================================================
    // KONFIRMASI, PROGRES, DAN HASIL PENGIRIMAN
    // =====================================================

    AppDialog {
        id: sendSelectionDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 420)
        title: "Konfirmasi Pengiriman"

        contentItem: ColumnLayout {
            spacing: 14

            Label {
                Layout.fillWidth: true
                text: "Kamu memilih " + plugin.selectedFeatureIds.length +
                      " fitur dari layer " + plugin.attributeLayerName + "."
                color: "#111827"
                font.pixelSize: 14
                wrapMode: Text.WordWrap
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: noteLabel.implicitHeight + 24
                radius: 10
                color: "#FFFBEB"
                border.color: "#FDE68A"

                Label {
                    id: noteLabel

                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.margins: 12
                    text: "Fitur terpilih dikirim ke antrean survei Firebase. Atribut disimpan sebagai properties dan geometri sebagai objek terstruktur dengan koordinat. Data utama tidak ditimpa langsung."
                    color: "#92400E"
                    font.pixelSize: 12
                    wrapMode: Text.WordWrap
                }
            }

            RowLayout {
                Layout.fillWidth: true
                Layout.topMargin: 4
                spacing: 8

                AppButton {
                    Layout.fillWidth: true
                    text: "Batal"
                    onClicked: sendSelectionDialog.close()
                }

                AppButton {
                    Layout.fillWidth: true
                    kind: "primary"
                    text: "Kirim sekarang"
                    onClicked: plugin.startSelectedUpload()
                }
            }
        }
    }

    AppDialog {
        id: uploadProgressDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 420)
        title: "Mengirim Data Survei"
        showClose: false
        closePolicy: Popup.NoAutoClose

        contentItem: ColumnLayout {
            spacing: 14

            Label {
                id: uploadProgressText

                Layout.fillWidth: true
                text: "Menyiapkan pengiriman..."
                color: "#111827"
                font.pixelSize: 14
                wrapMode: Text.WordWrap
            }

            ProgressBar {
                Layout.fillWidth: true
                from: 0
                to: Math.max(1, plugin.uploadQueue.length)
                value: plugin.uploadQueueIndex
            }

            Label {
                Layout.fillWidth: true
                text: "Jangan tutup aplikasi sampai pengiriman selesai."
                color: "#9CA3AF"
                font.pixelSize: 11
                wrapMode: Text.WordWrap
            }
        }
    }

    AppDialog {
        id: uploadResultDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 420)
        title: "Hasil Pengiriman"

        contentItem: ColumnLayout {
            spacing: 14

            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 76
                    radius: 12
                    color: "#F0F9FF"
                    border.color: "#BAE6FD"

                    Column {
                        anchors.centerIn: parent
                        spacing: 2

                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: plugin.uploadSuccessCount
                            color: "#0369A1"
                            font.pixelSize: 26
                            font.bold: true
                        }

                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: "Berhasil"
                            color: "#0369A1"
                            font.pixelSize: 12
                        }
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 76
                    radius: 12
                    color: plugin.uploadFailureCount > 0 ? "#FEF2F2" : "#F9FAFB"
                    border.color: plugin.uploadFailureCount > 0 ? "#FECACA" : "#E5E7EB"

                    Column {
                        anchors.centerIn: parent
                        spacing: 2

                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: plugin.uploadFailureCount
                            color: plugin.uploadFailureCount > 0 ? "#B91C1C" : "#6B7280"
                            font.pixelSize: 26
                            font.bold: true
                        }

                        Label {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: "Gagal"
                            color: plugin.uploadFailureCount > 0 ? "#B91C1C" : "#6B7280"
                            font.pixelSize: 12
                        }
                    }
                }
            }

            Label {
                Layout.fillWidth: true
                visible: plugin.uploadFailureCount > 0
                text: "Detail kegagalan (ID fitur dan penyebab):"
                color: "#991B1B"
                font.pixelSize: 12
                font.bold: true
                wrapMode: Text.WordWrap
            }

            ScrollView {
                Layout.fillWidth: true
                Layout.preferredHeight: plugin.uploadFailureCount > 0 ? Math.min(150, Math.max(48, failureDetailsLabel.implicitHeight + 12)) : 0
                visible: plugin.uploadFailureCount > 0
                clip: true

                Label {
                    id: failureDetailsLabel
                    width: uploadResultDialog.width - 64
                    text: plugin.uploadFailureDetails.join("\n\n")
                    color: "#7F1D1D"
                    font.pixelSize: 11
                    wrapMode: Text.WrapAnywhere
                }
            }

            Label {
                Layout.fillWidth: true
                visible: plugin.uploadFailureCount > 0
                text: "Periksa penyebab di atas. UUID otomatis dibuat untuk fitur yang belum memiliki UUID; UUID tersebut dikirim sebagai identitas dokumen dan properti."
                color: "#6B7280"
                font.pixelSize: 11
                wrapMode: Text.WordWrap
            }

            AppButton {
                Layout.fillWidth: true
                kind: "primary"
                text: "Selesai"
                onClicked: uploadResultDialog.close()
            }
        }
    }

    // =====================================================
    // DIALOG HASIL PEMERIKSAAN API
    // =====================================================

    AppDialog {
        id: debugDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 24, 520)
        height: Math.min(parent.height - 32, 540)

        title: "Pemeriksaan API QField"

        contentItem: ColumnLayout {
            spacing: 10

            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                radius: 10
                color: "#F9FAFB"
                border.color: "#E5E7EB"
                clip: true

                ScrollView {
                    anchors.fill: parent
                    anchors.margins: 4

                    TextArea {
                        readOnly: true
                        selectByMouse: true
                        wrapMode: TextEdit.Wrap
                        text: plugin.debugOutput
                        color: "#1F2937"
                        font.family: "monospace"
                        font.pixelSize: 12
                        background: null
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                Item {
                    Layout.fillWidth: true
                }

                AppButton {
                    text: "Tutup"
                    onClicked: debugDialog.close()
                }
            }
        }
    }

    // =====================================================
    // DIALOG DAFTAR BASE
    // =====================================================

    AppDialog {
        id: baseDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 420)
        height: Math.min(parent.height - 48, 540)

        title: "Tarik Base"

        contentItem: ColumnLayout {
            spacing: 8

            Label {
                Layout.fillWidth: true
                text: plugin.baseListMessage
                color: "#6B7280"
                font.pixelSize: 13
                wrapMode: Text.WordWrap
            }

            ListView {
                id: baseListView

                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                model: plugin.baseList
                boundsBehavior: Flickable.StopAtBounds

                ScrollBar.vertical: ScrollBar {
                    policy: ScrollBar.AsNeeded
                }

                delegate: Item {
                    id: baseRow

                    required property var modelData
                    required property int index

                    width: ListView.view.width
                    height: 64

                    Rectangle {
                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.bottom: parent.bottom
                        height: 1
                        color: "#F1F5F9"
                        visible: baseRow.index < baseListView.count - 1
                    }

                    RowLayout {
                        anchors.fill: parent
                        anchors.rightMargin: 4
                        spacing: 12

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 2

                            Label {
                                Layout.fillWidth: true
                                text: baseRow.modelData.layerName
                                color: "#111827"
                                font.pixelSize: 14
                                font.weight: Font.DemiBold
                                elide: Text.ElideRight
                            }

                            Label {
                                Layout.fillWidth: true
                                text: baseRow.modelData.featureCount + " fitur  ·  "
                                      + baseRow.modelData.geometryType
                                      + (baseRow.modelData.inProject
                                         ? "  ·  → " + baseRow.modelData.targetName
                                         : "  ·  layer baru akan dibuat")
                                color: baseRow.modelData.inProject ? "#9CA3AF" : "#0369A1"
                                font.pixelSize: 11
                                elide: Text.ElideRight
                            }
                        }

                        AppButton {
                            compact: true
                            kind: "danger"
                            text: "Hapus"
                            visible: baseRow.modelData.createdByPlugin === true
                            enabled: !plugin.pullBusy

                            onClicked: {
                                plugin.pendingBase = baseRow.modelData
                                deleteConfirmDialog.open()
                            }
                        }

                        AppButton {
                            compact: true
                            kind: "primary"
                            text: baseRow.modelData.inProject ? "Tarik" : "Buat"
                            enabled: !plugin.pullBusy

                            onClicked: {
                                plugin.pendingBase = baseRow.modelData
                                pullConfirmDialog.open()
                            }
                        }
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                Item {
                    Layout.fillWidth: true
                }

                AppButton {
                    text: "Tutup"
                    onClicked: baseDialog.close()
                }
            }
        }
    }

    AppDialog {
        id: pullConfirmDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 400)
        title: "Tarik base?"

        contentItem: ColumnLayout {
            spacing: 12

            Label {
                Layout.fillWidth: true
                text: !plugin.pendingBase ? ""
                      : !plugin.pendingBase.inProject
                        ? ("Layer '" + plugin.pendingBase.layerName + "' belum ada di proyek ini.\n\n"
                           + "• Layer baru akan dibuat sebagai file GeoPackage di folder proyek QField, "
                           + "dengan kolom sesuai base dari QGIS.\n"
                           + "• Semua feature base (" + plugin.pendingBase.featureCount + ") ikut dimasukkan.\n"
                           + "• Layer ini dimuat otomatis setiap proyek dibuka.")
                        : ("Base '" + plugin.pendingBase.layerName + "' akan dimasukkan ke layer '"
                           + plugin.pendingBase.targetName + "' di GeoPackage QField.\n\n"
                           + "• Feature yang uuid-nya belum ada akan ditambahkan.\n"
                           + "• Feature yang uuid-nya sudah ada akan diperbarui atributnya. "
                           + "Geometrinya tidak diubah.\n"
                           + "• Feature lain di layer QField tidak dihapus.\n"
                           + "• Kalau base punya kolom baru, layer buatan plugin dibuat ulang "
                           + "otomatis dengan struktur baru; data lama di HP ikut dipindahkan.")
                color: "#374151"
                font.pixelSize: 13
                wrapMode: Text.WordWrap
            }

            RowLayout {
                Layout.fillWidth: true

                Item {
                    Layout.fillWidth: true
                }

                AppButton {
                    text: "Batal"
                    onClicked: pullConfirmDialog.close()
                }

                AppButton {
                    kind: "primary"
                    text: "Tarik sekarang"
                    onClicked: {
                        var chosen = plugin.pendingBase
                        pullConfirmDialog.close()
                        baseDialog.close()
                        if (chosen)
                            plugin.startPullBase(chosen)
                    }
                }
            }
        }
    }

    AppDialog {
        id: deleteConfirmDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 400)
        title: "Hapus layer?"

        contentItem: ColumnLayout {
            spacing: 12

            Label {
                Layout.fillWidth: true
                text: plugin.pendingBase
                      ? ("Layer '" + plugin.pendingBase.layerName + "' akan dikeluarkan dari proyek "
                         + "dan tidak dimuat lagi saat proyek dibuka.\n\n"
                         + "PERHATIAN: semua feature di layer ini ikut hilang dari HP, "
                         + "termasuk hasil survei yang belum dikirim ke Firebase.\n\n"
                         + "Base di Firebase tidak ikut terhapus, jadi layer bisa dibuat ulang lewat tombol Buat.")
                      : ""
                color: "#374151"
                font.pixelSize: 13
                wrapMode: Text.WordWrap
            }

            RowLayout {
                Layout.fillWidth: true

                Item {
                    Layout.fillWidth: true
                }

                AppButton {
                    text: "Batal"
                    onClicked: deleteConfirmDialog.close()
                }

                AppButton {
                    kind: "danger"
                    text: "Hapus layer"
                    onClicked: {
                        var chosen = plugin.pendingBase
                        deleteConfirmDialog.close()
                        if (chosen)
                            plugin.deleteBaseLayer(chosen)
                    }
                }
            }
        }
    }

    AppDialog {
        id: pullResultDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 24, 480)
        height: Math.min(parent.height - 32, 460)

        title: plugin.pullBusy ? "Menarik base..." : "Hasil Tarik Base"

        contentItem: ColumnLayout {
            spacing: 10

            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                radius: 10
                color: "#F9FAFB"
                border.color: "#E5E7EB"
                clip: true

                ScrollView {
                    anchors.fill: parent
                    anchors.margins: 4

                    TextArea {
                        readOnly: true
                        selectByMouse: true
                        wrapMode: TextEdit.Wrap
                        text: plugin.pullOutput
                        color: "#1F2937"
                        font.family: "monospace"
                        font.pixelSize: 12
                        background: null
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                Item {
                    Layout.fillWidth: true
                }

                AppButton {
                    text: "Tutup"
                    enabled: !plugin.pullBusy
                    onClicked: pullResultDialog.close()
                }
            }
        }
    }

    // =====================================================
    // DIALOG LOGIN
    // =====================================================

    LoginDialog {
        id: loginDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        projectId: "webgis-sctk"
        apiKey: plugin.firebaseApiKey
        loading: plugin.isLoggingIn
        errorMessage: plugin.loginError

        onLoginRequested: function(projectId, apiKey, email, password) {
            plugin.firebaseApiKey = apiKey
            loginSettings.savedApiKey = apiKey
            plugin.loginError = ""
            plugin.isLoggingIn = true

            firebaseAuth.apiKey = apiKey
            firebaseAuth.login(email, password)
        }
    }

    // =====================================================
    // DIALOG AKUN
    // =====================================================

    AppDialog {
        id: accountDialog

        parent: mainWindow.contentItem
        anchors.centerIn: parent

        width: Math.min(parent.width - 32, 340)
        title: "Akun SCTK Sync"

        contentItem: ColumnLayout {
            spacing: 14

            RowLayout {
                Layout.fillWidth: true
                spacing: 12

                Rectangle {
                    Layout.preferredWidth: 40
                    Layout.preferredHeight: 40
                    radius: 20
                    color: "#E0F2FE"

                    Label {
                        anchors.centerIn: parent
                        text: plugin.activeUser.length > 0 ? plugin.activeUser.charAt(0).toUpperCase() : "?"
                        color: "#0369A1"
                        font.pixelSize: 16
                        font.bold: true
                    }
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2

                    Label {
                        text: "Login sebagai"
                        color: "#6B7280"
                        font.pixelSize: 12
                    }

                    Label {
                        Layout.fillWidth: true
                        text: plugin.activeUser
                        color: "#111827"
                        font.pixelSize: 14
                        font.weight: Font.DemiBold
                        elide: Text.ElideMiddle
                    }
                }
            }

            AppButton {
                Layout.fillWidth: true
                kind: "danger"
                text: "Logout"

                onClicked: {
                    plugin.logoutFirebase()
                    accountDialog.close()
                }
            }
        }
    }
}
